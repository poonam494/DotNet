﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace responsiveTrial
{
    public partial class DDLAjax : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        [WebMethod]
        public static Dictionary<string, string> PopulateOrganizationDropdown()
        {
            try
            {
                Dictionary<string, string> organizationDictionary = new Dictionary<string, string>();

                PeopleFinderT.PeopleFinderWebServiceSoapClient ws = new PeopleFinderT.PeopleFinderWebServiceSoapClient();

                DataSet ds = ws.GetOrganizationUnits();

                // return ds.GetXml();

                List<string> orgs = new List<string>();

                foreach (DataRow item in ds.Tables[0].Rows)
                {
                    orgs.Add(item["organizationName"].ToString().Split(new string[] { "=" }, StringSplitOptions.RemoveEmptyEntries)[1] + ":" + item["organizationName"].ToString().Split(new string[] { "=" }, StringSplitOptions.RemoveEmptyEntries)[1]);
                }
                // return orgs;



                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    string orgFullName = row["organizationname"].ToString();
                    string name = orgFullName.Split(new string[] { "=" }, StringSplitOptions.RemoveEmptyEntries)[1];
                    organizationDictionary.Add(name + "_Key", name);
                }

                ////ddl.DataSource = organizationDictionary;
                ////ddl.DataTextField = "Value";
                ////ddl.DataValueField = "Key";
                ////ddl.DataBind();

                //dropDownorganization.DataSource = organizationDictionary;
                //dropDownorganization.DataTextField = "Value";
                //dropDownorganization.DataValueField = "Key";
                //dropDownorganization.DataBind();

                return organizationDictionary;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }


       


    }
}