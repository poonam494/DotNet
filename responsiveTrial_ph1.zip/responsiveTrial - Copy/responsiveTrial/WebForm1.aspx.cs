﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace responsiveTrial
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!Page.IsPostBack)
            {

             //   Repeater.Attributes.Add("Class", "Invisible");
            Repeater1.DataSource = PopulateOragnizationUsers("BMSI"); 
            Repeater1.DataBind();
            }

        }

        [WebMethod]
        public static Dictionary<string, string> PopulateOrganizationDropdown()
        {
            try
            {
                Dictionary<string, string> organizationDictionary = new Dictionary<string, string>();

                PeopleFinderT.PeopleFinderWebServiceSoapClient ws = new PeopleFinderT.PeopleFinderWebServiceSoapClient();

                DataSet ds = ws.GetOrganizationUnits();

                // return ds.GetXml();

                List<string> orgs = new List<string>();

                foreach (DataRow item in ds.Tables[0].Rows)
                {
                    orgs.Add(item["organizationName"].ToString().Split(new string[] { "=" }, StringSplitOptions.RemoveEmptyEntries)[1] + ":" + item["organizationName"].ToString().Split(new string[] { "=" }, StringSplitOptions.RemoveEmptyEntries)[1]);
                }
                // return orgs;



                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    string orgFullName = row["organizationname"].ToString();
                    string name = orgFullName.Split(new string[] { "=" }, StringSplitOptions.RemoveEmptyEntries)[1];
                    organizationDictionary.Add(name + "_Key", name);
                }

                ////ddl.DataSource = organizationDictionary;
                ////ddl.DataTextField = "Value";
                ////ddl.DataValueField = "Key";
                ////ddl.DataBind();

                //dropDownorganization.DataSource = organizationDictionary;
                //dropDownorganization.DataTextField = "Value";
                //dropDownorganization.DataValueField = "Key";
                //dropDownorganization.DataBind();

                return organizationDictionary;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }


        [WebMethod]
        public static List<ActiveDirectoryUserDetails> PopulateOragnizationUsers(string organizationName)
        {
            try
            {

                

                PeopleFinderT.PeopleFinderWebServiceSoapClient ws = new PeopleFinderT.PeopleFinderWebServiceSoapClient();

                DataSet ds = ws.GetOrganizationUnitUsers(organizationName);
                List<ActiveDirectoryUserDetails> organizationUnitUsers = new List<ActiveDirectoryUserDetails>();

                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    ActiveDirectoryUserDetails user = new ActiveDirectoryUserDetails();

                    user.displayName = row["displayName"].ToString();
                    user.title = row["title"].ToString();
                    user.company = row["company"].ToString();
                    user.mail = row["mail"].ToString();
                    user.department = row["department"].ToString();
                    user.telephoneNumber = row["telephoneNumber"].ToString();
                    user.mobile = row["mobile"].ToString();
                    user.physicalDeliveryOfficeName = row["physicalDeliveryOfficeName"].ToString();
                    user.cn = row["cn"].ToString();
                    user.organizationUnit = row["organizationUnit"].ToString();
                    user.distinguishedName = row["distinguishedName"].ToString();
                    user.imageLocation = row["imageLocation"].ToString();

                    organizationUnitUsers.Add(user);

                }

                //Repeater1.DataSource = organizationUnitUsers;
                //Repeater1.DataBind();
                return organizationUnitUsers;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



        [WebMethod]
        public static Dictionary<string, string> PopulateDepartmentDropdown(string organizationName)
        {
            try
            {
                Dictionary<string, string> deptDictionary = new Dictionary<string, string>();

                PeopleFinderT.PeopleFinderWebServiceSoapClient ws = new PeopleFinderT.PeopleFinderWebServiceSoapClient();

                DataSet ds = ws.GetDepartmentByOrganizationUnit(organizationName);

                // return ds.GetXml();

                List<string> department = new List<string>();

                foreach (DataRow item in ds.Tables[0].Rows)
                {
                    department.Add(item["department"].ToString());
                }
                // return orgs;



                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    string deptFullName = row["department"].ToString();
                    //string name = deptFullName.Split(new string[] { "=" }, StringSplitOptions.RemoveEmptyEntries)[1];
                    deptDictionary.Add(deptFullName + "_Key", deptFullName);
                }

                ////ddl.DataSource = organizationDictionary;
                ////ddl.DataTextField = "Value";
                ////ddl.DataValueField = "Key";
                ////ddl.DataBind();

                //dropDownorganization.DataSource = organizationDictionary;
                //dropDownorganization.DataTextField = "Value";
                //dropDownorganization.DataValueField = "Key";
                //dropDownorganization.DataBind();

                return deptDictionary;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }


        [WebMethod]
        public static List<ActiveDirectoryUserDetails> PopulateDepartmentUsers(string organization,string department)
        {
            try
            {
                PeopleFinderT.PeopleFinderWebServiceSoapClient ws = new PeopleFinderT.PeopleFinderWebServiceSoapClient();

                DataSet ds = ws.GetUsersByDepartmentAndOrganizationUnit(organization, department);  //ws.GetOrganizationUnitUsers(organization);
                List<ActiveDirectoryUserDetails> organizationUnitUsers = new List<ActiveDirectoryUserDetails>();

                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    ActiveDirectoryUserDetails user = new ActiveDirectoryUserDetails();

                    user.displayName = row["displayName"].ToString();
                    user.title = row["title"].ToString();
                    user.company = row["company"].ToString();
                    user.mail = row["mail"].ToString();
                    user.department = row["department"].ToString();
                    user.telephoneNumber = row["telephoneNumber"].ToString();
                    user.mobile = row["mobile"].ToString();
                    user.physicalDeliveryOfficeName = row["physicalDeliveryOfficeName"].ToString();
                    user.cn = row["cn"].ToString();
                    user.organizationUnit = row["organizationUnit"].ToString();
                    user.distinguishedName = row["distinguishedName"].ToString();
                    user.imageLocation = row["imageLocation"].ToString();

                    organizationUnitUsers.Add(user);

                }

                //Repeater1.DataSource = organizationUnitUsers;
                //Repeater1.DataBind();
                return organizationUnitUsers;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


    }
}