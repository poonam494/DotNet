﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace responsiveTrial
{
    public partial class ddTut : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //PopulateOrganization();

            //PopulateOrganizationDropdown();
        }

        internal void PopulateOrganization()
        {
            try
            {
                Dictionary<string, string> organizationDictionary = new Dictionary<string, string>();

                PeopleFinderT.PeopleFinderWebServiceSoapClient ws = new PeopleFinderT.PeopleFinderWebServiceSoapClient();

                DataSet ds =  ws.GetOrganizationUnits();

                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    string orgFullName = row["organizationname"].ToString();
                    string name = orgFullName.Split(new string[] { "=" }, StringSplitOptions.RemoveEmptyEntries)[1];
                    organizationDictionary.Add(name, name);
                }

               var list = new List<KeyValuePair<string,string>>();
              list.Add(new KeyValuePair<string,string>("http://www.google.com", "a"));
              list.Add(new KeyValuePair<string,string>("http://www.google.com", "b"));
              list.Add(new KeyValuePair<string,string>("http://www.google.com", "c"));

              string drowdownhtml = string.Empty;

              foreach (var element in list)
              {
                  drowdownhtml += " <ul><li><a href=" + element.Key + ">" + element.Value + "</a></li></ul>";
              }

              //options.Text = drowdownhtml;
              
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }


        [WebMethod]
        public static Dictionary<string,string> PopulateOrganizationDropdown()
        {
            try
            {
                Dictionary<string, string> organizationDictionary = new Dictionary<string, string>();

                PeopleFinderT.PeopleFinderWebServiceSoapClient ws = new PeopleFinderT.PeopleFinderWebServiceSoapClient();

                DataSet ds = ws.GetOrganizationUnits();

               // return ds.GetXml();

                List<string> orgs = new List<string>();

                foreach (DataRow item in ds.Tables[0].Rows)
                {
                    orgs.Add(item["organizationName"].ToString().Split(new string[] { "=" }, StringSplitOptions.RemoveEmptyEntries)[1] + ":" + item["organizationName"].ToString().Split(new string[] { "=" }, StringSplitOptions.RemoveEmptyEntries)[1]);
                }
               // return orgs;



                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    string orgFullName = row["organizationname"].ToString();
                    string name = orgFullName.Split(new string[] { "=" }, StringSplitOptions.RemoveEmptyEntries)[1];
                    organizationDictionary.Add(name + "_Key", name);
                }

                ////ddl.DataSource = organizationDictionary;
                ////ddl.DataTextField = "Value";
                ////ddl.DataValueField = "Key";
                ////ddl.DataBind();

                //dropDownorganization.DataSource = organizationDictionary;
                //dropDownorganization.DataTextField = "Value";
                //dropDownorganization.DataValueField = "Key";
                //dropDownorganization.DataBind();

                return organizationDictionary;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        protected void ddl_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                string organizationName = ddl.SelectedItem.Value.ToString();
                //PopulateOrganizationUsers(organizationName);
               

            }
            catch (Exception ex)
            {
            }
        }


    }
}