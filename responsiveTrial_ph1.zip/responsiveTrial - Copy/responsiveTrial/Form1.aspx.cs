﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace responsiveTrial
{
    public partial class Form1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            PopulateOrg();
        }

        protected void ddlOrg_SelectedIndexChanged(object sender, EventArgs e)
        {
            //PopulateOrg();
        }

        private void PopulateOrg()
        {
            Dictionary<string, string> organizationDictionary = new Dictionary<string, string>();

            PeopleFinderT.PeopleFinderWebServiceSoapClient ws = new PeopleFinderT.PeopleFinderWebServiceSoapClient();
            DataSet ds = ws.GetOrganizationUnits();

            foreach (DataRow row in ds.Tables[0].Rows)
            {
                string orgFullName = row["organizationname"].ToString();
                string name = orgFullName.Split(new string[] { "=" }, StringSplitOptions.RemoveEmptyEntries)[1];
                organizationDictionary.Add(name, name);
            }


            ddlOrg.DataSource = organizationDictionary;
            ddlOrg.DataValueField = "Key";
            ddlOrg.DataTextField = "Value";
            //OrgDropDownList.AppendDataBoundItems = true;
            ddlOrg.Items.Clear();

            ddlOrg.DataBind();
        }




    }
}