﻿using log4net;
using PeopleFinderR.Repository;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;

namespace PeopleFinderR
{
    /// <summary>
    /// Summary description for PeopleFinderWebService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]
    public class PeopleFinderWebService : System.Web.Services.WebService
    {
        ILog logger = log4net.LogManager.GetLogger("AppLogger");

        [WebMethod]
        public DataSet GetOrganizationUnits()
        {
            try
            {
                logger.Info("WS: Started in GetOrganizationUnits method");
                DataOperations operations = new DataOperations();
                DataSet orgs = operations.GetOrganizationUnits();
                logger.Info("WS: Completed GetOrganizationUnits method");

                return orgs;
            }
            catch(SoapException ex)
            {
                logger.Error("WS: SoapException: Error encountered while getting organization units",ex);
                throw ex;
            }
            catch (Exception ex)
            {
                logger.Error("WS: Error encountered while getting organization units", ex);
                throw ex;
            }
           
        }


        [WebMethod]
        public DataSet GetOrganizationUnitUsers(string organization)
        {
            try
            {
                logger.Info("WS: Started getting organization units users");
                DataOperations operations = new DataOperations();
                DataSet users = operations.GetOrganizationUnitUsers(organization);
                logger.Info("WS: Completed getting organization units users");
                
                return users;
            }
            catch (SoapException ex)
            {
                logger.Error("WS: SoapException: Error encountered while getting organization unit users", ex);
                throw ex;
            }
            catch (Exception ex)
            {
                logger.Error("WS: Error encountered while getting organization units users", ex);
                throw ex;
            }
           
        }

        [WebMethod]
        public DataSet GetDepartmentByOrganizationUnit(string organization)
        {
            try
            {
                logger.Info("WS: Started in getting department by organization unit");
                
                DataOperations operations = new DataOperations();
                DataSet departments = operations.GetDepartmentByOrganizationUnit(organization);

                logger.Info("WS: Completed in getting department by organization unit");

                return departments;
            }
            catch(SoapException ex)
            {
                logger.Error("WS: SoapException: Error encountered while getting department by organization unit",ex);
                throw ex;
            }
            catch (Exception ex)
            {
                logger.Error("WS: Error encountered while getting department by organization unit", ex);
                throw ex;
            }
        }


        [WebMethod]
        public DataSet GetUsersByDepartmentAndOrganizationUnit(string organization, string department)
        {
            try
            {
                logger.Info("WS: Started in getting users of department: " + department + " and organization : " + organization);

                DataOperations operations = new DataOperations();
                DataSet departments = operations.GetUsersByDepartmentAndOrganizationUnit(organization, department);

                logger.Info("WS: Completed getting users of department: " + department + " and organization : " + organization);

                return departments;
            }
            catch (SoapException ex)
            {
                logger.Error("WS: SoapException: Error encountered while getting users of department: " + department + " and organization : " + organization, ex);
                throw ex;
            }
            catch(Exception ex)
            {
                logger.Error("WS: Error encountered while getting users of department: " + department + " and organization : " + organization, ex);
                throw ex;
            }
           
        }


        [WebMethod]
        //public Dictionary<string,string> GetUsersByName(string Name)
        public List<string> GetUsersByName(string Name)
        {
            try
            {
                logger.Info("WS: Started in getting users by name : " + Name);

                DataOperations operations = new DataOperations();
                DataSet users = operations.GetUsersByName(Name);

                List<string> matchingUsers = new List<string>();

                //Dictionary<string, string> autoCompleteusers = new Dictionary<string, string>();
                foreach (DataRow item in users.Tables[0].Rows)
                {
                    //autoCompleteusers.Add(item["cn"].ToString(), item["displayName"].ToString());
                    matchingUsers.Add(item["displayName"].ToString() + ":" + item["cn"].ToString());
                }

                logger.Info("WS: Completed getting users by name : " + Name);

                return matchingUsers;
            }
            catch(SoapException ex)
            {
                logger.Error("WS: SoapException : Error encountered while getting user suggestion for name :" + Name ,ex);
                throw ex;
            }
            catch (Exception ex)
            {
                logger.Error("WS: Error encountered while getting user suggestion for name :" + Name, ex);
                throw ex;
            }
        }


        [WebMethod]
        //public Dictionary<string,string> GetUsersByName(string Name)
        public DataSet GetUsersDetailsByName(string Name)
        {
            try
            {
                logger.Info("WS: Started getting user details by name : " + Name);

                DataOperations operations = new DataOperations();
                DataSet user = operations.GetUsersDetailsByName(Name);

                //foreach (DataRow item in users.Tables[0].Rows)
                //{
                //    //autoCompleteusers.Add(item["cn"].ToString(), item["displayName"].ToString());
                //    autoCompleteusers.Add(item["displayName"].ToString() + "-" + item["cn"].ToString());
                //}

                logger.Info("WS: Completed getting user details by name : " + Name);
                return user;
            }
            catch(SoapException ex)
            {
                logger.Error("WS: SoapException : Error encountered while getting details for user :" + Name, ex);
                throw ex;
            }
            catch (Exception ex)
            {
                logger.Error("WS: Error encountered while getting details for user :" + Name, ex);
                throw ex;
            }
        }

        [WebMethod]
        public void SaveUserImageFilePath(string cn, string filePath) 
        {
            try
            {
                logger.Info("WS: Started saving " + filePath + " filepath for user : " + cn);
                
                DataOperations operations = new DataOperations();
                operations.SaveUserImageFilePath(cn, filePath);
                
                logger.Info("WS: Completed saving " + filePath + " filepath for user : " + cn);
            }
            catch(SoapException ex)
            {
                logger.Error("WS : SoapException : Error encountered while saving filepath : " + filePath + " of user: " + cn,ex);
                throw ex;
            }
            catch (Exception ex)
            {
                logger.Error("WS : Error encountered while saving filepath : " + filePath + " of user: " + cn, ex);                
                throw ex;
            }
            
        }

        [WebMethod]
        public void SaveFileDetails(string cn, string basepath, string filename) 
        {
            try
            {
                logger.Info("WS: Started saving " + filename + " filename in directory "+  basepath +" for user : " + cn);

                DataOperations operations = new DataOperations();
                operations.SaveFileDetails(cn, basepath, filename);

                logger.Info("WS: Completed saving " + filename + " filename in directory " + basepath + " for user : " + cn);
            }
            catch(SoapException ex)
            {
                logger.Error("WS : SoapException : Error encountered while saving file details basepath : " + basepath + " ,filename : " + filename + " of user: " + cn, ex);
                throw ex;
            }
            catch (Exception ex)
            {
                logger.Error("WS : Error encountered while saving file details basepath : " + basepath + " ,filename : " + filename + " of user: " + cn,ex);
                throw ex;
            }
        }

        [WebMethod]
        public DataSet GetUserAuthenticationDetails(string username) 
        {
            DataOperations operations = new DataOperations();
            DataSet userAuthenticationDetail = operations.GetUserAuthenticationDetails(username);

            return userAuthenticationDetail;
        }

    }
}
