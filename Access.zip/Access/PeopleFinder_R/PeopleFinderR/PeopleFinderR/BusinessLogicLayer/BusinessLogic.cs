﻿using log4net;
using PeopleFinderR.Entities;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;

namespace PeopleFinderR.BusinessLogicLayer
{
    public class BusinessLogic
    {
        PeopleFinderService.PeopleFinderWebServiceSoapClient ws;
        ILog logger = log4net.LogManager.GetLogger("AppLogger");

        public BusinessLogic()
        {
            ws = new PeopleFinderService.PeopleFinderWebServiceSoapClient();
        }

        internal Dictionary<string, string> PopulateOrganization()
        {
            try
            {
                logger.Info("BL: Started getting organization unit");
                Dictionary<string, string> organizationDictionary = new Dictionary<string, string>();

                DataSet ds = ws.GetOrganizationUnits();

                // ds.Tables["ActiveDirectoryorganizations"].DefaultView;
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    string orgFullName = row["organizationname"].ToString();
                    string name = orgFullName.Split(new string[] { "=" }, StringSplitOptions.RemoveEmptyEntries)[1];
                    organizationDictionary.Add(name, name);
                }

                logger.Info("BL: Completed getting organization unit from service");
                return organizationDictionary;
            }
            catch (Exception ex)
            {
                logger.Error("BL: Error encountered while getting organization",ex);
                return null;
            }

           
        }


        internal List<ActiveDirectoryUserDetails> PopulateOrganizationUsers(string organization)
        {
            try
            {
                logger.Info("BL: Started getting users of organization " + organization );

                DataSet ds = ws.GetOrganizationUnitUsers(organization);
                List<ActiveDirectoryUserDetails> users = new List<ActiveDirectoryUserDetails>();
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    ActiveDirectoryUserDetails user = new ActiveDirectoryUserDetails();
                    user.displayName = row["displayName"].ToString();
                    user.title = row["title"].ToString();
                    user.company = row["company"].ToString();
                    user.department = row["department"].ToString();
                    user.mail = row["mail"].ToString();
                    user.telephoneNumber = row["telephoneNumber"].ToString();
                    user.mobile = row["mobile"].ToString();
                    user.physicalDeliveryOfficeName = row["physicalDeliveryOfficeName"].ToString();
                    //user.imageLocation = row["imageLocation"].ToString();
                    user.cn = row["cn"].ToString();
                    user.distinguishedName = row["distinguishedName"].ToString();

                    //if (File.Exists(HttpContext.Current.Server.MapPath(Path.Combine("/ProfilePic/" + user.cn + ".png"))))  //hardcoded path no configuration

                    #region file from configured directory, no database path check
                    //string imageBasePath = ConfigurationManager.AppSettings["ImageBasePath"]; 
                    //if (File.Exists(HttpContext.Current.Server.MapPath(Path.Combine(imageBasePath + user.cn + ".png"))))
                    //{
                    //    user.imageLocation = Path.Combine(imageBasePath + user.cn + ".png");      //Path.Combine("/ProfilePic/" + user.cn + ".png");
                    //}
                    //else if (File.Exists(HttpContext.Current.Server.MapPath(Path.Combine(imageBasePath + user.cn + ".jpg"))))
                    //{
                    //    user.imageLocation = Path.Combine(imageBasePath + user.cn + ".jpg");      //Path.Combine("/ProfilePic/" + user.cn + ".png");
                    //}
                    //else 
                    //{
                    //    user.imageLocation = "themes/css/images/not_available.jpg";
                    //}
                    #endregion

                    #region file from DB check
                    string imageBasePath = ConfigurationManager.AppSettings["ImageBasePath"];
                    if (File.Exists(HttpContext.Current.Server.MapPath(Path.Combine(row["basepath"].ToString() + row["filename"]))))
                    {
                        //user.imageLocation = HttpContext.Current.Server.MapPath(Path.Combine(row["basepath"].ToString() + row["filename"]));      //Path.Combine("/ProfilePic/" + user.cn + ".png");
                        user.imageLocation = Path.Combine(row["basepath"].ToString() + row["filename"].ToString());      //Path.Combine("/ProfilePic/" + user.cn + ".png");
                    }
                    else
                    {
                        user.imageLocation = "themes/css/images/not_available.jpg";
                    }
                    #endregion

                    users.Add(user);
                }

                logger.Info("BL: Completed getting" + users.Count + " users of organization " + organization );
                return users;
            }
            catch (Exception ex)
            {
                logger.Error("BL: Error encountered while getting users of organization from service", ex);
            }
            return null;
        }

        internal Dictionary<string, string> PopulateDepartmentsByOrganizationUnit(string organization)
        {
            try
            {
                logger.Info("BL: Started getting departments of organization unit " + organization);
                DataSet ds = ws.GetDepartmentByOrganizationUnit(organization);
                Dictionary<string, string> departments = new Dictionary<string, string>();
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    if (!string.IsNullOrEmpty(row["department"].ToString()))
                        departments.Add(row["department"].ToString(), row["department"].ToString());
                }

                logger.Info("BL: Completed getting " + departments.Count + " department(s) of organization unit " + organization);
                return departments;
            }
            catch (Exception ex)
            {
                logger.Error("BL: Error encountered while getting departments of organization " + organization , ex);
            }
            return null;
        }


        internal List<ActiveDirectoryUserDetails> PopulateDepartmentOrganizationUsers(string organization, string department)
        {
            try
            {
                logger.Info("BL: Started getting " + department + " department users of organization " + organization );

                DataSet ds = ws.GetUsersByDepartmentAndOrganizationUnit(organization, department);
                List<ActiveDirectoryUserDetails> users = new List<ActiveDirectoryUserDetails>();
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    ActiveDirectoryUserDetails user = new ActiveDirectoryUserDetails();
                    user.displayName = row["displayName"].ToString();
                    user.title = row["title"].ToString();
                    user.company = row["company"].ToString();
                    user.department = row["department"].ToString();
                    user.mail = row["mail"].ToString();
                    user.telephoneNumber = row["telephoneNumber"].ToString();
                    user.mobile = row["mobile"].ToString();
                    user.physicalDeliveryOfficeName = row["physicalDeliveryOfficeName"].ToString();
                    //user.imageLocation = row["imageLocation"].ToString();
                    user.cn = row["cn"].ToString();
                    user.distinguishedName = row["distinguishedName"].ToString();

                    //if (File.Exists(HttpContext.Current.Server.MapPath(Path.Combine("/ProfilePic/" + user.cn + ".png"))))

                    #region file from configured directory, no database path check
                    //string imageBasePath = ConfigurationManager.AppSettings["ImageBasePath"];
                    //if (File.Exists(HttpContext.Current.Server.MapPath(Path.Combine(imageBasePath + user.cn + ".png"))))
                    //{
                    //    user.imageLocation = Path.Combine("/ProfilePic/" + user.cn + ".png");
                    //}
                    //else if (File.Exists(HttpContext.Current.Server.MapPath(Path.Combine(imageBasePath + user.cn + ".jpg"))))
                    //{
                    //    user.imageLocation = Path.Combine(imageBasePath + user.cn + ".jpg");      //Path.Combine("/ProfilePic/" + user.cn + ".png");
                    //}
                    //else
                    //{
                    //    user.imageLocation = "themes/css/images/not_available.jpg";
                    //}
                    #endregion

                    #region file from DB check
                    string imageBasePath = ConfigurationManager.AppSettings["ImageBasePath"];
                    if (File.Exists(HttpContext.Current.Server.MapPath(Path.Combine(row["basepath"].ToString() + row["filename"]))))
                    {
                        //user.imageLocation = HttpContext.Current.Server.MapPath(Path.Combine(row["basepath"].ToString() + row["filename"]));      //Path.Combine("/ProfilePic/" + user.cn + ".png");
                        user.imageLocation = Path.Combine(row["basepath"].ToString() + row["filename"].ToString());      //Path.Combine("/ProfilePic/" + user.cn + ".png");

                    }
                    else
                    {
                        user.imageLocation = "themes/css/images/not_available.jpg";
                    }
                    #endregion

                    users.Add(user);
                }

                logger.Info("BL: Completed getting " + users.Count + " users of " + department + " department of organization " + organization );

                return users;
            }
            catch (Exception ex)
            {
                logger.Error("BL: Error encountered while getting " + department + " department users of organization " + organization , ex);
            }
            return null;
        }

        internal List<ActiveDirectoryUserDetails> PopulateSelectedUser(string name)
        {
            try
            {
                logger.Info("BL: Started getting selected user " + name );

                DataSet ds = ws.GetUsersDetailsByName(name);
                List<ActiveDirectoryUserDetails> users = new List<ActiveDirectoryUserDetails>();
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    ActiveDirectoryUserDetails user = new ActiveDirectoryUserDetails();
                    user.displayName = row["displayName"].ToString();
                    user.title = row["title"].ToString();
                    user.company = row["company"].ToString();
                    user.department = row["department"].ToString();
                    user.mail = row["mail"].ToString();
                    user.telephoneNumber = row["telephoneNumber"].ToString();
                    user.mobile = row["mobile"].ToString();
                    user.physicalDeliveryOfficeName = row["physicalDeliveryOfficeName"].ToString();
                    //user.imageLocation = row["imageLocation"].ToString();
                    user.cn = row["cn"].ToString();
                    user.distinguishedName = row["distinguishedName"].ToString();

                    //if (File.Exists(HttpContext.Current.Server.MapPath(Path.Combine("/ProfilePic/" + user.cn + ".png"))))

                    #region file from configured directory, no database path check
                    //string imageBasePath = ConfigurationManager.AppSettings["ImageBasePath"];
                    //if (File.Exists(HttpContext.Current.Server.MapPath(Path.Combine(imageBasePath + user.cn + ".png"))))
                    //{
                    //    user.imageLocation = Path.Combine("/ProfilePic/" + user.cn + ".png");
                    //}
                    //else if (File.Exists(HttpContext.Current.Server.MapPath(Path.Combine(imageBasePath + user.cn + ".jpg"))))
                    //{
                    //    user.imageLocation = Path.Combine(imageBasePath + user.cn + ".jpg");      //Path.Combine("/ProfilePic/" + user.cn + ".png");
                    //}
                    //else
                    //{
                    //    user.imageLocation = "themes/css/images/not_available.jpg";
                    //}
                    #endregion

                    #region file from DB check
                    string imageBasePath = ConfigurationManager.AppSettings["ImageBasePath"];
                    if (File.Exists(HttpContext.Current.Server.MapPath(Path.Combine(row["basepath"].ToString() + row["filename"]))))
                    {
                        //user.imageLocation = HttpContext.Current.Server.MapPath(Path.Combine(row["basepath"].ToString() + row["filename"]));      //Path.Combine("/ProfilePic/" + user.cn + ".png");
                        user.imageLocation = Path.Combine(row["basepath"].ToString() + row["filename"].ToString());      //Path.Combine("/ProfilePic/" + user.cn + ".png");
                    }
                    else
                    {
                        user.imageLocation = "themes/css/images/not_available.jpg";
                    }
                    #endregion

                    users.Add(user);
                }

                logger.Info("BL: Completed getting selected user " + name );

                return users;
            }
            catch (Exception ex)
            {
                logger.Error("BL: Error encountered while getting selected user "+ name , ex);
            }
            return null;
        }

        internal void SaveFilePathLocation(string cn, string filePath) 
        {
            try
            {
                logger.Info("BL: Started saving file path location " + filePath + " for user: " + cn );
                ws.SaveUserImageFilePath(cn, filePath);
                logger.Info("BL: Completed saving file path location " + filePath + " for user: " + cn);
            }
            catch (Exception ex)
            {
                logger.Error("BL: Error encountered while saving file path location "+ filePath + " for user: " + cn  ,ex);
            }
        }


        internal void SaveFileDetails(string cn, string basepath, string filename)
        {
            try
            {
                logger.Info("BL: Started saving file details directory: " + basepath + " , filename: " + filename  + " for user: " + cn );
                ws.SaveFileDetails(cn, basepath, filename);
                logger.Info("BL: Completed saving file details directory: " + basepath + " , filename: " + filename + " for user: " + cn);
            }
            catch (Exception ex)
            {
                logger.Error("BL: Error encountered while saving file details directory: " + basepath + " , filename: " + filename + " for user: " + cn, ex);
            }
        }

        #region authentication 
        
        internal DataSet GetUserAuthenticationDetails(string username) 
        {
           DataSet userAuthDetail =  ws.GetUserAuthenticationDetails(username);
           return userAuthDetail;
        }


        public void PasswordEncryption(string pwd)
        {
            string salt = null;
            string hashedPwd = GeneratePasswordHash(pwd, out salt);
            //Response.Write("Salt:" + salt);
            //Response.Write("hash:" + hashedPwd);
        }

        public static string GetSaltString()
        {
            int SALT_SIZE = 24;
            RNGCryptoServiceProvider m_cryptoServiceProvider = new RNGCryptoServiceProvider();

            // Lets create a byte array to store the salt bytes
            byte[] saltBytes = new byte[SALT_SIZE];

            // lets generate the salt in the byte array
            m_cryptoServiceProvider.GetNonZeroBytes(saltBytes);

            // Let us get some string representation for this salt
            string saltString = Convert.ToBase64String(saltBytes); //Convert.ToString(saltBytes);
            //string saltString = Utility.GetString(saltBytes);

            // Now we have our salt string ready lets return it to the caller
            return saltString;
        }


        public string GeneratePasswordHash(string textPassword, out string salt)
        {
            salt = GetSaltString();

            string finalString = textPassword + salt;

            //Response.Write(GetPasswordHashAndSalt(finalString));

            return GetPasswordHashAndSalt(finalString);
        }


        public string GetPasswordHashAndSalt(string saltedPassword)
        {
            // Let us use SHA256 algorithm to 
            // generate the hash from this salted password
            SHA256 sha = new SHA256CryptoServiceProvider();
            byte[] dataBytes = Encoding.UTF8.GetBytes(saltedPassword);
            byte[] resultBytes = sha.ComputeHash(dataBytes);

            // return the hash string to the caller
            return Convert.ToBase64String(resultBytes);
        }


        #endregion
    }
}