﻿using log4net;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace PeopleFinderR.DataAccess
{
    public class ActiveDirectoryDataAccess : IDataAccess
    {
        ILog logger;

        public ActiveDirectoryDataAccess()
        {
            logger = log4net.LogManager.GetLogger("AppLogger");
        }

        private static SqlConnection GetConnection()
        {
            string connectionString = GetConnectionString();  //ConfigurationManager.ConnectionStrings["DatabaseConnectionString"].ConnectionString;
            SqlConnection connection = new SqlConnection(connectionString);
            return connection;
        }


        private static string GetConnectionString()
        {
            try 
	        {	
		        string prodEnvirorment = ConfigurationManager.AppSettings["IS_PROD"].ToString();
                string uatEnvirorment = ConfigurationManager.AppSettings["IS_UAT"].ToString();
                string devEnvirorment = ConfigurationManager.AppSettings["IS_DEV"].ToString();

                string dbConnectionString = null;

                if(Convert.ToBoolean(Convert.ToInt16(prodEnvirorment)))
                {
                    dbConnectionString = ConfigurationManager.ConnectionStrings["ProdDatabaseConnectionString"].ConnectionString;
                }
                else if (Convert.ToBoolean(Convert.ToInt16(uatEnvirorment)))
                {
                    dbConnectionString = ConfigurationManager.ConnectionStrings["UatDatabaseConnectionString"].ConnectionString;
                }
                else if (Convert.ToBoolean(Convert.ToInt16(devEnvirorment)))
                {
                    dbConnectionString = ConfigurationManager.ConnectionStrings["DevDatabaseConnectionString"].ConnectionString;
                }

                return dbConnectionString;
	        }
	        catch (Exception)
	        {
		        throw;
	        }
        }

        public DataSet GetOrganizations()
        {
            logger.Info("Started getting organization units from database");
            SqlConnection con;
            try
            {
                con = GetConnection();
                con.Open();
                using (SqlCommand cmd = new SqlCommand("select distinct(organizationName) from ActiveDirectoryorganizations", con))
                {
                    cmd.CommandType = CommandType.Text;
                    //cmd.ExecuteReader();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    logger.Info("Completed getting organization units from database");

                    return ds;
                }
            }
            catch (Exception ex)
            {
                logger.Error("Error encountered while fetching organization units from database", ex);
                throw ex;
            }
            finally
            {
                con = null;
            }
        }

        #region one table
        //public DataSet GetOrganizationUnitUsers(string organization)
        //{
        //    SqlConnection con;
        //    try
        //    {
        //        con = GetConnection();
        //        con.Open();
        //        //using (SqlCommand cmd = new SqlCommand("select * from ActiveDirectoryUserDataReplica where organizationUnit like '%'+@organization+'%'", con))
        //        using (SqlCommand cmd = new SqlCommand("select * from ActiveDirectoryUserDataReplica where organizationUnit like @organization", con))
        //        {
        //            cmd.CommandType = CommandType.Text;
        //            cmd.Parameters.AddWithValue("@organization", "%" + organization + "%"); //string.Format("%{0}%",organization)
        //            SqlDataAdapter da = new SqlDataAdapter(cmd);
        //            DataSet ds = new DataSet();
        //            da.Fill(ds);


        //            return ds;
        //        }

        //    }
        //    catch (Exception e)
        //    {
        //        throw;
        //    }
        //    finally
        //    {
        //        con = null;
        //    }
        //    return null;
        //}


        //public DataSet GetUsersByDepartmentAndOrganizationUnit(string organization, string department)
        //{
        //    SqlConnection con;
        //    try
        //    {
        //        con = GetConnection();
        //        con.Open();

        //        string query = null;
        //        bool isAllDepartment = false;

        //        if (department.Equals("All", StringComparison.InvariantCultureIgnoreCase))
        //        {
        //            query = "select * from ActiveDirectoryUserDataReplica where organizationUnit like @organization ";
        //            isAllDepartment = true;
        //        }
        //        else
        //        {
        //            query = "select * from ActiveDirectoryUserDataReplica where organizationUnit like @organization and department = @department";
        //        }

        //        using (SqlCommand cmd = new SqlCommand(query, con))
        //        {
        //            cmd.CommandType = CommandType.Text;
        //            cmd.Parameters.AddWithValue("@organization", "%" + organization + "%"); //string.Format("%{0}%",organization)
        //            if (!isAllDepartment)
        //            {
        //                cmd.Parameters.AddWithValue("@department", department);
        //            }
        //            SqlDataAdapter da = new SqlDataAdapter(cmd);
        //            DataSet ds = new DataSet();
        //            da.Fill(ds);

        //            return ds;
        //        }

        //    }
        //    catch (Exception e)
        //    {
        //        throw;
        //    }
        //    finally
        //    {
        //        con = null;
        //    }
        //    return null;
        //}


        //public DataSet GetUsersDetailsByName(string Name)
        //{
        //    SqlConnection con;
        //    try
        //    {
        //        con = GetConnection();
        //        con.Open();

        //        using (SqlCommand cmd = new SqlCommand("select * from ActiveDirectoryUserDataReplica where cn = @cn", con))
        //        {
        //            cmd.CommandType = CommandType.Text;
        //            cmd.Parameters.AddWithValue("@cn", Name); //string.Format("%{0}%",organization)
        //            SqlDataAdapter da = new SqlDataAdapter(cmd);
        //            DataSet ds = new DataSet();
        //            da.Fill(ds);

        //            return ds;
        //        }

        //    }
        //    catch (Exception e)
        //    {
        //        throw;
        //    }
        //    finally
        //    {
        //        con = null;
        //    }
        //    return null;
        //}

        #endregion

        public DataSet GetDepartmentByOrganizationUnit(string organization)
        {
            SqlConnection con;
            try
            {
                logger.Info("Started getting departments for organization units: " + organization + " from database");

                con = GetConnection();
                con.Open();

                using (SqlCommand cmd = new SqlCommand("select distinct(department) from ActiveDirectoryUserDataReplica where organizationUnit like @organization", con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@organization", "%" + organization + "%"); //string.Format("%{0}%",organization)
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    logger.Info("Completed getting departments for organization units: "+ organization + " from database");
                    return ds;
                }

            }
            catch (Exception ex)
            {
                logger.Error("Error encountered while getting departments of organization "+ organization +" from database",ex);
                throw ex;
            }
            finally
            {
                con = null;
            }
        }


        public DataSet GetUsersByName(string searchInput)
        {
            SqlConnection con;
            try
            {
                logger.Info("Started getting usernames for search criteria :" + searchInput + " from database");
                
                con = GetConnection();
                con.Open();

                string query = null;
                bool isNumberSearch = true;

                foreach (char c in searchInput)
                {
                    if (c < '0' || c > '9')
                    {
                        isNumberSearch = false;
                    }
                }

                if (!isNumberSearch)
                {
                    query = "select displayName,cn from ActiveDirectoryUserDataReplica where displayName like @seachInput";
                    logger.Debug("search criteria is name: " + searchInput);
                }
                else
                {
                    query = "select displayName,cn from ActiveDirectoryUserDataReplica where telephoneNumber like @seachInput";
                    logger.Debug("search criteria is telephone number: " + searchInput + " from database");
                }

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@seachInput", "%" + searchInput + "%"); //string.Format("%{0}%",organization)
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    logger.Info("Completed getting usernames for search criteria :" + searchInput + " from database");

                    return ds;
                }
            }
            catch (Exception ex)
            {
                logger.Error("Error encountered while getting usernames for search input: " + searchInput  + " from database", ex);
                throw ex;
            }
            finally
            {
                con = null;
            }
        }


        public void SaveUserImageFilePath(string cn,string filePath) 
        {
            SqlConnection con;
            try
            {
                logger.Info("Started saving filepath " + filePath + " for user " + cn + " in database");
                con = GetConnection();
                con.Open();

                using (SqlCommand cmd = new SqlCommand("Update ActiveDirectoryUserDataReplica Set imageLocation = @filepath where cn = @cn", con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@cn", cn);
                    cmd.Parameters.AddWithValue("@filepath", filePath);

                    cmd.ExecuteNonQuery();
                }

                logger.Info("Completed saving filepath " + filePath + " for user " + cn + " in database");
            }
            catch (Exception ex)
            {
                logger.Error("Error encountered while saving filepath " + filePath + " for user " + cn + " in database",ex);
                throw;
            }
            finally 
            {
                con = null;
            }
        }

        public void SaveFileDetails(string cn, string basepath, string filename) 
        {
            SqlConnection con;
            try
            {
                logger.Info("Started saving filename " + filename + " in directory " + basepath + " for user:" + cn + " in database");

                con = GetConnection();
                con.Open();

                using (SqlCommand cmd = new SqlCommand("spSaveUserImageFileDetails", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@cn", cn);
                    cmd.Parameters.AddWithValue("@basepath", basepath);
                    cmd.Parameters.AddWithValue("@filename", filename);

                    cmd.ExecuteNonQuery();
                }
                
                logger.Info("Completed saving filename " + filename + " in directory " + basepath + " for user:" + cn + " in database");
            }
            catch (Exception ex)
            {
                logger.Error("Error encountered while saving filename " + filename + " in directory " + basepath + " for user:" + cn + " in database",ex);
                throw;
            }
            finally 
            {
                con = null;
            }
        }

        #region File details from DB
        public DataSet GetOrganizationUnitUsers(string organization)
        {
            SqlConnection con;
            try
            {
                logger.Info("Started getting users for organization unit: " + organization + " from database");

                con = GetConnection();
                con.Open();
                //using (SqlCommand cmd = new SqlCommand("select * from ActiveDirectoryUserDataReplica where organizationUnit like '%'+@organization+'%'", con))
                string query = "select users.*,userimage.basepath,userimage.filename from ActiveDirectoryUserDataReplica as users left outer join UserImageFileDetails as userimage on users.cn = userimage.cn where users.organizationUnit like @organization";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@organization", "%" + organization + "%"); //string.Format("%{0}%",organization)
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    logger.Info("Completed getting users for organization unit: " + organization + " from database");

                    return ds;
                }
            }
            catch (Exception ex)
            {
                logger.Error("Error encountered while getting users for organization unit: " + organization + " from database",ex);
                throw;
            }
            finally
            {
                con = null;
            }
        }



        public DataSet GetUsersByDepartmentAndOrganizationUnit(string organization, string department)
        {
            SqlConnection con;
            try
            {
                logger.Info("Started getting users for organization: " + organization + " and department: " + department + " from database");
                con = GetConnection();
                con.Open();

                string query = null;
                bool isAllDepartment = false;

                if (department.Equals("All", StringComparison.InvariantCultureIgnoreCase))
                {
                    query = "select users.*,userimage.basepath,userimage.filename from ActiveDirectoryUserDataReplica as users left outer join UserImageFileDetails as userimage on users.cn = userimage.cn where users.organizationUnit like @organization ";
                    isAllDepartment = true;
                }
                else
                {
                    query = "select users.*,userimage.basepath,userimage.filename from ActiveDirectoryUserDataReplica as users left outer join UserImageFileDetails as userimage on users.cn = userimage.cn where users.organizationUnit like @organization and users.department = @department";
                }

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@organization", "%" + organization + "%"); //string.Format("%{0}%",organization)
                    if (!isAllDepartment)
                    {
                        cmd.Parameters.AddWithValue("@department", department);
                    }
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    logger.Info("Completed getting users for organization : " + organization + " and department: " + department + " from database");

                    return ds;
                }

            }
            catch (Exception ex)
            {
                logger.Error("Error encountered while getting users for organization : " + organization + " and department: " + department + " from database", ex);
                throw;
            }
            finally
            {
                con = null;
            }
            return null;
        }


        public DataSet GetUsersDetailsByName(string Name)
        {
            SqlConnection con;
            try
            {
                logger.Info("Started getting user details for name :" + Name + " from database");
                con = GetConnection();
                con.Open();

                using (SqlCommand cmd = new SqlCommand("select users.*,userimage.basepath,userimage.filename from ActiveDirectoryUserDataReplica as users left outer join UserImageFileDetails as userimage on users.cn = userimage.cn where users.cn = @cn", con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@cn", Name); //string.Format("%{0}%",organization)
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    logger.Info("Completed getting user details for name :" + Name + " from database");

                    return ds;
                }
            }
            catch (Exception ex)
            {
                logger.Error("Error encountered while getting user details for name :" + Name + " from database",ex);
                throw;
            }
            finally
            {
                con = null;
            }
        }

        #endregion


        public DataSet GetUserAuthenticationDetails(string username) 
        {
            SqlConnection con;

            try
            {
                logger.Info("Started getting user details of " + username +" for authentication from database");
                con = GetConnection();
                con.Open();

                using (SqlCommand cmd = new SqlCommand("GetUserAuthenticationDetail",con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@username", username);

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    logger.Info("Completed getting user details of " + username + " for authentication from database");

                    return ds;
                }

            }
            catch (Exception ex)
            {
                logger.Error("Error encountered while getting user details of " + username + " for authentication from database");
                throw ex;
            }


            return null;
        }

    
    }
}