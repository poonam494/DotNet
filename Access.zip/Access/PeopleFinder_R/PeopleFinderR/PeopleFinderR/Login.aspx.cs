﻿using PeopleFinderR.BusinessLogicLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PeopleFinderR
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                Session["isAunthenticated"] = false;

                string queryParameters = Server.UrlDecode(Request.QueryString["queryString"]);
                
                if (Request.QueryString["session"]!= null)
                {
                    if (Request.QueryString["session"].ToString() == "Timeout")
                    {
                        lblErrorMessage.Text = "Session Timeout. Please login";
                        var newclassValue = lblErrorMessage.Attributes["class"].Replace("display", "");
                        lblErrorMessage.Attributes["class"] = newclassValue;
                    }
                }
            }
        }


        public void btnLogin_OnClientClick(object sender, EventArgs e)
        {
            string domainName = GetDomainName(txtUsername.Text);
            string userName = GetUsername(txtUsername.Text);
            IntPtr token = IntPtr.Zero;

            BusinessLogic businessLogic = new BusinessLogic();

            bool isAuthenticate = CheckLogin(userName,txtPassword.Text);

            if (isAuthenticate) 
            {
                Session["isAdmin"] = "Yes";
                Session["isAunthenticated"] = true;
            }

            //PasswordEncryption(txtPassword.Text);

            if (Session["isAdmin"] != null && Session["isAdmin"] == "Yes")
            {
                Response.Redirect("PeopleSearch.aspx");
            }
            else
            {
                bool result = LogonUser(userName, domainName, txtPassword.Text, 2, 0, ref token);


                if (result)
                {

                    //if (string.IsNullOrEmpty(Request.QueryString["ReturnUrl"]))
                    //{
                    //    FormsAuthentication.RedirectFromLoginPage(txtUserName.Text, false);
                    //}
                    //else
                    //{

                    string errorMsgStyles = "display line-style6";
                    lblErrorMessage.Attributes.Remove("class");
                    lblErrorMessage.Attributes.Add("class", errorMsgStyles);
                    lblErrorMessage.Text = "";

                    FormsAuthentication.SetAuthCookie(txtUsername.Text, false);
                    //Session["isAdmin"] = "Yes";
                    Response.Redirect("PeopleSearch.aspx");
                    //}
                }
                else
                {
                    //If not authenticated then display an error message
                    //Response.Write("Invalid username or password.");

                    var newclassValue = lblErrorMessage.Attributes["class"].Replace("display", "");
                    lblErrorMessage.Attributes["class"] = newclassValue;
                    lblErrorMessage.Text = "Invalid username or password.";

                }
            }
        }

     

        [DllImport("ADVAPI32.dll", EntryPoint = "LogonUserW", SetLastError = true, CharSet = CharSet.Auto)]
        public static extern bool LogonUser(string lpszUsername, string lpszDomain,
            string lpszPassword, int dwLogonType, int dwLogonProvider, ref IntPtr phToken);


        public static string GetDomainName(string usernameDomain)
        {
            if (string.IsNullOrEmpty(usernameDomain))
            {
                throw (new ArgumentException("Argument can't be null.", "usernameDomain"));
            }
            if (usernameDomain.Contains("\\"))
            {
                int index = usernameDomain.IndexOf("\\");
                return usernameDomain.Substring(0, index);
            }
            else if (usernameDomain.Contains("@"))
            {
                int index = usernameDomain.IndexOf("@");
                return usernameDomain.Substring(index + 1);
            }
            else
            {
                return "";
            }
        }

        public static string GetUsername(string usernameDomain)
        {
            if (string.IsNullOrEmpty(usernameDomain))
            {
                throw (new ArgumentException("Argument can't be null.", "usernameDomain"));
            }
            if (usernameDomain.Contains("\\"))
            {
                int index = usernameDomain.IndexOf("\\");
                return usernameDomain.Substring(index + 1);
            }
            else if (usernameDomain.Contains("@"))
            {
                int index = usernameDomain.IndexOf("@");
                return usernameDomain.Substring(0, index);
            }
            else
            {
                return usernameDomain;
            }
        }


        #region Authentication

        public void PasswordEncryption(string pwd) 
        {
            string salt = null;
            string hashedPwd =  GeneratePasswordHash(pwd, out salt);
            //Response.Write("Salt:" + salt);
            //Response.Write("hash:" + hashedPwd);
        }

        public static string GetSaltString()
        {
             int SALT_SIZE = 24;
             RNGCryptoServiceProvider m_cryptoServiceProvider = new RNGCryptoServiceProvider();

            // Lets create a byte array to store the salt bytes
            byte[] saltBytes = new byte[SALT_SIZE];

            // lets generate the salt in the byte array
            m_cryptoServiceProvider.GetNonZeroBytes(saltBytes);

            // Let us get some string representation for this salt
            string saltString = Convert.ToBase64String(saltBytes); //Convert.ToString(saltBytes);
            //string saltString = Utility.GetString(saltBytes);

            // Now we have our salt string ready lets return it to the caller
            return saltString;
        }

        
        public string GeneratePasswordHash(string textPassword, out string salt)
        {
            salt = GetSaltString();

            string finalString = textPassword + salt;

            //Response.Write(GetPasswordHashAndSalt(finalString));

            return GetPasswordHashAndSalt(finalString);
        }


        public string GetPasswordHashAndSalt(string saltedPassword)
        {
            // Let us use SHA256 algorithm to 
            // generate the hash from this salted password
            SHA256 sha = new SHA256CryptoServiceProvider();
            byte[] dataBytes = Encoding.UTF8.GetBytes(saltedPassword);
            byte[] resultBytes = sha.ComputeHash(dataBytes);

            // return the hash string to the caller
            return Convert.ToBase64String(resultBytes);
        }


        private bool CheckLogin(string userName, string password)
        {
            DataSet ds = GetDetailsForUserAuthentication(userName);

            if(ds.Tables[0].Rows[0]["username"].ToString().Equals(userName,StringComparison.InvariantCultureIgnoreCase))
            {
                string dbSalt = ds.Tables[0].Rows[0]["salt"].ToString();
                string dbHash = ds.Tables[0].Rows[0]["encryptedPassword"].ToString();

                //string computePassword = password + dbSalt;
                //string computedPasswordHash  = GetPasswordHashAndSalt(computePassword);

                return IsPasswordMatch(password,dbSalt,dbHash);
            }

            return false;
        }

        private DataSet GetDetailsForUserAuthentication(string userName)
        {
            BusinessLogic busnicessLogic = new BusinessLogic();
            DataSet ds = busnicessLogic.GetUserAuthenticationDetails(userName);
            return ds;
        }

        public bool IsPasswordMatch(string password, string dbSalt, string dbHash)
        {
            string computePassword = password + dbSalt;
            return dbHash == GetPasswordHashAndSalt(computePassword);
        }
       
        #endregion

    }
}