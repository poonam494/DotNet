﻿using log4net;
using PeopleFinderR.BusinessLogicLayer;
using PeopleFinderR.Entities;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PeopleFinderR
{
    public partial class PeopleSearch : System.Web.UI.Page
    {
        ILog logger = log4net.LogManager.GetLogger("AppLogger");

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
              
                //if (Context.Session != null)
                //{
                //    if (Session.IsNewSession)
                //    {
                //        string cookieHeader = Request.Headers["Cookie"];
                //        //checking if session timedout then redirect to ogin
                //        if ((null != cookieHeader) && (cookieHeader.IndexOf("ASP.NET_SessionId") >= 0))
                //        {
                //            string queryString = Server.UrlEncode("session=Timeout");
                //            Response.Redirect("Login.aspx?" + queryString);
                //            //show msg for session ended. login again.
                //        }
                //        else 
                //        {
                //            Response.Redirect("Login.aspx");
                //        }
                //    }
                //    else if (Convert.ToBoolean(Session["isAunthenticated"].ToString()))
                //    {
                //        PopulateOrganization();
                //    }
                //    else 
                //    {
                //        Response.Redirect("Login.aspx");
                //    }
                //} 


                PopulateOrganization();

            }
        }

        private void PopulateOrganization()
        {
            try
            {
                logger.Info("Start Populating organization unit");
                BusinessLogic businessLogic = new BusinessLogic();
                Dictionary<string, string> organizationDictionary = businessLogic.PopulateOrganization();

                OrgDropDownList.DataSource = organizationDictionary;
                OrgDropDownList.DataValueField = "Key";
                OrgDropDownList.DataTextField = "Value";
                //OrgDropDownList.AppendDataBoundItems = true;
                OrgDropDownList.Items.Clear();

                OrgDropDownList.DataBind();

                logger.Info("Completed populating organization unit");
            }
            catch(Exception ex)
            {
                logger.Error("Error encountered while populating organization units", ex.InnerException);
            }
        }

        protected void OrgDropDownList_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                logger.Info("Started populating users for selected organization");
                string organizationName = OrgDropDownList.SelectedItem.Value.ToString();
                logger.Info("Selected organization "+ organizationName + " to get all users belonging to it");

                if (OrgDropDownList.SelectedIndex == 0)
                {
                    //departmentDropDownList.Visible = false;
                    //lblDepartment.Visible = false;

                    departmentDropDownList.Items.Clear();
                    departmentDropDownList.DataBind();

                    logger.Info("Not selected any organization");
                    repeaterSearchResults.DataSource = null;
                    repeaterSearchResults.DataBind();

                    SearchUpdatePanel.Update();
                    return;
                }

                int userCount = PopulateOranizationUsers(organizationName);
                logger.Info("The users count on selection of organization " + organizationName + " is :" + userCount);

                PopulateDepartmentsByOrganizationUnit(organizationName);

                txtSearchInput.Text = "";
                hfUserSelected.Value = "";
                hfUserSelectedCN.Value = "";

                if (userCount > 0)
                {
                    string styles = "display line-style6";
                    lblMessage.Attributes.Remove("class");
                    lblMessage.Attributes.Add("class", styles);
                    lblMessage.Text = "";

                    string errorMsgStyles = "display line-style6";
                    lblErrorMessage.Attributes.Remove("class");
                    lblErrorMessage.Attributes.Add("class", errorMsgStyles);
                    lblErrorMessage.Text = "";

                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "scrollScreen", "scrollDownTo()", true);
                }
                else
                {
                    logger.Info("Start clearing error message and displaying message for no users");
                    string errorMsgStyles = "display line-style6";
                    lblErrorMessage.Attributes.Remove("class");
                    lblErrorMessage.Attributes.Add("class", errorMsgStyles);
                    lblErrorMessage.Text = "";

                    var newclassValue = lblMessage.Attributes["class"].Replace("display", "");
                    lblMessage.Attributes["class"] = newclassValue;
                    lblMessage.Text = "No users found";
                    logger.Info("Completed clearing error message and displaying message for no users");
                    
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "scrollScreen", "scrollDownTo()", true);
                }
                logger.Info("Completed populating users for selected organization");

            }
            catch (Exception)
            {
                logger.Error("Error encountered on populating users for selected organization");
                
            }
            
        }


        private int PopulateOranizationUsers(string organizationName)
        {
            try
            {
                logger.Info("Started fetching users to poulate for organization " + organizationName);

                BusinessLogic businessLogic = new BusinessLogic();
                List<ActiveDirectoryUserDetails> userList = businessLogic.PopulateOrganizationUsers(organizationName);
                repeaterSearchResults.DataSource = userList;
                repeaterSearchResults.DataBind();
                
                SearchUpdatePanel.Update();

                logger.Info("Completed fetching users to populte users to populate for organization");

                return userList.Count;
            }
            catch (Exception)
            {
                logger.Error("Error encountered while fetching users to populate for organization " + organizationName);
                return -1;
            }
           
        }

        private void PopulateDepartmentsByOrganizationUnit(string organizationName)
        {
            try
            {
                logger.Info("Started populating departments for organization unit :" + organizationName);

                BusinessLogic businessLogic = new BusinessLogic();
                Dictionary<string, string> departments = businessLogic.PopulateDepartmentsByOrganizationUnit(organizationName);
                departmentDropDownList.Items.Clear();
                departmentDropDownList.DataSource = departments;
                departmentDropDownList.DataTextField = "Key";
                departmentDropDownList.DataValueField = "Value";
                departmentDropDownList.AppendDataBoundItems = true;
                departmentDropDownList.Items.Insert(0, new ListItem("All", "All"));
                departmentDropDownList.SelectedIndex = 0;
                departmentDropDownList.DataBind();

                departmentDropDownList.Visible = true;
                lblDepartment.Visible = true;

                logger.Info("Completed populating departments for organization unit :" + organizationName);
            }
            catch (Exception ex)
            {
                logger.Error("Error encountered while populating departement for organization " + organizationName,ex.InnerException); 
            }

        }


        public void Submit_Click(object sender, EventArgs e)
        {
            try
            {
                logger.Info("Started to populate selected user from suggestions");
                string userName = Request.Form[txtSearchInput.UniqueID];
                string selectedUser = Request.Form[hfUserSelected.UniqueID];
                string userSelectedCN = Request.Form[hfUserSelectedCN.UniqueID];

                txtSearchInput.Text = selectedUser;

                BusinessLogic businessLogic = new BusinessLogic();
                List<ActiveDirectoryUserDetails> userList = businessLogic.PopulateSelectedUser(userSelectedCN);

                repeaterSearchResults.DataSource = userList;
                repeaterSearchResults.DataBind();

                OrgDropDownList.SelectedIndex = 0;
                departmentDropDownList.Items.Clear();

                //departmentDropDownList.Visible = false;
                //lblDepartment.Visible = false;

                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "scrollScreen", "scrollDownTo()", true);

                logger.Info("Completed to populate selected user from suggestions");
            }
            catch (Exception ex)
            {
                logger.Error("Error encountered while populating selected user " + txtSearchInput.Text +" from selection",ex);
            }
        }

        protected void OrgDropDownList_DataBound(object sender, EventArgs e)
        {
            OrgDropDownList.Items.Insert(0, new ListItem("--Select--", "0"));
            OrgDropDownList.SelectedIndex = 0;
        }

        protected void departmentDropDownList_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                logger.Info("Started populating users for selected department of organization");
                
                string organizationName = OrgDropDownList.SelectedItem.Value.ToString();
                string departmentName = departmentDropDownList.SelectedItem.Value.ToString();
                logger.Info("for organization " + organizationName + "  department " + departmentName);

                BusinessLogic businessLogic = new BusinessLogic();
                List<ActiveDirectoryUserDetails> userList;
                userList = businessLogic.PopulateDepartmentOrganizationUsers(organizationName, departmentName);

                logger.Info("Populating " + userList.Count + "users for organization " + organizationName + " and department " + departmentName);

                repeaterSearchResults.DataSource = userList;
                repeaterSearchResults.DataBind();

                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "scrollScreen", "scrollDownTo()", true);

                logger.Info("Completed Populating users for organization " + organizationName + " and department " + departmentName);
            }
            catch (Exception ex)
            {
                logger.Error("Error encountered while populating users for department of organization ",ex);
            }
        }


        protected void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                logger.Info("Started searching users for selected organization and department");
                string organizationSelected = OrgDropDownList.SelectedItem.Value.ToString();
                string department = departmentDropDownList.SelectedItem == null ? null : departmentDropDownList.SelectedItem.Value.ToString();

                if (OrgDropDownList.SelectedIndex == 0)
                {
                    //lblMessage.CssClass.Replace("display", "");
                    //lblMessage.Text = "Select organization unit";

                    var newclassValue = lblErrorMessage.Attributes["class"].Replace("display", "");
                    lblErrorMessage.Attributes["class"] = newclassValue;
                    lblErrorMessage.Text = "* Select organization unit";
                }
                else
                {
                    BusinessLogic businessLogic = new BusinessLogic();
                    List<ActiveDirectoryUserDetails> userList;

                    userList = businessLogic.PopulateDepartmentOrganizationUsers(organizationSelected, department);

                    //lblMessage.CssClass = "display";
                    //lblMessage.Text = "";

                    string styles = "display line-style6";
                    lblErrorMessage.Attributes.Remove("class");
                    lblErrorMessage.Attributes.Add("class", styles);
                    lblErrorMessage.Text = "";

                    repeaterSearchResults.DataSource = userList;
                    repeaterSearchResults.DataBind();
                }
                logger.Info("Completed searching users for selected organization and department");
            }
            catch (Exception ex)
            {
                logger.Error("Error encountered while searching users for organization and department",ex);
            }
        }


        protected void btnModalUploadImage_Click(object sender, EventArgs e)
        {
            try
            {
                logger.Info("Started uploading profile image of user to directory");
                Button btn = (Button)sender;

                //unique cn value
                var documentId = btn.CommandArgument;    //btn.CommandArgument;  //modal_btnUploadImage

                //Get the Repeater Item reference
                RepeaterItem item = btn.NamingContainer as RepeaterItem;

                var fileSelection = (FileUpload)item.FindControl("modal_fileUpload");

                var filename = fileSelection.PostedFile.FileName;

                if (fileSelection.PostedFile != null && fileSelection.PostedFile.ContentLength > 0)
                {
                    //getting file extension
                    string extension = Path.GetExtension(fileSelection.PostedFile.FileName);

                    if (extension.ToLower().Equals(".jpg", StringComparison.InvariantCultureIgnoreCase) || extension.ToLower().Equals(".png", StringComparison.InvariantCultureIgnoreCase))
                    {
                        //renaming uploaded file to cn unique name
                        //fileSelection.PostedFile.SaveAs(Server.MapPath(Path.Combine("~/ProfilePic/", documentId + extension))); // + documentId + extension);

                        //fetching location from basepath & cn unique naming
                        string imageBasePath = ConfigurationManager.AppSettings["ImageBasePath"];
                        fileSelection.PostedFile.SaveAs(Server.MapPath(Path.Combine(imageBasePath, documentId + extension))); // + documentId + extension);

                        //saving entire file location with directory
                        //string fileSavePathLocation = Server.MapPath(Path.Combine("~/ProfilePic/", documentId + extension));
                        //BusinessLogic businessLogic = new BusinessLogic();
                        //businessLogic.SaveFilePathLocation(documentId, fileSavePathLocation);

                        //saving  file location directory and filename differently
                        BusinessLogic businessLogic = new BusinessLogic();
                        businessLogic.SaveFileDetails(documentId, imageBasePath, documentId + extension);

                        List<ActiveDirectoryUserDetails> userList;
                        if (!string.IsNullOrEmpty(txtSearchInput.Text.ToString()))
                        {
                            userList = businessLogic.PopulateSelectedUser(documentId);
                        }
                        else
                        {
                            string organizationName = OrgDropDownList.SelectedItem.Value.ToString();
                            string departmentName = departmentDropDownList.SelectedItem.Value.ToString();

                            userList = businessLogic.PopulateDepartmentOrganizationUsers(organizationName, departmentName);
                        }

                        repeaterSearchResults.DataSource = userList;
                        repeaterSearchResults.DataBind();

                        string msg = "File uploaded successfully";
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "MessageDialog", "ShowMessageDialog('" + msg + "')", true);
                    }
                    else
                    {

                        //string msg = "Please select a file having jpg or png file format";
                        //string messageId = documentId;

                        //string messageId = "lblUploadMsg-" + documentId;



                        //Label uploadMsg = new Label();
                        //Label msglabel = (Label)item.FindControl("lblUploadMsg");
                        ////msglabel.ID = messageId;
                        //var newclassValue = msglabel.Attributes["class"].Replace("display", "");
                        //msglabel.Attributes["class"] = newclassValue;

                        //msglabel.Text = msg;

                        //  ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "DisplayModal", "DisplayModal('" + documentId + "');", true);
                        //  ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "MessageDialog", "ShowMessageDialog('" + msg + "')", true);
                    }

                }
                else
                {
                    string msg = "Please select a valid file";
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "MessageDialog", "ShowMessageDialog('" + msg + "')", true);

                }

                logger.Info("Completed uploading profile image of user :" + documentId);
            }
            catch (Exception ex)
            {
                logger.Error("Error encountered while uploading profile image of user",ex);
            }

            
        }

        protected void repeaterSearchResults_ItemCreated(object sender, RepeaterItemEventArgs e)
        {
            ScriptManager scriptManager = ScriptManager.GetCurrent(this);
            //Button btn = e.Item.FindControl("btnUploadImage") as Button;
            ////if (btn != null)
            ////{
            ////    btn.Click += btnUploadImage_Click;
            ////    scriptManager.RegisterPostBackControl(btn);
            ////}

            Button modalBtn = e.Item.FindControl("modal_btnUploadImage") as Button;
            if (modalBtn != null)
            {
                modalBtn.Click += btnModalUploadImage_Click;
                scriptManager.RegisterPostBackControl(modalBtn);
            }

        }

        protected void repeaterSearchResults_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (Session["isAdmin"] != null)
            {
                if (Session["isAdmin"].Equals("Yes"))
                {
                    Button btn = e.Item.FindControl("btn_showModal") as Button;
                    btn.Visible = true;
                }
            }
        }
    }
}