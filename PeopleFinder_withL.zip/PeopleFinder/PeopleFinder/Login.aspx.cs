﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PeopleFinder
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        public void btnLogin_OnClientClick(object sender, EventArgs e) 
        {
            string domainName = GetDomainName(txtUserName.Text);
            string userName = GetUsername(txtUserName.Text);
            IntPtr token = IntPtr.Zero;

            bool result = LogonUser(userName, domainName, txtPassword.Text, 2, 0, ref token);


            if (result)
            {
               
                //if (string.IsNullOrEmpty(Request.QueryString["ReturnUrl"]))
                //{
                //    FormsAuthentication.RedirectFromLoginPage(txtUserName.Text, false);
                //}
                //else
                //{
                    FormsAuthentication.SetAuthCookie(txtUserName.Text, false);
                    Response.Redirect("PeopleSearch.aspx");
                //}
            }
            else
            {
                //If not authenticated then display an error message
                Response.Write("Invalid username or password.");
            }

        }

        [DllImport("ADVAPI32.dll", EntryPoint = "LogonUserW", SetLastError = true, CharSet = CharSet.Auto)]
        public static extern bool LogonUser(string lpszUsername, string lpszDomain,
            string lpszPassword, int dwLogonType, int dwLogonProvider, ref IntPtr phToken);


        public static string GetDomainName(string usernameDomain)
        {
            if (string.IsNullOrEmpty(usernameDomain))
            {
                throw (new ArgumentException("Argument can't be null.", "usernameDomain"));
            }
            if (usernameDomain.Contains("\\"))
            {
                int index = usernameDomain.IndexOf("\\");
                return usernameDomain.Substring(0, index);
            }
            else if (usernameDomain.Contains("@"))
            {
                int index = usernameDomain.IndexOf("@");
                return usernameDomain.Substring(index + 1);
            }
            else
            {
                return "";
            }
        }

        public static string GetUsername(string usernameDomain)
        {
            if (string.IsNullOrEmpty(usernameDomain))
            {
                throw (new ArgumentException("Argument can't be null.", "usernameDomain"));
            }
            if (usernameDomain.Contains("\\"))
            {
                int index = usernameDomain.IndexOf("\\");
                return usernameDomain.Substring(index + 1);
            }
            else if (usernameDomain.Contains("@"))
            {
                int index = usernameDomain.IndexOf("@");
                return usernameDomain.Substring(0, index);
            }
            else
            {
                return usernameDomain;
            }
        }  


    }
}