﻿using PeopleFinder.BusinessLogicLayer;
using PeopleFinder.Entities;
using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using System.Web.UI;

namespace PeopleFinder
{
    public partial class PeopleSearch : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                PopulateOrganization();
            }
            
        }

        private void PopulateOrganization()
        {
            BusinessLogic businessLogic = new BusinessLogic();
            Dictionary<string, string> organizationDictionary = businessLogic.PopulateOrganization();

            OrgDropDownList.DataSource = organizationDictionary;
            OrgDropDownList.DataValueField = "Key";
            OrgDropDownList.DataTextField = "Value";
            //OrgDropDownList.AppendDataBoundItems = true;
            OrgDropDownList.Items.Clear();
            
            OrgDropDownList.DataBind();
        }

        protected void OrgDropDownList_SelectedIndexChanged(object sender, EventArgs e)
        {
             string organizationName = OrgDropDownList.SelectedItem.Value.ToString() ;

             if(OrgDropDownList.SelectedIndex == 0 )
             {
                 departmentDropDownList.Visible = false;
                 lblDepartment.Visible = false;
                 Repeater_userDetails.DataSource = null;
                 Repeater_userDetails.DataBind();
                 return;
             }

             PopulateOranizationUsers(organizationName);
             PopulateDepartmentsByOrganizationUnit(organizationName);

             txtSearchInput.Text = "";
             hfUserSelected.Value = "";
             hfUserSelectedCN.Value = "";

             SearchUpdatePanel.Update();
        }

        private void PopulateDepartmentsByOrganizationUnit(string organizationName)
        {
            BusinessLogic businessLogic = new BusinessLogic();
            Dictionary<string, string> departments = businessLogic.PopulateDepartmentsByOrganizationUnit(organizationName);
            departmentDropDownList.Items.Clear();
            departmentDropDownList.DataSource = departments;
            departmentDropDownList.DataTextField = "Key";
            departmentDropDownList.DataValueField = "Value";
            departmentDropDownList.AppendDataBoundItems = true;
            departmentDropDownList.Items.Insert(0, new ListItem("All", "All"));
            departmentDropDownList.SelectedIndex = 0;
            departmentDropDownList.DataBind();

            departmentDropDownList.Visible = true;
            lblDepartment.Visible = true;
        }

        private void PopulateOranizationUsers(string organizationName)
        {
            BusinessLogic businessLogic = new BusinessLogic();
            List<ActiveDirectoryUserDetails> userList = businessLogic.PopulateOrganizationUsers(organizationName);
            Repeater_userDetails.DataSource = userList;
            Repeater_userDetails.DataBind();

        }

        protected void OrgDropDownList_DataBound(object sender, EventArgs e)
        {
            OrgDropDownList.Items.Insert(0, new ListItem("--Select--", "0"));
            OrgDropDownList.SelectedIndex = 0;
        }

        protected void departmentDropDownList_SelectedIndexChanged(object sender, EventArgs e)
        {
            string organizationName = OrgDropDownList.SelectedItem.Value.ToString();
            string departmentName = departmentDropDownList.SelectedItem.Value.ToString();

            BusinessLogic businessLogic = new BusinessLogic();
            List<ActiveDirectoryUserDetails> userList;
            
            userList = businessLogic.PopulateDepartmentOrganizationUsers(organizationName, departmentName);

            Repeater_userDetails.DataSource = userList;
            Repeater_userDetails.DataBind();

            SearchUpdatePanel.Update();
        }

        public void Submit_Click(object sender, EventArgs e)
        {
            string userName = Request.Form[txtSearchInput.UniqueID];
            string selectedUser = Request.Form[hfUserSelected.UniqueID];
            string userSelectedCN = Request.Form[hfUserSelectedCN.UniqueID];

            //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Name: " + userName + "\\nID: " + selectedUser + "\\n CN:" + userSelectedCN + "')", true);
            //ClientScript.RegisterStartupScript(this.GetType(), "alertMsg", "alert('Name: " + userName + "\\nID: " + selectedUser + "');", true);

            txtSearchInput.Text = selectedUser;

            BusinessLogic businessLogic = new BusinessLogic();
            List<ActiveDirectoryUserDetails> userList = businessLogic.PopulateSelectedUser(userSelectedCN);

            Repeater_userDetails.DataSource = userList;
            Repeater_userDetails.DataBind();

            OrgDropDownList.SelectedIndex = 0;
            departmentDropDownList.Visible = false;
            lblDepartment.Visible = false;

            SearchUpdatePanel.Update();
        }
    }
}