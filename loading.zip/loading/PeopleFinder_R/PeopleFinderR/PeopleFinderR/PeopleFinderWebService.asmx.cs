﻿using log4net;
using PeopleFinderR.Repository;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;

namespace PeopleFinderR
{
    /// <summary>
    /// Summary description for PeopleFinderWebService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]
    public class PeopleFinderWebService : System.Web.Services.WebService
    {
        ILog logger = log4net.LogManager.GetLogger("AppLogger");

        [WebMethod]
        public DataSet GetOrganizationUnits()
        {
            try
            {
                DataOperations operations = new DataOperations();
                DataSet orgs = operations.GetOrganizationUnits();

                return orgs;
            }
            catch(SoapException ex)
            {
                logger.Error("WS: SoapException: Error encountered while getting organization units",ex);
                throw ex;
            }
            catch (Exception ex)
            {
                logger.Error("WS: Error encountered while getting organization units", ex);
                throw ex;
            }
           
        }


        [WebMethod]
        public DataSet GetOrganizationUnitUsers(string organization)
        {
            DataOperations operations = new DataOperations();
            DataSet users = operations.GetOrganizationUnitUsers(organization);
            return users;
        }

        [WebMethod]
        public DataSet GetDepartmentByOrganizationUnit(string organization)
        {
            try
            {
                DataOperations operations = new DataOperations();
                DataSet departments = operations.GetDepartmentByOrganizationUnit(organization);
                return departments;
            }
            catch(SoapException ex)
            {
                logger.Error("WS: SoapException: Error encountered while getting organization",ex);
                throw ex;
            }
            catch (Exception ex)
            {
                logger.Error("WS: Error encountered while getting organization",ex);
                throw ex;
            }
        }


        [WebMethod]
        public DataSet GetUsersByDepartmentAndOrganizationUnit(string organization, string department)
        {
            try
            {
                DataOperations operations = new DataOperations();
                DataSet departments = operations.GetUsersByDepartmentAndOrganizationUnit(organization, department);
                return departments;
            }
            catch (SoapException ex)
            {
                logger.Error("WS: SoapException: Error encountered while getting users of department: " + department + " and organization : " + organization, ex);
                throw ex;
            }
            catch(Exception ex)
            {
                logger.Error("WS: Error encountered while getting users of department: " + department + " and organization : " + organization, ex);
                throw ex;
            }
           
        }


        [WebMethod]
        //public Dictionary<string,string> GetUsersByName(string Name)
        public List<string> GetUsersByName(string Name)
        {
            try
            {
                DataOperations operations = new DataOperations();
                DataSet users = operations.GetUsersByName(Name);

                List<string> autoCompleteusers = new List<string>();

                //Dictionary<string, string> autoCompleteusers = new Dictionary<string, string>();
                foreach (DataRow item in users.Tables[0].Rows)
                {
                    //autoCompleteusers.Add(item["cn"].ToString(), item["displayName"].ToString());
                    autoCompleteusers.Add(item["displayName"].ToString() + ":" + item["cn"].ToString());
                }
                return autoCompleteusers;
            }
            catch(SoapException ex)
            {
                logger.Error("WS: SoapException : Error encountered while getting user suggestion for name :" + Name ,ex);
                throw ex;
            }
            catch (Exception ex)
            {
                logger.Error("WS: Error encountered while getting user suggestion for name :" + Name, ex);
                throw ex;
            }
        }


        [WebMethod]
        //public Dictionary<string,string> GetUsersByName(string Name)
        public DataSet GetUsersDetailsByName(string Name)
        {
            try
            {
                DataOperations operations = new DataOperations();
                DataSet user = operations.GetUsersDetailsByName(Name);

                //foreach (DataRow item in users.Tables[0].Rows)
                //{
                //    //autoCompleteusers.Add(item["cn"].ToString(), item["displayName"].ToString());
                //    autoCompleteusers.Add(item["displayName"].ToString() + "-" + item["cn"].ToString());
                //}

                return user;
            }
            catch(SoapException ex)
            {
                logger.Error("WS: SoapException : Error encountered while getting details for user :" + Name, ex);
                throw ex;
            }
            catch (Exception ex)
            {
                logger.Error("WS: Error encountered while getting details for user :" + Name, ex);
                throw ex;
            }
          
        }

        [WebMethod]
        public void SaveUserImageFilePath(string cn, string filePath) 
        {
            try
            {
                DataOperations operations = new DataOperations();
                operations.SaveUserImageFilePath(cn, filePath);
            }
            catch(SoapException ex)
            {
                logger.Error("WS : SoapException : Error encountered while saving filepath : " + filePath + " of user: " + cn);
                throw ex;
            }
            catch (Exception ex)
            {
                logger.Error("WS : Error encountered while saving filepath : " + filePath + " of user: " + cn);                
                throw ex;
            }
            
        }

        [WebMethod]
        public void SaveFileDetails(string cn, string basepath, string filename) 
        {
            try
            {
                DataOperations operations = new DataOperations();
                operations.SaveFileDetails(cn, basepath, filename);
            }
            catch(SoapException ex)
            {
                logger.Error("WS : SoapException : Error encountered while saving file details basepath : " + basepath + " ,filename : " + filename + " of user: " + cn);
                throw ex;
            }
            catch (Exception ex)
            {
                logger.Error("WS : Error encountered while saving file details basepath : " + basepath + " ,filename : " + filename + " of user: " + cn);
                throw ex;
            }
        }

        [WebMethod]
        public DataSet GetLoadingUsers(int pageIndex, string org)
        {
            DataOperations operations = new DataOperations();
            return operations.GetLoadingUsers(pageIndex, org);
        }

        [WebMethod]
        public string GetLoadingUsersXML(int pageIndex, string org)
        {
            DataOperations operations = new DataOperations();
            return operations.GetLoadingUsers(pageIndex, org).GetXml();
        }

    }
}
