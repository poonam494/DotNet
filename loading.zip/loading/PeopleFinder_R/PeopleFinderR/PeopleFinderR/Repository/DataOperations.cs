﻿using PeopleFinderR.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace PeopleFinderR.Repository
{
    public class DataOperations
    {
        IDataAccess dataAccess;

        public DataOperations()
        {
            dataAccess = new ActiveDirectoryDataAccess();
        }

        internal DataSet GetOrganizationUnits()
        {
            return dataAccess.GetOrganizations();

        }

        internal DataSet GetOrganizationUnitUsers(string organization)
        {
            return dataAccess.GetOrganizationUnitUsers(organization);

        }

        internal DataSet GetDepartmentByOrganizationUnit(string organization)
        {
            return dataAccess.GetDepartmentByOrganizationUnit(organization);

        }

        internal DataSet GetUsersByDepartmentAndOrganizationUnit(string organization, string department)
        {
            return dataAccess.GetUsersByDepartmentAndOrganizationUnit(organization, department);

        }

        internal DataSet GetUsersByName(string Name)
        {
            return dataAccess.GetUsersByName(Name);

        }

        internal DataSet GetUsersDetailsByName(string Name)
        {
            return dataAccess.GetUsersDetailsByName(Name);
        }

        internal void SaveUserImageFilePath(string cn, string filePath) 
        {
             dataAccess.SaveUserImageFilePath(cn, filePath);
        }

        internal void SaveFileDetails(string cn, string basepath, string filename) 
        {
            dataAccess.SaveFileDetails(cn, basepath, filename);
        }

        internal DataSet GetLoadingUsers(int pageindex, string org) 
        {
            return dataAccess.GetLoadingUsers(pageindex, org);
        }

    }
}