﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PeopleFinderR.Entities
{
    internal class ActiveDirectoryUserDetails
    {
        public string displayName { get; set; }
        public string title { get; set; }
        public string company { get; set; }
        public string mail { get; set; }
        public string telephoneNumber { get; set; }
        public string mobile { get; set; }
        public string department { get; set; }
        public string physicalDeliveryOfficeName { get; set; }
        public string organizationUnit { get; set; }
        public string imageLocation { get; set; }
        public string distinguishedName { get; set; }
        public string cn { get; set; }
        public string pageCount { get; set; }
    }
}