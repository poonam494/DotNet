﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.DirectoryServices;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ActiveDirectoryUsersBatch
{
    class Program
    {
        //Dictionary to read app properties
        static Dictionary<string, string> appProperties = new Dictionary<string, string>();
        static string[] attributes;

        static void Main(string[] args)
        {
            //Logging
            Logger.OpenLog();

            //Dictionary to read app properties
            ReadApplicationProperties();

            //To read attributes from config
            ReadAttributes();

            //Dictionary to hold organizationUnits
            Dictionary<string, string> organisationUnits = new Dictionary<string, string>();

            //List to hold userData
            List<ActiveDirectoryUserDetails> ADUsers = null;

            GetADUserDetailsAndLoadDatabase(ADUsers, organisationUnits);

            Logger.CloseLog();

            Console.WriteLine("---");

            Environment.Exit(0);
            
            Console.ReadLine();

        }

        private static void ReadApplicationProperties() 
        {
            try
            {
                string filename = string.Empty;
                if (Convert.ToBoolean(Convert.ToInt32(ConfigurationManager.AppSettings["DEV_ENVIRONMENT"].ToString())))
                {
                    filename = ConfigurationManager.AppSettings["DEV_APPLICATION_PROPERTIES"].ToString();
                }
                else if (Convert.ToBoolean(Convert.ToInt32(ConfigurationManager.AppSettings["UAT_ENVIRONMENT"].ToString())))
                {
                    filename = ConfigurationManager.AppSettings["UAT_APPLICATION_PROPERTIES"].ToString();
                }
                else if (Convert.ToBoolean(Convert.ToInt32(ConfigurationManager.AppSettings["PROD_ENVIRONMENT"].ToString())))
                {
                    filename = ConfigurationManager.AppSettings["PROD_APPLICATION_PROPERTIES"].ToString();
                }

                string batchPath = Path.GetFullPath(Path.Combine(System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location), @"..\..\"));
                string path = batchPath + @"Resources\" + filename;
                //string path = batchPath + @"Resources\ApplicationProperties.txt";


                string[] properties = File.ReadAllLines(path);
                        //(@"..\..\Resources\ApplicationProperties.txt");

                    Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") + " : Read Application Properties");

                    foreach (var prop in properties)
                    {
                        string[] propArr = prop.Split(new string[] { "|" }, StringSplitOptions.RemoveEmptyEntries);
                        appProperties.Add(propArr[0], propArr[1]);

                        Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") + " : " + propArr[0] + "|" + propArr[1]);
                    }
            }
            catch(Exception ex)
            {
                string error = ex.Message;
                Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") +" : " +error);
            }
        }

        private static void ReadAttributes() 
        {
            try
            {
                string configAttributes = ConfigurationManager.AppSettings["attributes"];
                attributes = configAttributes.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries);

                Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") + " : " +"Reading attributes from Config file");

                foreach (string attr in attributes)
                {
                    Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") + " : " + attr);
                }
            }
            catch (Exception ex)
            {
                string error = ex.Message;
                Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") + " : " +error);
            }
        }


        private static void GetADUserDetailsAndLoadDatabase(List<ActiveDirectoryUserDetails> ADUsers, Dictionary<string,string> OrganizationUnits)
        {
            //To get organizationUnits
            Dictionary<string,string> organizationUnits = GetOrganizationUnits();

            //Get ADUsers
            ADUsers = GetUserDataFromActiveDirectory(ADUsers);
            
            //Populate data table
            if ((ADUsers != null) && (ADUsers.Count > 0))
            {
                Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") + " : Total organization Count: " + organizationUnits.Count);
                Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") + " : Total User Count: " + ADUsers.Count);

                DataTable OrganizationDataTable = PopulateOrganizationDataTable(organizationUnits);
                DataTable ADUsersDataTable = PopulateUserDataTable(ADUsers);
                //Load database
                LoadDatabaseTable(ADUsersDataTable, OrganizationDataTable);
            }
        }

        private static void LoadDatabaseTable(DataTable ADUsersDataTable, DataTable OrganizationDataTable)
        {
            LoadOrganizationDatabaseTable(OrganizationDataTable);
            LoadUserDatabaseTable(ADUsersDataTable);
        }
              
        private static List<ActiveDirectoryUserDetails> GetUserDataFromActiveDirectory(List<ActiveDirectoryUserDetails> ADUsers) 
        {
            Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") +" : Getting User information from External base DN");
            //Get AD User from DN1
            ADUsers = GetADUsersFromExternalBaseDN(ADUsers);

            //Get AD User from DN2
            if (ADUsers == null)
            {
                ADUsers = new List<ActiveDirectoryUserDetails>();

            }

            Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") + " : Getting User information from base DN");
            ADUsers = GetADUsersFromBaseDN(ADUsers);

            int userCount = ADUsers == null ? 0 : ADUsers.Count;
            Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") + " : User Count from Active directory:" + userCount);

            return ADUsers;
        }


        private static List<ActiveDirectoryUserDetails> GetADUsersFromExternalBaseDN(List<ActiveDirectoryUserDetails> ADUsers)
        {
            //To get all persons in external base DN
            return GetUserDetails(ADUsers);
            
        }

        private static Dictionary<string, string> GetOrganizationUnits()
        {
            Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") + " : Fetching Organization Units");
            Dictionary<string, string> organisationUnits = new Dictionary<string, string>();

            try
            {
                string host = appProperties["hostName"];
                string domain = appProperties["EXTERNAL_BASE_DN"];
                string username = appProperties["LDAP_LOGIN_UID"];
                string password = appProperties["LDAP_LOGIN_PWD"];
                string filter = "(&(objectClass=organizationalUnit))";

                SearchResultCollection searchResults = Search(host, domain, username, password, filter, SearchScope.Subtree);


                foreach (SearchResult searchresult in searchResults)
                {
                    DirectoryEntry deSearchResult = searchresult.GetDirectoryEntry() as DirectoryEntry;
                    organisationUnits.Add(deSearchResult.Name, deSearchResult.Path);

                }

                Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") + " : Organization Unit Count :" + organisationUnits.Count);
            }
            catch (Exception ex)
            {
                string error = ex.Message;
                Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") +" : " +error);
            }
         
            return organisationUnits;
        }


        private static List<ActiveDirectoryUserDetails> GetUserDetails(List<ActiveDirectoryUserDetails> ADUsers) 
        {
            string host = appProperties["hostName"];
            string domain = appProperties["EXTERNAL_BASE_DN"];
            string username = appProperties["LDAP_LOGIN_UID"];
            string password = appProperties["LDAP_LOGIN_PWD"];
            string filterPerson = "(&(objectClass=Person))";

            SearchResultCollection searchResults = Search(host, domain, username, password, filterPerson, SearchScope.Subtree);

            return GetListFromSearchCollection(searchResults,ADUsers);
        }

        private static List<ActiveDirectoryUserDetails> GetListFromSearchCollection(SearchResultCollection searchResults, List<ActiveDirectoryUserDetails> ADUsers)
        {
            Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") +" : Populate User list from search results");
            try
            {
                if (searchResults.Count > 0)
                {
                    if (ADUsers == null) 
                    {
                        ADUsers = new List<ActiveDirectoryUserDetails>();
                    }

                    foreach (SearchResult orgUsers in searchResults)
                    {
                        ActiveDirectoryUserDetails user = new ActiveDirectoryUserDetails();

                        DirectoryEntry deSearchResult = orgUsers.GetDirectoryEntry();

                        string[] distinguishedNameArr = deSearchResult.Properties["distinguishedName"].Value.ToString().Split(',');

                        string ouName = string.Empty;

                        foreach (string s in distinguishedNameArr)
                        {
                            if (s.ToLower().Contains("ou="))
                            {
                                ouName = s;
                                user.organizationUnit = ouName;
                                break;
                            }
                        }

                        
                        string userDetails = "OrganizationUnit:" + ouName + ",";

                        //for logging
                        foreach (string attr in attributes)
                        {
                            userDetails = userDetails + attr + ":" + deSearchResult.Properties[attr].Value + ",";

                        }

                        Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") + " : " + userDetails.Substring(0, userDetails.Length - 1));

                        //setting user properties
                        user.displayName = deSearchResult.Properties["displayName"].Value == null ? "" : deSearchResult.Properties["displayName"].Value.ToString();
                        user.title = deSearchResult.Properties["title"].Value == null ? "" : deSearchResult.Properties["title"].Value.ToString();
                        user.company = deSearchResult.Properties["company"].Value == null ? "" : deSearchResult.Properties["company"].Value.ToString();
                        user.mail = deSearchResult.Properties["mail"].Value == null ? "" : deSearchResult.Properties["mail"].Value.ToString();
                        user.telephoneNumber = deSearchResult.Properties["telephoneNumber"].Value == null ? "" : deSearchResult.Properties["telephoneNumber"].Value.ToString();
                        user.mobile = deSearchResult.Properties["mobile"].Value == null ? "" : deSearchResult.Properties["mobile"].Value.ToString();
                        user.department = deSearchResult.Properties["department"].Value == null ? "" : deSearchResult.Properties["department"].Value.ToString();
                        user.physicalDeliveryOfficeName = deSearchResult.Properties["physicalDeliveryOfficeName"].Value == null ? "" : deSearchResult.Properties["physicalDeliveryOfficeName"].Value.ToString();
                        user.distinguishedName = deSearchResult.Properties["distinguishedName"].Value == null ? "" : deSearchResult.Properties["distinguishedName"].Value.ToString();
                        user.cn = deSearchResult.Properties["cn"].Value == null ? "" : deSearchResult.Properties["cn"].Value.ToString();

                        user.imageLocation = "";

                        ADUsers.Add(user);
                    }
                    Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") + " : User list prepared from search results");
                    return ADUsers;
                }

            }
            catch (Exception ex)
            {
                string error = ex.Message;
                Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") + " : "+error);
            }
            return null;
        }

        private static List<ActiveDirectoryUserDetails> GetADUsersFromBaseDN(List<ActiveDirectoryUserDetails> ADUsers)
        {
            return GetBaseDNUserDetails(ADUsers);
        }


        private static List<ActiveDirectoryUserDetails> GetBaseDNUserDetails(List<ActiveDirectoryUserDetails> ADUsers)
        {
            string host = appProperties["hostName"];
            string domain = appProperties["BASE_DN"];
            string username = appProperties["LDAP_LOGIN_UID"];
            string password = appProperties["LDAP_LOGIN_PWD"];
            string filterPerson = "(&(objectClass=User)(objectCategory=Person)(!department=Student)(|(userAccountControl=512)(userAccountControl=66048)(userAccountControl=544)))";

            SearchResultCollection searchResults = Search(host, domain, username, password, filterPerson, SearchScope.Subtree);

            return GetListFromBaseSearchCollection(searchResults, ADUsers);
        }

        private static List<ActiveDirectoryUserDetails> GetListFromBaseSearchCollection(SearchResultCollection searchResults, List<ActiveDirectoryUserDetails> ADUsers)
        {
            Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") + " : Populate user list from search results for Base DN");
            try
            {
                if (searchResults.Count > 0)
                {
                    if (ADUsers == null)
                    {
                        ADUsers = new List<ActiveDirectoryUserDetails>();
                    }
                
                    foreach (SearchResult searchUser in searchResults)
                    {

                        ActiveDirectoryUserDetails user = new ActiveDirectoryUserDetails();
                        DirectoryEntry deSearchResult = searchUser.GetDirectoryEntry();

                        string[] distinguishedNameArr = deSearchResult.Properties["distinguishedName"].Value.ToString().Split(',');

                        string baseDN_OUName = "OU=ICES,";
                        bool ouSet = false;

                        foreach (string s in distinguishedNameArr)
                        {
                            if (s.ToLower().Contains("ou=corporate services"))
                            {
                                baseDN_OUName = baseDN_OUName + "ou=corporate services".ToUpper();
                                user.organizationUnit = baseDN_OUName;
                                ouSet = true;

                                break;
                            }
                        }

                        if (!ouSet)
                        {
                            foreach (string s in distinguishedNameArr)
                            {
                                if (s.ToLower().Contains("ou=research"))
                                {
                                    baseDN_OUName = baseDN_OUName + "ou=research".ToUpper() ;
                                    user.organizationUnit = baseDN_OUName;
                                    ouSet = true;

                                    break;
                                }
                            }
                        }

                        if (!ouSet)
                        {
                            foreach (string s in distinguishedNameArr)
                            {
                                if (s.ToLower().Contains("ou="))
                                {
                                    baseDN_OUName = baseDN_OUName + s;
                                    user.organizationUnit = baseDN_OUName;
                                    ouSet = true;

                                    break;
                                }
                            }
                        }

                        string userDetails = "OrganizationUnit:" + baseDN_OUName + ",";

                        //for logging
                        foreach (string attr in attributes)
                        {
                            userDetails = userDetails + attr + ":" + deSearchResult.Properties[attr].Value + ",";
                        }

                        Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss")+ " : " + userDetails.Substring(0, userDetails.Length - 1));

                        user.displayName = deSearchResult.Properties["displayName"].Value == null ? "" : deSearchResult.Properties["displayName"].Value.ToString();
                        user.title = deSearchResult.Properties["title"].Value == null ? "" : deSearchResult.Properties["title"].Value.ToString();
                        user.company = deSearchResult.Properties["company"].Value == null ? "" : deSearchResult.Properties["company"].Value.ToString();
                        user.mail = deSearchResult.Properties["mail"].Value == null ? "" : deSearchResult.Properties["mail"].Value.ToString();
                        user.telephoneNumber = deSearchResult.Properties["telephoneNumber"].Value == null ? "" : deSearchResult.Properties["telephoneNumber"].Value.ToString();
                        user.mobile = deSearchResult.Properties["mobile"].Value == null ? "" : deSearchResult.Properties["mobile"].Value.ToString();
                        user.department = deSearchResult.Properties["department"].Value == null ? "" : deSearchResult.Properties["department"].Value.ToString();
                        user.physicalDeliveryOfficeName = deSearchResult.Properties["physicalDeliveryOfficeName"].Value == null ? "" : deSearchResult.Properties["physicalDeliveryOfficeName"].Value.ToString();
                        user.distinguishedName = deSearchResult.Properties["distinguishedName"].Value == null ? "" : deSearchResult.Properties["distinguishedName"].Value.ToString();
                        user.cn = deSearchResult.Properties["cn"].Value == null ? "" : deSearchResult.Properties["cn"].Value.ToString();

                        user.imageLocation = "";

                        ADUsers.Add(user);
                    }

                    Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") + " : User list prepared from search results");
                    return ADUsers;
                }
            }
            catch (Exception ex)
            {
                string error = ex.Message;
            }
            return null;
        }


        private static DataTable PopulateOrganizationDataTable(Dictionary<string,string> organizationUnits)
        {
            Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") + " : Populate data table from Organization listing");
            DataTable dataTableOrganization = new DataTable("OrganizationDataTable");

            string columnNameOrgName = "organizationName";
            DataColumn column1 = new DataColumn(columnNameOrgName);
            dataTableOrganization.Columns.Add(column1);
            Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") + " : Column name:" + columnNameOrgName);

            string columnNamePath = "path";
            DataColumn column2 = new DataColumn(columnNamePath);
            dataTableOrganization.Columns.Add(column2);
            Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") + " : Column name:" + columnNamePath);

            foreach (KeyValuePair<string,string> pair in organizationUnits)
            {
                DataRow orgRow = dataTableOrganization.NewRow();

                orgRow["organizationName"] = pair.Key;
                orgRow["path"] = pair.Value;

                dataTableOrganization.Rows.Add(orgRow);
            }

            return dataTableOrganization;
        }



        private static DataTable PopulateUserDataTable(List<ActiveDirectoryUserDetails> ADUsers)
        {
            Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") + " : Populate data table from User list");
            DataTable dataTableUsers = new DataTable("UserDetails");

            foreach (string attr in attributes)
            {
                string columnName = attr;
                DataColumn column = new DataColumn(columnName);
                dataTableUsers.Columns.Add(column);
                Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") + " : Column name:" + columnName);
            }

            DataColumn organizationUnit = new DataColumn("organizationUnit");
            dataTableUsers.Columns.Add(organizationUnit);
            DataColumn imageLocation = new DataColumn("imageLocation");
            dataTableUsers.Columns.Add(imageLocation);


            foreach (ActiveDirectoryUserDetails user in ADUsers)
            {
                DataRow userRow = dataTableUsers.NewRow();

                userRow["displayName"] = user.displayName;
                userRow["title"] = user.title;
                userRow["company"] = user.company;
                userRow["mail"] = user.mail;
                userRow["telephoneNumber"] = user.telephoneNumber;
                userRow["mobile"] = user.mobile;
                userRow["department"] = user.department;
                userRow["physicalDeliveryOfficeName"] = user.physicalDeliveryOfficeName;
                userRow["distinguishedName"] = user.distinguishedName;
                userRow["cn"] = user.cn;
                userRow["organizationUnit"] = user.organizationUnit;
                userRow["imageLocation"] = user.imageLocation;

                dataTableUsers.Rows.Add(userRow);
            }
            dataTableUsers.AcceptChanges();

            Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") + " : "+"Data table users count:" + dataTableUsers.Rows.Count);
            return dataTableUsers;
        }


        private static void LoadOrganizationDatabaseTable(DataTable OrganizationDataTable)
        {
            Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") + " : " + "Loading Organization database table");
            
            SqlConnection con;

            try
            {
                con = GetConnection();
                con.Open();

                using (SqlCommand cmd = new SqlCommand("truncate table ActiveDirectoryOrganizations", con))
                {
                    cmd.CommandType = CommandType.Text;
                    Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") + " : " + "Executing query :" + cmd.CommandText);
                    cmd.ExecuteNonQuery();
                }

                Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") + " : " + "Performing bulk organization insert operation");

                using (SqlBulkCopy bulkCopy = new SqlBulkCopy(con))
                {
                    bulkCopy.DestinationTableName =
                        "ActiveDirectoryOrganizations";

                    try
                    {
                        //Column mappings
                        bulkCopy.ColumnMappings.Add("organizationName", "organizationName");
                        bulkCopy.ColumnMappings.Add("path", "path");

                        // Write the array of rows to the destination.
                        bulkCopy.WriteToServer(OrganizationDataTable);
                    }
                    catch (Exception ex)
                    {
                        string error = ex.Message;
                        Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") + " : " + error);
                        Environment.Exit(-1);
                    }
                }

                Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") + " : " + "Completed insert operation on Organization table");


            }
            catch (Exception ex)
            {
                string error = ex.Message;
                Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") + " : " + error);
                Environment.Exit(-1);
            }
            finally
            {
                con = null;
            }
        }



        private static void LoadUserDatabaseTable(DataTable dt)
        {
            Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") + " : " +"Loading User database tables");

            SqlConnection con;
            try
            {
                con = GetConnection();
                con.Open();

                using (SqlCommand cmd = new SqlCommand("truncate table ActiveDirectoryUserData", con))
                {
                    cmd.CommandType = CommandType.Text;
                    Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") + " : "+"Executing query :" + cmd.CommandText);
                    cmd.ExecuteNonQuery();
                }

                Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") +" : " +"Performing bulk user insert operation");

                using (SqlBulkCopy bulkCopy = new SqlBulkCopy(con))
                {
                    bulkCopy.DestinationTableName =
                        "ActiveDirectoryUserData";
                    
                    try
                    {
                        //Column mappings
                        bulkCopy.ColumnMappings.Add("displayName", "displayName");
                        bulkCopy.ColumnMappings.Add("title", "title");
                        bulkCopy.ColumnMappings.Add("company", "company");
                        bulkCopy.ColumnMappings.Add("mail", "mail");
                        bulkCopy.ColumnMappings.Add("telephoneNumber", "telephoneNumber");
                        bulkCopy.ColumnMappings.Add("mobile", "mobile");
                        bulkCopy.ColumnMappings.Add("department", "department");
                        bulkCopy.ColumnMappings.Add("physicalDeliveryOfficeName", "physicalDeliveryOfficeName");
                        bulkCopy.ColumnMappings.Add("distinguishedName", "distinguishedName");
                        bulkCopy.ColumnMappings.Add("cn", "cn");
                        bulkCopy.ColumnMappings.Add("organizationUnit", "organizationUnit");
                        bulkCopy.ColumnMappings.Add("imageLocation", "imageLocation");

                        // Write the array of rows to the destination.
                        bulkCopy.WriteToServer(dt);
                    }
                    catch (Exception ex)
                    {
                        string error = ex.Message;
                        Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") + " : " + error);
                        Environment.Exit(-1);
                    }
                }

                Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") + " : "+"Performing insert operation on replica table");

                using (SqlCommand cmd = new SqlCommand("truncate table ActiveDirectoryUserDataReplica", con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();
                }

                using (SqlCommand cmd = new SqlCommand("spADUsersReplica", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.ExecuteNonQuery();
                }

                Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") + " : " + "Completed insert operation on Users table");
            }
            catch (Exception ex)
            {
                string error = ex.Message;
                Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") +" : "+error);
                Environment.Exit(-1);
            }
            finally
            {
               con = null;
            }
        }

        private static SqlConnection GetConnection()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["DatabaseConnectionString"].ConnectionString;
            SqlConnection connection = new SqlConnection(connectionString);
            Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") +" : " +"Database Connection: " + connectionString);
            return connection;
        }

        private static SearchResultCollection Search(string host,string domain,string username, string password, string filter,SearchScope scope)
        {
            Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss")+" : "+ "Searching in Active directory");
            Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss")+" : "+ "Following is search method parameters:");
            Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss")+" : "+ "Host: " + host);
            Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss")+" : "+ "Domain: " + domain);
            Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss")+" : "+ "Username: " + username);
            Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss")+" : "+ "Password: " + password);
            Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss")+" : "+ "Filter Criteria: " + filter);
            Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss")+" : "+ "Search Scope: " + scope);
            Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss")+" : "+ "Search method parameters ends");

            DirectoryEntry directoryEntry;
            DirectorySearcher directorySearcher;
            try
            {
                directoryEntry = new DirectoryEntry("LDAP://" + host + "/" + domain, username, password);
                directoryEntry.AuthenticationType = AuthenticationTypes.ServerBind;

                directorySearcher = new DirectorySearcher(directoryEntry);
                directorySearcher.Filter = filter;
                directorySearcher.SearchScope = scope;
                directorySearcher.PageSize = System.Int32.MaxValue;

                SearchResultCollection searchCollection = directorySearcher.FindAll();

                Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") + " : " + "Search count : " + searchCollection.Count); 

                return searchCollection;
            }
            catch (Exception ex)
            {
                string error = ex.Message;
                Logger.WriteToLog(DateTime.Now.ToString("yyyy-MM-dd-hh:mm:ss") + " : " + error);
            }
            finally 
            {
                directoryEntry = null;
                directorySearcher = null;
            }
            return null;
        }

    }
}
