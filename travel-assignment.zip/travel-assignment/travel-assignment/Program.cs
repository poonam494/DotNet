﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Globalization;

namespace travel_assignment
{
    class Program
    {
        static HashSet<string> allData = new HashSet<string>();

        static void Main(string[] args)
        {

           string[] providerList = new string[]  { @"C:\Users\RADHE\Desktop\pp-assignment\Provider1.txt",
                                    @"C:\Users\RADHE\Desktop\pp-assignment\Provider2.txt",
                                    @"C:\Users\RADHE\Desktop\pp-assignment\Provider3.txt" };

            foreach (string pL in providerList)
                ReadDataFile(pL,"|");
        
            foreach (String row in allData)
                System.Console.WriteLine(row);
            
            System.Console.ReadLine();
        }



        static void ReadDataFile(String filePath, String colDelimiter)
        {
            String line;
            int count = 0;
            System.IO.StreamReader file = new System.IO.StreamReader(@filePath);
            while ((line = file.ReadLine()) != null)
            {
                ++count;
                if(count !=1)
                    allData.Add(FindAndReplaceDate(line.Trim().Replace(',', '|')));

            }
                
            file.Close();
           

        }

        static string FindAndReplaceDate(string rowData)
        {
            try
            {
               // return Regex.Replace(rowData,"\\b(?<month>\\d{1,2})/(?<day>\\d{1,2})/(?<year>\\d{2,4})\\b","${day}-${month}-${year}", RegexOptions.None);
                return Regex.Replace(rowData, "\\b(?<month>\\d{1,2})-(?<day>\\d{1,2})-(?<year>\\d{2,4})\\b", "${month}/${day}/${year}", RegexOptions.None);
            }
            catch (Exception)
            {
                return rowData;
            }
        }


        
       
    }
}
