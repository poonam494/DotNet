﻿using PeopleFinder.DataAccess;
using PeopleFinder.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;

namespace PeopleFinder.BusinessLogicLayer
{
    public class BusinessLogic
    {
        PeopleFinderService.PeopleFinderWebServiceSoapClient ws;
        public BusinessLogic()
        {
            ws = new PeopleFinderService.PeopleFinderWebServiceSoapClient();
        }

        internal Dictionary<string, string> PopulateOrganization() 
        {
            try
            {
                Dictionary<string, string> organizationDictionary = new Dictionary<string, string>();

                DataSet ds = ws.GetOrganizationUnits();

                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    string orgFullName = row["organizationname"].ToString();
                    string name = orgFullName.Split(new string[] { "=" }, StringSplitOptions.RemoveEmptyEntries)[1];
                    organizationDictionary.Add(name, name);
                }

                return organizationDictionary;
            }
            catch (Exception ex)
            {
                throw ex;
            }
          
        }

        internal List<ActiveDirectoryUserDetails> PopulateOrganizationUsers(string organizationName) 
        {
            try
            {
                DataSet ds = ws.GetOrganizationUnitUsers(organizationName);
                List<ActiveDirectoryUserDetails> organizationUnitUsers = new List<ActiveDirectoryUserDetails>();

                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    ActiveDirectoryUserDetails user = new ActiveDirectoryUserDetails();

                    user.displayName = row["displayName"].ToString();
                    user.title = row["title"].ToString();
                    user.company = row["company"].ToString();
                    user.mail = row["mail"].ToString();
                    user.department = row["department"].ToString();
                    user.telephoneNumber = row["telephoneNumber"].ToString();
                    user.mobile = row["mobile"].ToString();
                    user.physicalDeliveryOfficeName = row["physicalDeliveryOfficeName"].ToString();
                    user.cn = row["cn"].ToString();
                    user.organizationUnit = row["organizationUnit"].ToString();
                    user.distinguishedName = row["distinguishedName"].ToString();
                    user.imageLocation = row["imageLocation"].ToString();

                    #region file from DB check
                    if (File.Exists(HttpContext.Current.Server.MapPath(Path.Combine(row["basepath"].ToString() + row["filename"]))))
                    {
                        //user.imageLocation = HttpContext.Current.Server.MapPath(Path.Combine(row["basepath"].ToString() + row["filename"]));      //Path.Combine("/ProfilePic/" + user.cn + ".png");
                        user.imageLocation = Path.Combine(row["basepath"].ToString() + row["filename"].ToString());      //Path.Combine("/ProfilePic/" + user.cn + ".png");
                    }
                    else
                    {
                        user.imageLocation = "images/not_available.jpg"; 
                    }
                    #endregion


                    //if ((!String.IsNullOrWhiteSpace(user.mail)) || (!String.IsNullOrWhiteSpace(user.telephoneNumber)) || (!String.IsNullOrWhiteSpace(user.mobile)))
                    //{
                    //    organizationUnitUsers.Add(user);
                    //}

                    #region filteration working

                    if (!String.IsNullOrWhiteSpace(user.mail))   //&& user.mail.Trim().EndsWith(".sg"))
                    {
                        if (user.mail.Trim().EndsWith(".sg"))
                        {
                            string newPh = user.telephoneNumber.Replace(" ", "");
                            if ((!String.IsNullOrWhiteSpace(user.telephoneNumber)) && (Regex.IsMatch(user.telephoneNumber, "[a-zA-Z]") || Regex.IsMatch(user.telephoneNumber, "^[0]+$") || !(user.telephoneNumber.Length >= 8)))  //^(\+|[65]|0{0,1})[0]*$   //Regex.IsMatch(newPh, @"^(\+65)?[0]+$")
                            {
                                user.telephoneNumber = string.Empty;
                            }
                            organizationUnitUsers.Add(user);
                        }
                    }
                    else if ((!String.IsNullOrWhiteSpace(user.telephoneNumber)) && !Regex.IsMatch(user.telephoneNumber, "[a-zA-Z]") && !Regex.IsMatch(user.telephoneNumber, "^[0]+$") && (user.telephoneNumber.Length >= 8))     //|| (!String.IsNullOrWhiteSpace(user.mobile))) 
                    {
                        organizationUnitUsers.Add(user);
                    }
                    else if (!String.IsNullOrWhiteSpace(user.mobile))
                    {
                        user.telephoneNumber = string.Empty;
                        organizationUnitUsers.Add(user);
                    }

                    #endregion

                }

                //filter for email ends with .sg but filters out either info present one
                //organizationUnitUsers = organizationUnitUsers.Where(p => p.mail.TrimEnd(new char[]{' '}).EndsWith(".sg")).OrderBy(u => u.displayName).ToList<ActiveDirectoryUserDetails>();
                
                organizationUnitUsers = organizationUnitUsers.OrderBy(u => u.displayName).ToList<ActiveDirectoryUserDetails>();

                return organizationUnitUsers;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        internal List<ActiveDirectoryUserDetails> PopulateSelectedUser(string name)
        {
            try
            {
                //getting selected user details from service
                DataSet ds = ws.GetUsersDetailsByName(name);
                List<ActiveDirectoryUserDetails> users = new List<ActiveDirectoryUserDetails>();

                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    //Populating user object for selected user from autocomplete 
                    ActiveDirectoryUserDetails user = new ActiveDirectoryUserDetails();
                    user.displayName = row["displayName"].ToString();
                    user.title = row["title"].ToString();
                    user.company = row["company"].ToString();
                    user.department = row["department"].ToString();
                    user.mail = row["mail"].ToString();
                    user.telephoneNumber = row["telephoneNumber"].ToString();
                    user.mobile = row["mobile"].ToString();
                    user.physicalDeliveryOfficeName = row["physicalDeliveryOfficeName"].ToString();
                    user.imageLocation = row["imageLocation"].ToString();
                    user.cn = row["cn"].ToString();
                    user.distinguishedName = row["distinguishedName"].ToString();
                    user.organizationUnit = row["organizationUnit"].ToString();


                    #region file from DB check
                    if (File.Exists(HttpContext.Current.Server.MapPath(Path.Combine(row["basepath"].ToString() + row["filename"]))))
                    {
                        //user.imageLocation = HttpContext.Current.Server.MapPath(Path.Combine(row["basepath"].ToString() + row["filename"]));      //Path.Combine("/ProfilePic/" + user.cn + ".png");
                        user.imageLocation = Path.Combine(row["basepath"].ToString() + row["filename"].ToString());      //Path.Combine("/ProfilePic/" + user.cn + ".png");
                    }
                    else
                    {
                        user.imageLocation = "images/not_available.jpg"; //HttpContext.Current.Server.MapPath("~/images/not_available.jpg");
                    }
                    #endregion

                    users.Add(user);
                }

                return users;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return null;
        }


        internal Dictionary<string, string> PopulateDepartmentsByOrganizationUnit(string organization)
        {
            DataSet ds = ws.GetDepartmentByOrganizationUnit(organization);
            Dictionary<string, string> departments = new Dictionary<string, string>();
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                if (!string.IsNullOrEmpty(row["department"].ToString()))
                    departments.Add(row["department"].ToString(), row["department"].ToString());
            }

            return departments;
        }


        internal List<ActiveDirectoryUserDetails> PopulateDepartmentOrganizationUsers(string organization, string department)
        {
            DataSet ds = ws.GetUsersByDepartmentAndOrganizationUnit(organization, department);
            List<ActiveDirectoryUserDetails> users = new List<ActiveDirectoryUserDetails>();

            foreach (DataRow row in ds.Tables[0].Rows)
            {
                ActiveDirectoryUserDetails user = new ActiveDirectoryUserDetails();
                user.displayName = row["displayName"].ToString();
                user.title = row["title"].ToString();
                user.company = row["company"].ToString();
                user.department = row["department"].ToString();
                user.mail = row["mail"].ToString();
                user.telephoneNumber = row["telephoneNumber"].ToString();
                user.mobile = row["mobile"].ToString();
                user.physicalDeliveryOfficeName = row["physicalDeliveryOfficeName"].ToString();
                user.imageLocation = row["imageLocation"].ToString();
                user.cn = row["cn"].ToString();
                user.distinguishedName = row["distinguishedName"].ToString();
                user.organizationUnit = row["organizationUnit"].ToString();


                #region file from DB check
                if (File.Exists(HttpContext.Current.Server.MapPath(Path.Combine(row["basepath"].ToString() + row["filename"]))))
                {
                    //user.imageLocation = HttpContext.Current.Server.MapPath(Path.Combine(row["basepath"].ToString() + row["filename"]));      //Path.Combine("/ProfilePic/" + user.cn + ".png");
                    user.imageLocation = Path.Combine(row["basepath"].ToString() + row["filename"].ToString());      //Path.Combine("/ProfilePic/" + user.cn + ".png");

                }
                else
                {
                    user.imageLocation = "images/not_available.jpg"; 
                }
                #endregion


                //if ((!String.IsNullOrWhiteSpace(user.mail)) || (!String.IsNullOrWhiteSpace(user.telephoneNumber)) || (!String.IsNullOrWhiteSpace(user.mobile)))
                //{
                //    //if (!String.IsNullOrWhiteSpace(user.mail))
                //    //{
                //    //     users.Add(user);
                //    //}

                //    users.Add(user);
                //}


                //if (!String.IsNullOrWhiteSpace(user.mail))   // && user.mail.Trim().EndsWith(".sg"))
                //{
                //    if (user.mail.Trim().EndsWith(".sg"))
                //    {
                //        users.Add(user);
                //    }
                //}
                //else if ((!String.IsNullOrWhiteSpace(user.telephoneNumber)) || (!String.IsNullOrWhiteSpace(user.mobile)))
                //{
                //    users.Add(user);
                //}


                //if ((!String.IsNullOrWhiteSpace(user.mail)) || (!String.IsNullOrWhiteSpace(user.telephoneNumber)) || (!String.IsNullOrWhiteSpace(user.mobile)))
                //{
                //    users.Add(user);
                //}

                #region working filteration
                if (!String.IsNullOrWhiteSpace(user.mail))   //&& user.mail.Trim().EndsWith(".sg"))
                {
                    if (user.mail.Trim().EndsWith(".sg"))
                    {
                        string newPh = user.telephoneNumber.Replace(" ", "");
                        if ((!String.IsNullOrWhiteSpace(user.telephoneNumber)) && (Regex.IsMatch(user.telephoneNumber, "[a-zA-Z]") || Regex.IsMatch(user.telephoneNumber, "^[0]+$") || !(user.telephoneNumber.Length >= 8)))  //^(\+|[65]|0{0,1})[0]*$   //Regex.IsMatch(newPh, @"^(\+65)?[0]+$")
                        {
                            user.telephoneNumber = string.Empty;
                        }
                        users.Add(user);
                    }
                }
                else if ((!String.IsNullOrWhiteSpace(user.telephoneNumber)) && !Regex.IsMatch(user.telephoneNumber, "[a-zA-Z]") && !Regex.IsMatch(user.telephoneNumber, "^[0]+$") && (user.telephoneNumber.Length >= 8))     //|| (!String.IsNullOrWhiteSpace(user.mobile))) 
                {
                    users.Add(user);
                }
                else if (!String.IsNullOrWhiteSpace(user.mobile))
                {
                    user.telephoneNumber = string.Empty;
                    users.Add(user);
                }
                #endregion

                //users.Add(user);
                
            }

            //filter mails with sg end
            //users = users.Where(p => p.mail.TrimEnd(new char[] { ' ' }).EndsWith(".sg")).OrderBy(u => u.displayName).ToList<ActiveDirectoryUserDetails>();

            users = users.OrderBy(u => u.displayName).ToList<ActiveDirectoryUserDetails>();
            return users;
        }


        public DataSet populateRI()
        {
            try
            {
                Dictionary<string, string> RIDictionary = new Dictionary<string, string>();

                RIInfoDB db = new RIInfoDB();
                DataSet ds = db.GetRIs();

                //    foreach (DataRow row in ds.Tables[0].Rows)
                //    {
                //        string RI_Abbrev = row["RI_Abbrev"].ToString();
                //        string RI_LoginDomain = row["RI_LoginDomain"].ToString();

                //        RIDictionary.Add(RI_LoginDomain, RI_Abbrev);
                //    }

                //return RIDictionary;


                return ds;


            }
            catch (Exception)
            {

                throw;
            }
            return null;
        }


        public string GetRIEntireNameByAbbr(string riAbbr)
        {
            RIInfoDB db = new RIInfoDB();

            DataSet ds = db.GetRIs();
            DataView dataView = ds.Tables[0].DefaultView;

            dataView.RowFilter = "RI_Abbrev = '" + riAbbr + "'";

            if (dataView.Count > 0)
            {
                DataTable dt = dataView.Table;
                return dt.Rows[0]["RI_Name"].ToString();
            }


            return null;
        }


        internal void SaveFileDetails(string cn, string basepath, string filename)
        {
            try
            {
                //logger.Info("BL: Started saving file details directory: " + basepath + " , filename: " + filename + " for user: " + cn);
                
                UploadImageDB imgDb = new UploadImageDB();
                imgDb.SaveFileDetails(cn, basepath, filename);

                //logger.Info("BL: Completed saving file details directory: " + basepath + " , filename: " + filename + " for user: " + cn);
            }
            catch (Exception ex)
            {
               // logger.Error("BL: Error encountered while saving file details directory: " + basepath + " , filename: " + filename + " for user: " + cn, ex);
            }
        }


    }
}