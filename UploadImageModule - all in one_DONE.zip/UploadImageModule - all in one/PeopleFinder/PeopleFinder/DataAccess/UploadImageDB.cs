﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace PeopleFinder.DataAccess
{
    public class UploadImageDB
    {

        //private static SqlConnection GetConnection()
        //{
        //    try
        //    {
        //        string connectionString = GetConnectionString();  // ConfigurationManager.ConnectionStrings["DevDatabaseConnectionString"].ConnectionString;
        //        SqlConnection connection = new SqlConnection(connectionString);
        //        return connection;
        //    }
        //    catch (Exception e)
        //    {
        //        throw e;
        //    }
        //}


        private static string GetConnectionString()
        {
            try
            {
                string prodEnvirorment = ConfigurationManager.AppSettings["IS_PROD"].ToString();
                string uatEnvirorment = ConfigurationManager.AppSettings["IS_UAT"].ToString();
                string devEnvirorment = ConfigurationManager.AppSettings["IS_DEV"].ToString();

                string dbConnectionString = null;

                if (Convert.ToBoolean(Convert.ToInt16(prodEnvirorment)))
                {
                    dbConnectionString = ConfigurationManager.ConnectionStrings["ProdDatabaseConnectionString"].ConnectionString;
                }
                else if (Convert.ToBoolean(Convert.ToInt16(uatEnvirorment)))
                {
                    dbConnectionString = ConfigurationManager.ConnectionStrings["UatDatabaseConnectionString"].ConnectionString;
                }
                else if (Convert.ToBoolean(Convert.ToInt16(devEnvirorment)))
                {
                    dbConnectionString = ConfigurationManager.ConnectionStrings["DevDatabaseConnectionString"].ConnectionString;
                }

                return dbConnectionString;
            }
            catch (Exception)
            {
                throw;
            }
        }



        public int InsertUploadImageRequest(string ri, string cn, string userid, string email,string fullname,string status) 
        {
            SqlConnection con = null;

            try
            {
                con = DBConnection.GetConnection();  //GetConnection();
                con.Open();
                using (SqlCommand cmd = new SqlCommand("spInsertUserImageFileRequest", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@requestorRI", ri);

                    cmd.Parameters.AddWithValue("@requestorCN", cn);

                    cmd.Parameters.AddWithValue("@requestorUserId", userid);

                    cmd.Parameters.AddWithValue("@requestorEmail", email);

                    cmd.Parameters.AddWithValue("@requestorFullName", fullname);

                    cmd.Parameters.AddWithValue("@status", status);

                    //SqlParameter parameter = new SqlParameter("@requestId", SqlDbType.Int);
                    //parameter.Direction = ParameterDirection.Output;
                    //cmd.Parameters.Add(parameter);
                    cmd.Parameters.Add("@requestId", SqlDbType.Int).Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();

                    int requestID =  Convert.ToInt32(cmd.Parameters["@requestId"].Value.ToString());

                    return requestID;
                }
               // return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
                con.Dispose();
                con = null;
            }

        }


        public DataSet GetPendingUserImageRequest()
        {
            SqlConnection con = null;

            try
            {
                con = DBConnection.GetConnection(); //GetConnection();
                con.Open();
                using (SqlCommand cmd = new SqlCommand("spGetPendingUserImageFileRequest", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();

                    da.Fill(ds);

                    if (ds.Tables[0].Rows.Count > 0)
                        return ds;
                    else
                        return null;
                }
                // return 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
                con.Dispose();
                con = null;
            }

        }


        public void SaveFileDetails(string cn, string basepath, string filename)
        {
            SqlConnection con;

            try
            {
               // logger.Info("Started saving filename " + filename + " in directory " + basepath + " for user:" + cn + " in database");

                con = DBConnection.GetConnection();  //GetConnection();
                con.Open();

                using (SqlCommand cmd = new SqlCommand("spSaveUserImageFileDetails", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@cn", cn);
                    cmd.Parameters.AddWithValue("@basepath", basepath);
                    cmd.Parameters.AddWithValue("@filename", filename);

                    cmd.ExecuteNonQuery();
                }

               // logger.Info("Completed saving filename " + filename + " in directory " + basepath + " for user:" + cn + " in database");

            }
            catch (Exception ex)
            {
              //  logger.Error("WS : Error encountered while saving file details basepath : " + basepath + " ,filename : " + filename + " of user: " + cn, ex);
                throw ex;
            }
        }



    }
}