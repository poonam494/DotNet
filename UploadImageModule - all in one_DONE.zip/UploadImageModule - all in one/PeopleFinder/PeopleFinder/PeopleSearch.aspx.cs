﻿using PeopleFinder.BusinessLogicLayer;
using PeopleFinder.Entities;
using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using System.Web.UI;
using log4net;
//using System.Web.UI.HtmlControls;
using System.Web;
using System.IO;
using System.Text.RegularExpressions;

namespace PeopleFinder
{
    public partial class PeopleSearch : System.Web.UI.Page
    {
        //ILog logger = log4net.LogManager.GetLogger("AppLogger");

        protected void Page_init(object sender, EventArgs e) 
        {
            //working
            //ClientScript.RegisterStartupScript(this.GetType(), "Displayloading", "Displayloading();", true);
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //isLoading.Value = "loading";
                PopulateOrganization();
                DisableDepartmentDropDown();

                //var newclassValue = imgPowerBy.Attributes["class"].Replace("fix", "");
                //imgPowerBy.Attributes["class"] = newclassValue;
            }
            else 
            {
                //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "hideLoading", "Showloading();", true);

                //Page.ClientScript.RegisterStartupScript(this.GetType(), "showLoading", "Showloading();", true);

                //working
               // ClientScript.RegisterStartupScript(this.GetType(), "Displayloading", "Displayloading();", true);

            }
        }

        //display department drop down
        private void DisableDepartmentDropDown() 
        {
            departmentDropDownList.Items.Clear();
            departmentDropDownList.Enabled = false;
            departmentDropDownList.Items.Insert(0, new ListItem("All", "All"));
            departmentDropDownList.SelectedIndex = 0;
        }

        private void PopulateOrganization()
        {
            try
            {
                BusinessLogic businessLogic = new BusinessLogic();
                Dictionary<string, string> organizationDictionary = businessLogic.PopulateOrganization();

                OrgDropDownList.DataSource = organizationDictionary;
                OrgDropDownList.DataValueField = "Key";
                OrgDropDownList.DataTextField = "Value";
                //OrgDropDownList.AppendDataBoundItems = true;
                OrgDropDownList.Items.Clear();

                OrgDropDownList.DataBind();
            }
            catch (Exception e)
            {
            }
        }

        protected void OrgDropDownList_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                string organizationName = OrgDropDownList.SelectedItem.Value.ToString();

                if (OrgDropDownList.SelectedIndex == 0)
                {
                    //display department drop down
                    //departmentDropDownList.Visible = false;
                    //lblDepartment.Visible = false;
                    
                    //departmentDropDownList.Items.Clear();
                    //departmentDropDownList.Enabled = false;
                    DisableDepartmentDropDown();

                    Repeater_userDetails.DataSource = null;
                    Repeater_userDetails.DataBind();
                    return;
                }

                //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "showLoading", "Showloading();", true);
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "showLoading", "Showloading();", true);

                //working
                //ClientScript.RegisterStartupScript(this.GetType(), "Displayloading", "Displayloading();", true);

                PopulateOrganizationUsers(organizationName);
                PopulateDepartmentsByOrganizationUnit(organizationName);

                //ScriptManager.RegisterClientScriptBlock(Page, typeof(Page), "hideLoading", "Displayloading();", true);
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "hideLoading", "Displayloading();", true);
               

                isLoading.Value = "done";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        private void PopulateOrganizationUsers(string organizationName)
        {
            try
            {
                BusinessLogic businessLogic = new BusinessLogic();
                List<ActiveDirectoryUserDetails> organizationUsers = businessLogic.PopulateOrganizationUsers(organizationName);
                
                Repeater_userDetails.DataSource = organizationUsers;
                Repeater_userDetails.DataBind();

                txtSearchInput.Text = String.Empty;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void OrgDropDownList_DataBound(object sender, EventArgs e)
        {
            OrgDropDownList.Items.Insert(0, new ListItem("--Select--", "0"));
            OrgDropDownList.SelectedIndex = 0;
        }


        protected void departmentDropDownList_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                //logger.Info("Started populating users for selected department of organization");

                string organizationName = OrgDropDownList.SelectedItem.Value.ToString();
                string departmentName = departmentDropDownList.SelectedItem.Value.ToString();

                //departmentDropDownList.SelectedItem.Attributes.Add("title", departmentName);

                //departmentDropDownList.Attributes.Add("title", departmentName);

                BusinessLogic businessLogic = new BusinessLogic();
                List<ActiveDirectoryUserDetails> userList;

                userList = businessLogic.PopulateDepartmentOrganizationUsers(organizationName, departmentName);

                Repeater_userDetails.DataSource = null;
                Repeater_userDetails.DataSource = userList;
                Repeater_userDetails.DataBind();

                //logger.Info("Completed Populating users for organization " + organizationName + " and department " + departmentName);
            }
            catch (Exception ex)
            {
               // logger.Error("Error encountered while populating users for department of organization ", ex);
            }
        }


        public void Submit_Click(object sender, EventArgs e)
        {
            try
            {
                string userName = Request.Form[txtSearchInput.UniqueID];
                string selectedUser = Request.Form[hfUserSelected.UniqueID];
                string userSelectedCN = Request.Form[hfUserSelectedCN.UniqueID];

                txtSearchInput.Text = selectedUser;

                BusinessLogic businessLogic = new BusinessLogic();
                List<ActiveDirectoryUserDetails> userList = businessLogic.PopulateSelectedUser(userSelectedCN);

                foreach (var user in userList)
                {
                    if ((!String.IsNullOrWhiteSpace(user.telephoneNumber)) && (Regex.IsMatch(user.telephoneNumber, "[a-zA-Z]") || Regex.IsMatch(user.telephoneNumber, "^[0]+$") || !(user.telephoneNumber.Length >= 8)))  //^(\+|[65]|0{0,1})[0]*$   //Regex.IsMatch(newPh, @"^(\+65)?[0]+$")
                    {
                        user.telephoneNumber = string.Empty;
                    }

                }

                Repeater_userDetails.DataSource = userList;
                Repeater_userDetails.DataBind();

                OrgDropDownList.SelectedIndex = 0;
                departmentDropDownList.Items.Clear();

                //display department drop down
                DisableDepartmentDropDown();
                //departmentDropDownList.Visible = false;
                //lblDepartment.Visible = false;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



        private void PopulateDepartmentsByOrganizationUnit(string organizationName)
        {
            try
            {

                BusinessLogic businessLogic = new BusinessLogic();
                Dictionary<string, string> departments = businessLogic.PopulateDepartmentsByOrganizationUnit(organizationName);
                departmentDropDownList.Items.Clear();
                departmentDropDownList.DataSource = departments;
                departmentDropDownList.DataTextField = "Key";
                departmentDropDownList.DataValueField = "Value";
                departmentDropDownList.AppendDataBoundItems = true;
                departmentDropDownList.Items.Insert(0, new ListItem("All", "All"));
                departmentDropDownList.SelectedIndex = 0;
                departmentDropDownList.DataBind();

                //departmentDropDownList.Visible = true;
                //lblDepartment.Visible = true;

                departmentDropDownList.Enabled = true;

            }
            catch (Exception ex)
            {

            }
        }

        protected void btnClearSearch_Click(object sender, EventArgs e)
        {
            txtSearchInput.Text = "";
            hfUserSelected.Value = "";
            hfUserSelectedCN.Value = "";

            OrgDropDownList.SelectedIndex = 0;
            DisableDepartmentDropDown();
            departmentDropDownList.SelectedIndex = 0;

            Repeater_userDetails.DataSource = null;
            Repeater_userDetails.DataBind();
        }


    }
}