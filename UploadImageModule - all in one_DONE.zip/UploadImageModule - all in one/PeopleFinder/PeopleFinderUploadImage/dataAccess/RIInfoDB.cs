﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace PeopleFinderUploadImage.dataAccess
{
    public class RIInfoDB
    {
        /// <summary>
        /// Method to get sql connection 
        /// </summary>
        /// <returns></returns>
        private static SqlConnection GetConnection()
        {
            try
            {
                string connectionString = ConfigurationManager.ConnectionStrings["DevDatabaseConnectionString"].ConnectionString;
                SqlConnection connection = new SqlConnection(connectionString);
                return connection;
            }
            catch (Exception e)
            {
                throw e;
            }


        }


        public DataSet GetRIs() 
        {
            SqlConnection con = null;
            try
            {

                con = GetConnection();
                con.Open();
                using (SqlCommand cmd = new SqlCommand("p_mResearchInstitute_S", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    return ds;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex.InnerException);
            }
            finally 
            {
                con.Close();
                con = null;
            }
        }


        public string GetRILoginDomain(string RIAbbr) 
        {
            SqlConnection con = null;
            try
            {

                con = GetConnection();
                con.Open();
                using (SqlCommand cmd = new SqlCommand("p_mResearchInstitute_S_By_Abbr", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@strAbbr", RIAbbr);

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        return ds.Tables[0].Rows[0]["RI_LoginDomain"].ToString();
                    }
                    else 
                    {
                        return null;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex.InnerException);
            }
            finally
            {
                con.Close();
                con = null;
            }

           
        }



        public string GetRILDAPDomain(string strAbbr) 
        {
            SqlConnection con = null;
            try
            {

                con = GetConnection();
                con.Open();
                using (SqlCommand cmd = new SqlCommand("p_mResearchInstitute_S_By_Abbr", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@strAbbr", strAbbr);

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        return ds.Tables[0].Rows[0]["RI_LDAPDomain"].ToString();
                    }
                    else
                    {
                        return null;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex.InnerException);
            }
            finally
            {
                con.Close();
                con = null;
            }

        }






    }
}