﻿using PeopleFinderService.DataAccess;
using PeopleFinderService.Repository;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace PeopleFinderService
{
    /// <summary>
    /// Summary description for PeopleFinderWebService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]
    public class PeopleFinderWebService : System.Web.Services.WebService
    {

        [WebMethod]
        public DataSet GetOrganizationUnits()
        {
            //ActiveDirectoryDataAccess da = new ActiveDirectoryDataAccess();
            DataOperations operations = new DataOperations();
            DataSet orgs = operations.GetOrganizationUnits();

            return orgs;
        }


        [WebMethod]
        public DataSet GetOrganizationUnitUsers(string organization)
        {
            DataOperations operations = new DataOperations();
            DataSet users = operations.GetOrganizationUnitUsers(organization);
            return users;
        }

        [WebMethod]
        public DataSet GetDepartmentByOrganizationUnit(string organization)
        {
            DataOperations operations = new DataOperations();
            DataSet departments = operations.GetDepartmentByOrganizationUnit(organization);
            return departments;
        }


        [WebMethod]
        public DataSet GetUsersByDepartmentAndOrganizationUnit(string organization,string department)
        {
            DataOperations operations = new DataOperations();
            DataSet departments = operations.GetUsersByDepartmentAndOrganizationUnit(organization, department);
            return departments;
        }


    }
}
