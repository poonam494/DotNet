﻿using PeopleFinderService.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace PeopleFinderService.Repository
{
    public class DataOperations
    {
        IDataAccess dataAccess;

        public DataOperations()
        {
            dataAccess = new ActiveDirectoryDataAccess();
        }

        internal DataSet GetOrganizationUnits()
        {
            return dataAccess.GetOrganizations();
            
        }

        internal DataSet GetOrganizationUnitUsers(string organization) 
        {
            return dataAccess.GetOrganizationUnitUsers(organization);
            
        }

        internal DataSet GetDepartmentByOrganizationUnit(string organization)
        {
            return dataAccess.GetDepartmentByOrganizationUnit(organization);

        }

        internal DataSet GetUsersByDepartmentAndOrganizationUnit(string organization, string department)
        {
            return dataAccess.GetUsersByDepartmentAndOrganizationUnit(organization,department);

        }
    }
}