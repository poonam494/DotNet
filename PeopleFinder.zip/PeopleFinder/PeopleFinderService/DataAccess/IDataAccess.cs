﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeopleFinderService.DataAccess
{
    interface IDataAccess
    {
        DataSet GetOrganizations();

        DataSet GetOrganizationUnitUsers(string organization);

        DataSet GetDepartmentByOrganizationUnit(string organization);

        DataSet GetUsersByDepartmentAndOrganizationUnit(string organization, string department);
    }
}
