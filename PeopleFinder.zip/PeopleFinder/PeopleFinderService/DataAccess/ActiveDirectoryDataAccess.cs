﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace PeopleFinderService.DataAccess
{
    public class ActiveDirectoryDataAccess : IDataAccess
    {
        private static SqlConnection GetConnection()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["DatabaseConnectionString"].ConnectionString;
            SqlConnection connection = new SqlConnection(connectionString);
            return connection;
        }

        public DataSet GetOrganizations()
        {
            SqlConnection con ;
            try
            {
                con = GetConnection();
                con.Open();
                using (SqlCommand cmd = new SqlCommand("select distinct(organizationName) from ActiveDirectoryorganizations", con))
                {
                    cmd.CommandType = CommandType.Text;
                    //cmd.ExecuteReader();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    return ds;
                }

            }
            catch (Exception e)
            {
                throw;
            }
            finally 
            {
                con = null;
            }
            return null;
        }

        public DataSet GetOrganizationUnitUsers(string organization) 
        {
            SqlConnection con;
            try
            {
                con = GetConnection();
                con.Open();
                //using (SqlCommand cmd = new SqlCommand("select * from ActiveDirectoryUserDataReplica where organizationUnit like '%'+@organization+'%'", con))
                using (SqlCommand cmd = new SqlCommand("select * from ActiveDirectoryUserDataReplica where organizationUnit like @organization", con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@organization", "%" + organization +"%"); //string.Format("%{0}%",organization)
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    return ds;
                }

            }
            catch (Exception e)
            {
                throw;
            }
            finally
            {
                con = null;
            }
            return null;
        }

        public DataSet GetDepartmentByOrganizationUnit(string organization)
        {
            SqlConnection con;
            try
            {
                con = GetConnection();
                con.Open();

                using (SqlCommand cmd = new SqlCommand("select distinct(department) from ActiveDirectoryUserDataReplica where organizationUnit like @organization", con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@organization", "%" + organization + "%"); //string.Format("%{0}%",organization)
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    return ds;
                }

            }
            catch (Exception e)
            {
                throw;
            }
            finally
            {
                con = null;
            }
            return null;
        }

        public DataSet GetUsersByDepartmentAndOrganizationUnit(string organization, string department) 
        {
            SqlConnection con;
            try
            {
                con = GetConnection();
                con.Open();

                string query = null;
                bool isAllDepartment = false;

                if (department.Equals("All", StringComparison.InvariantCultureIgnoreCase))
                {
                    query = "select * from ActiveDirectoryUserDataReplica where organizationUnit like @organization ";
                    isAllDepartment = true;
                }
                else
                {
                    query = "select * from ActiveDirectoryUserDataReplica where organizationUnit like @organization and department = @department";
                }

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@organization", "%" + organization + "%"); //string.Format("%{0}%",organization)
                    if (!isAllDepartment)
                    {
                        cmd.Parameters.AddWithValue("@department", department);
                    }
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    return ds;
                }

            }
            catch (Exception e)
            {
                throw;
            }
            finally
            {
                con = null;
            }
            return null;
        }

        public DataSet GetUsersByName(string Name) 
        {
            SqlConnection con;
            try
            {
                con = GetConnection();
                con.Open();

                using (SqlCommand cmd = new SqlCommand("select displayName,cn from ActiveDirectoryUserDataReplica where displayName like @displayName", con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@displayName", "%" + Name + "%"); //string.Format("%{0}%",organization)
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    return ds;
                }

            }
            catch (Exception e)
            {
                throw;
            }
            finally
            {
                con = null;
            }
            return null;
        }



        public DataSet GetUsersDetailsByName(string Name) 
        {
            SqlConnection con;
            try
            {
                con = GetConnection();
                con.Open();

                using (SqlCommand cmd = new SqlCommand("select * from ActiveDirectoryUserDataReplica where cn = @cn", con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@cn", Name); //string.Format("%{0}%",organization)
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    return ds;
                }

            }
            catch (Exception e)
            {
                throw;
            }
            finally
            {
                con = null;
            }
            return null;
        }

    }
}