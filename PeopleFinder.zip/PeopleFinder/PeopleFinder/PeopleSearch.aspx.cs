﻿using PeopleFinder.BusinessLogicLayer;
using PeopleFinder.Entities;
using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using System.Web.UI;
using log4net;

namespace PeopleFinder
{
    public partial class PeopleSearch : System.Web.UI.Page
    {
        ILog logger =  log4net.LogManager.GetLogger("AppLogger");

        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
               // logger = log4net.LogManager.GetLogger("AppLogger");
                PopulateOrganization();
            }
            
        }

        private void PopulateOrganization()
        {
            try
            {
                logger.Info("Populate Organization Started");

                BusinessLogic businessLogic = new BusinessLogic();
                Dictionary<string, string> organizationDictionary = businessLogic.PopulateOrganization();

                OrgDropDownList.DataSource = organizationDictionary;
                OrgDropDownList.DataValueField = "Key";
                OrgDropDownList.DataTextField = "Value";
                //OrgDropDownList.AppendDataBoundItems = true;
                OrgDropDownList.Items.Clear();
            
                OrgDropDownList.DataBind();

                logger.Info("Populate Organization completed");

            }
            catch (Exception e)
            {
                logger.Error(e.Message, e);
            }
        }

        protected void OrgDropDownList_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                 string organizationName = OrgDropDownList.SelectedItem.Value.ToString() ;

                 logger.Info("Searched started for organization:" + organizationName);
             

                 if(OrgDropDownList.SelectedIndex == 0 )
                 {
                     logger.Error("Not selected any organization and clicked search");

                     departmentDropDownList.Visible = false;
                     lblDepartment.Visible = false;
                     Repeater_userDetails.DataSource = null;
                     Repeater_userDetails.DataBind();
                     return;
                 }

                 PopulateOranizationUsers(organizationName);
                 PopulateDepartmentsByOrganizationUnit(organizationName);

                 txtSearchInput.Text = "";
                 hfUserSelected.Value = "";
                 hfUserSelectedCN.Value = "";

                 SearchUpdatePanel.Update();
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message, ex);
            }
        }

        private void PopulateDepartmentsByOrganizationUnit(string organizationName)
        {
            try
            {
                logger.Info("Started populating departments for organization " + organizationName );

                BusinessLogic businessLogic = new BusinessLogic();
                Dictionary<string, string> departments = businessLogic.PopulateDepartmentsByOrganizationUnit(organizationName);
                departmentDropDownList.Items.Clear();
                departmentDropDownList.DataSource = departments;
                departmentDropDownList.DataTextField = "Key";
                departmentDropDownList.DataValueField = "Value";
                departmentDropDownList.AppendDataBoundItems = true;
                departmentDropDownList.Items.Insert(0, new ListItem("All", "All"));
                departmentDropDownList.SelectedIndex = 0;
                departmentDropDownList.DataBind();

                departmentDropDownList.Visible = true;
                lblDepartment.Visible = true;

                logger.Info("Populating " + departments.Count + " departments for organization completed successfully");
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message, ex);
            }
        }

        private void PopulateOranizationUsers(string organizationName)
        {
            try
            {
                logger.Info("Call to get users belonging to organization :" + organizationName);

                BusinessLogic businessLogic = new BusinessLogic();
                List<ActiveDirectoryUserDetails> userList = businessLogic.PopulateOrganizationUsers(organizationName);
                Repeater_userDetails.DataSource = userList;
                Repeater_userDetails.DataBind();

                logger.Info("Fetched " + userList.Count + " users belonging to organization successfully");
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message, ex);
            }
        }

        protected void OrgDropDownList_DataBound(object sender, EventArgs e)
        {
            OrgDropDownList.Items.Insert(0, new ListItem("--Select--", "0"));
            OrgDropDownList.SelectedIndex = 0;
        }

        protected void departmentDropDownList_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                logger.Info("Started Populating department users");

                string organizationName = OrgDropDownList.SelectedItem.Value.ToString();
                string departmentName = departmentDropDownList.SelectedItem.Value.ToString();

                logger.Info("for organization " + organizationName  + "  department " + departmentName);

                BusinessLogic businessLogic = new BusinessLogic();
                List<ActiveDirectoryUserDetails> userList;
            
                userList = businessLogic.PopulateDepartmentOrganizationUsers(organizationName, departmentName);

                Repeater_userDetails.DataSource = userList;
                Repeater_userDetails.DataBind();

                SearchUpdatePanel.Update();

                logger.Info("Populating " + userList.Count + "users for organization " + organizationName + " and department " + departmentName);
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message, ex);
            }
        }

        public void Submit_Click(object sender, EventArgs e)
        {
            try
            {
                logger.Info("Started autocomplete search");

                string userName = Request.Form[txtSearchInput.UniqueID];
                string selectedUser = Request.Form[hfUserSelected.UniqueID];
                string userSelectedCN = Request.Form[hfUserSelectedCN.UniqueID];

                //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Name: " + userName + "\\nID: " + selectedUser + "\\n CN:" + userSelectedCN + "')", true);
                //ClientScript.RegisterStartupScript(this.GetType(), "alertMsg", "alert('Name: " + userName + "\\nID: " + selectedUser + "');", true);

                txtSearchInput.Text = selectedUser;

                BusinessLogic businessLogic = new BusinessLogic();
                List<ActiveDirectoryUserDetails> userList = businessLogic.PopulateSelectedUser(userSelectedCN);

                Repeater_userDetails.DataSource = userList;
                Repeater_userDetails.DataBind();

                OrgDropDownList.SelectedIndex = 0;
                departmentDropDownList.Visible = false;
                lblDepartment.Visible = false;

                SearchUpdatePanel.Update();

                logger.Info("Completed autocomplete search for selected user " + selectedUser);
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message, ex);
            }
        }

        protected void btnUploadImage_Click(object sender, EventArgs e)
        {

        }
    }
}