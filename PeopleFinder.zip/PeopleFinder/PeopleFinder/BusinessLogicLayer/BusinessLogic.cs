﻿using PeopleFinder.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace PeopleFinder.BusinessLogicLayer
{
    public class BusinessLogic
    {
        PeopleFinderService.PeopleFinderWebServiceSoapClient ws;
        public BusinessLogic()
        {
            ws = new PeopleFinderService.PeopleFinderWebServiceSoapClient();
        }

        internal Dictionary<string, string> PopulateOrganization() 
        {
            Dictionary<string, string> organizationDictionary = new Dictionary<string, string>();
          
            DataSet ds = ws.GetOrganizationUnits();

            // ds.Tables["ActiveDirectoryorganizations"].DefaultView;
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                string orgFullName = row["organizationname"].ToString();
                string name = orgFullName.Split(new string[] { "=" }, StringSplitOptions.RemoveEmptyEntries)[1];
                organizationDictionary.Add(name, name);
            }

            return organizationDictionary;
        }


        internal List<ActiveDirectoryUserDetails> PopulateOrganizationUsers(string organization)
        {
            DataSet ds = ws.GetOrganizationUnitUsers(organization);
            List<ActiveDirectoryUserDetails> users = new List<ActiveDirectoryUserDetails>();
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                ActiveDirectoryUserDetails user = new ActiveDirectoryUserDetails();
                user.displayName = row["displayName"].ToString();
                user.title = row["title"].ToString();
                user.company = row["company"].ToString();
                user.department = row["department"].ToString();
                user.mail = row["mail"].ToString();
                user.telephoneNumber = row["telephoneNumber"].ToString();
                user.mobile = row["mobile"].ToString();
                user.physicalDeliveryOfficeName = row["physicalDeliveryOfficeName"].ToString();
                user.imageLocation = row["imageLocation"].ToString();
                user.cn = row["cn"].ToString();
                user.distinguishedName = row["distinguishedName"].ToString();

                users.Add(user);
            }

            return users;
        }

        internal Dictionary<string,string> PopulateDepartmentsByOrganizationUnit(string organization)
        {
            DataSet ds = ws.GetDepartmentByOrganizationUnit(organization);
            Dictionary<string, string> departments = new Dictionary<string, string>();
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                if (! string.IsNullOrEmpty(row["department"].ToString()))
                    departments.Add(row["department"].ToString(), row["department"].ToString());
            }

            return departments;
        }


        internal List<ActiveDirectoryUserDetails> PopulateDepartmentOrganizationUsers(string organization,string department)
        {
            DataSet ds = ws.GetUsersByDepartmentAndOrganizationUnit(organization, department);
            List<ActiveDirectoryUserDetails> users = new List<ActiveDirectoryUserDetails>();
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                ActiveDirectoryUserDetails user = new ActiveDirectoryUserDetails();
                user.displayName = row["displayName"].ToString();
                user.title = row["title"].ToString();
                user.company = row["company"].ToString();
                user.department = row["department"].ToString();
                user.mail = row["mail"].ToString();
                user.telephoneNumber = row["telephoneNumber"].ToString();
                user.mobile = row["mobile"].ToString();
                user.physicalDeliveryOfficeName = row["physicalDeliveryOfficeName"].ToString();
                user.imageLocation = row["imageLocation"].ToString();
                user.cn = row["cn"].ToString();
                user.distinguishedName = row["distinguishedName"].ToString();

                users.Add(user);
            }

            return users;
        }

    }
}