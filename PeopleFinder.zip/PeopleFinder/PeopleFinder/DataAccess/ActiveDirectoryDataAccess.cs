﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;

namespace PeopleFinder.DataAccess
{
    public class ActiveDirectoryDataAccess : IDataAccess
    {
        /// <summary>
        /// Method to get sql connection 
        /// </summary>
        /// <returns></returns>
        private static SqlConnection GetConnection()
        {
            try
            {
                string connectionString = GetConnectionString(); //ConfigurationManager.ConnectionStrings["DatabaseConnectionString"].ConnectionString;
                SqlConnection connection = new SqlConnection(connectionString);
                return connection;
            }
            catch (Exception e)
            {
                throw e;
            }
        }


        private static string GetConnectionString()
        {
            try
            {
                string prodEnvirorment = ConfigurationManager.AppSettings["IS_PROD"].ToString();
                string uatEnvirorment = ConfigurationManager.AppSettings["IS_UAT"].ToString();
                string devEnvirorment = ConfigurationManager.AppSettings["IS_DEV"].ToString();

                string dbConnectionString = null;

                if (Convert.ToBoolean(Convert.ToInt16(prodEnvirorment)))
                {
                    dbConnectionString = ConfigurationManager.ConnectionStrings["ProdDatabaseConnectionString"].ConnectionString;
                }
                else if (Convert.ToBoolean(Convert.ToInt16(uatEnvirorment)))
                {
                    dbConnectionString = ConfigurationManager.ConnectionStrings["UatDatabaseConnectionString"].ConnectionString;
                }
                else if (Convert.ToBoolean(Convert.ToInt16(devEnvirorment)))
                {
                    dbConnectionString = ConfigurationManager.ConnectionStrings["DevDatabaseConnectionString"].ConnectionString;
                }

                return dbConnectionString;
            }
            catch (Exception)
            {
                throw;
            }
        }




        /// <summary>
        /// Method to get organization names(i.e. RIs) from database
        /// </summary>
        /// <returns></returns>
        public DataSet GetOrganizations()
        {
           SqlConnection con;
           try
           {
               con = GetConnection();
               con.Open();

               using (SqlCommand cmd = new SqlCommand("select distinct(organizationName) from ActiveDirectoryOrganizations", con))
               {
                   cmd.CommandType = CommandType.Text;
                   SqlDataAdapter da = new SqlDataAdapter(cmd);
                   DataSet ds = new DataSet();

                   da.Fill(ds);
                   return ds;
               }
           }
           catch (Exception)
           {
               throw;
           }
           finally 
           {
               con = null;
           }
        }

        /// <summary>
        /// Method to get users belonging to organization unit from database
        /// </summary>
        /// <param name="organization">organization name(i.e. RI name)</param>
        /// <returns></returns>
        public DataSet GetOrganizationUnitUsers(string organization) 
        {
            SqlConnection con;
            try
            {
                con = GetConnection();
                con.Open();

                using (SqlCommand cmd = new SqlCommand("select * from ActiveDirectoryUserDataReplica where organizationUnit like @organization", con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@organization","%"+ organization + "%"); //String.Format("%{0}%",organization

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    return ds;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return null;
        }

        /// <summary>
        /// Method to get users suggestions from database for search input
        /// </summary>
        /// <param name="searchInput"></param>
        /// <returns></returns>
        public DataSet GetUsersByName(string searchInput)
        {
            SqlConnection con;
            try
            {
                con = GetConnection();
                con.Open();

                string query = null;
                bool isNumberSearch = true;

                foreach (char c in searchInput)
                {
                    if (c < '0' || c > '9')
                    {
                        isNumberSearch = false;
                    }
                }

                //initial
                //query = "Select displayName,organizationUnit,cn from ActiveDirectoryUserDataReplica where displayName like @searchInput";


                //(RTRIM(LTRIM(mail)) = ''  or mail is null) and
                //RTRIM(LTRIM(telephoneNumber)) = '' and 
                //RTRIM(LTRIM(mobile)) = ''
                
                
                //filteration working query
                query = "Select displayName,organizationUnit,cn from ActiveDirectoryUserDataReplica where displayName like @searchInput and (RTRIM(LTRIM(mail)) != ''  and RTRIM(LTRIM(mail)) like '%.sg') UNION (Select displayName,organizationUnit,cn from ActiveDirectoryUserDataReplica where displayName like @searchInput and RTRIM(LTRIM(mail)) = '' and ( RTRIM(LTRIM(telephoneNumber)) != '' or  RTRIM(LTRIM(mobile)) != '' ))";

                //query = "Select displayName,organizationUnit,cn from ActiveDirectoryUserDataReplica where displayName like @searchInput and (mail != '' or telephoneNumber != '' or  mobile != '' )";
                

                if (!isNumberSearch)
                {
                    //initial
                    //query = "select displayName,organizationUnit,cn from ActiveDirectoryUserDataReplica where displayName like @searchInput";

                    //filteration working query
                    query = "Select displayName,organizationUnit,cn from ActiveDirectoryUserDataReplica where displayName like @searchInput and (RTRIM(LTRIM(mail)) != ''  and RTRIM(LTRIM(mail)) like '%.sg') UNION (Select displayName,organizationUnit,cn from ActiveDirectoryUserDataReplica where displayName like @searchInput and RTRIM(LTRIM(mail)) = '' and ( RTRIM(LTRIM(telephoneNumber)) != '' or  RTRIM(LTRIM(mobile)) != '' ))";

                    //query = "Select displayName,organizationUnit,cn from ActiveDirectoryUserDataReplica where displayName like @searchInput and (mail != '' or telephoneNumber != '' or  mobile != '' )";

                }
                else
                {
                    //initial
                    //query = "select displayName,organizationUnit,cn from ActiveDirectoryUserDataReplica where telephoneNumber like @searchInput";

                    //filteration working query
                    query = "Select displayName,organizationUnit,cn from ActiveDirectoryUserDataReplica where telephoneNumber like @searchInput and (RTRIM(LTRIM(mail)) != ''  and RTRIM(LTRIM(mail)) like '%.sg') UNION (Select displayName,organizationUnit,cn from ActiveDirectoryUserDataReplica where telephoneNumber like @searchInput and RTRIM(LTRIM(mail)) = '' and ( RTRIM(LTRIM(telephoneNumber)) != '' or  RTRIM(LTRIM(mobile)) != '' ))";

                    //query = "Select displayName,organizationUnit,cn from ActiveDirectoryUserDataReplica where telephoneNumber like @searchInput and (mail != '' or telephoneNumber != '' or  mobile != '' )";

                }


                using (SqlCommand cmd = new SqlCommand(query,con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@searchInput", "%" + searchInput + "%"); //string.Format("%{0}%",organization)
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    ds.DataSetName = "userSuggestionsForNamePhone";
                    da.Fill(ds);

                    ds.AcceptChanges();
                    return ds;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                con = null;
            }
            //return null;  
        }


        /// <summary>
        /// Method to get user details by cn name
        /// </summary>
        /// <param name="Name"></param>
        /// <returns></returns>
        public DataSet GetUsersDetailsByName(string Name)
        {
            SqlConnection con;
            try
            {
                con = GetConnection();
                con.Open();

                using (SqlCommand cmd = new SqlCommand("select * from ActiveDirectoryUserDataReplica as users where users.cn = @cn", con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@cn", Name); //string.Format("%{0}%",organization)
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    return ds;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con = null;
            }
        }


        /// <summary>
        /// Method to get departments belonging to organization unit
        /// </summary>
        /// <param name="organization"></param>
        /// <returns></returns>
        public DataSet GetDepartmentByOrganizationUnit(string organization)
        {
            SqlConnection con;
            try
            {
                con = GetConnection();
                con.Open();

                using (SqlCommand cmd = new SqlCommand("select distinct(department) from ActiveDirectoryUserDataReplica where organizationUnit like @organization", con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@organization", "%" + organization + "%"); //string.Format("%{0}%",organization)
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    return ds;              
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                con = null;
            }
            return null;
        }



        public DataSet GetUsersByDepartmentAndOrganizationUnit(string organization, string department)
        {
            SqlConnection con;
            try
            {
                con = GetConnection();
                con.Open();

                string query = null;
                bool isAllDepartment = false;

                if (department.Equals("All", StringComparison.InvariantCultureIgnoreCase))
                {
                    query = "select * from ActiveDirectoryUserDataReplica where organizationUnit like @organization ";
                    isAllDepartment = true;
                }
                else
                {
                    query = "select * from ActiveDirectoryUserDataReplica where organizationUnit like @organization and department = @department";
                }

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@organization", "%" + organization + "%"); //string.Format("%{0}%",organization)
                    if (!isAllDepartment)
                    {
                        cmd.Parameters.AddWithValue("@department", department);
                    }
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    return ds; 
                }
            }
            catch (Exception e)
            {
            }
            finally
            {
                con = null;
            }
            return null;
        }


    }
}