﻿using PeopleFinder.BusinessLogicLayer;
using PeopleFinder.DataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.InteropServices;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PeopleFinder.UploadImage
{
    public partial class Login : System.Web.UI.Page
    {
        [DllImport("ADVAPI32.dll", EntryPoint = "LogonUserW", SetLastError = true, CharSet = CharSet.Auto)]
        public static extern bool LogonUser(string lpszUsername, string lpszDomain,
        string lpszPassword, int dwLogonType, int dwLogonProvider, ref IntPtr phToken);


        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Session["AuthenSuccess"] = false;

                BusinessLogic bl = new BusinessLogic();

                ddlDomain.DataSource = bl.populateRI();
                ddlDomain.DataTextField = "RI_Abbrev";
                ddlDomain.DataValueField = "RI_Abbrev";
                ddlDomain.DataBind();


                //ddlDomain.DataTextField = "RI_Abbrev";
                //ddlDomain.DataValueField = "RI_LoginDomain";

                //multiple entries of same value as login domain is same for multiple organizations
                //ddlDomain.DataTextField = "RI_LoginDomain";
                //ddlDomain.DataValueField = "RI_Abbrev";

                if (Request.QueryString["session"] != null)
                {
                    if (Request.QueryString["session"].ToString() == "Timeout")
                    {
                        pnlError.Visible = true;
                        lblErrMsg.Visible = true;
                        lblErrMsg.Text = "Session Timeout. Please log in again.";

                    }
                }

            }
            //else 
            //{
            //    if (string.IsNullOrWhiteSpace(lblDomain.Text)) 
            //    {

            //    }

            //}
        }


        protected void ddlDomain_DataBound(object sender, EventArgs e)
        {
            ddlDomain.Items.Insert(0, new ListItem("select domain", "0"));
            ddlDomain.SelectedIndex = 0;
        }

        protected void ddlDomain_SelectedIndexChanged(object sender, EventArgs e)
        {
            //if (ddlDomain.SelectedIndex != 0)
            if (ddlDomain.SelectedItem.Value != "0")
                GetDomainAndSite();
            else
            {
                lblDomain.Text = "";
                hidRI.Value = "";
            }
        }

        private void GetDomainAndSite()
        {
            RIInfoDB db = new RIInfoDB();
            BusinessLogic bl = new BusinessLogic();

            lblDomain.Text = db.GetRILoginDomain(ddlDomain.SelectedItem.Text) + "\\";

            //lblRIFullName.Text = bl.GetRIEntireNameByAbbr(ddlDomain.SelectedItem.Text);          //(ddlDomain.SelectedValue);   //  oRIDB.getRIFullnameByAbbr(ddlRI.SelectedValue);

            hidRI.Value = ddlDomain.SelectedValue;
        }



        protected void btnLogin_Click(object sender, EventArgs e)
        {
            lblErrMsg.Text = "";
            lblErrMsg.Visible = false;
            pnlError.Visible = false;

            string domainName = lblDomain.Text.Replace(@"\", "");
            // Extract domain name 
            //form provide DomainUsername e.g Domainname\Username
            string userName = txtUsername.Text.Trim();
            // Extract user name 
            //from provided DomainUsername e.g Domainname\Username
            IntPtr token = IntPtr.Zero;

            if (string.IsNullOrWhiteSpace(lblDomain.Text))
            {
                pnlError.Visible = true;
                lblErrMsg.Visible = true;
                lblErrMsg.Text = "Log in unsuccessful. Please select domain and enter credential, then try again.";
            }



            else
            {

                bool result = LogonUser(userName, domainName, txtPwd.Text, 2, 0, ref token);

                if (result)
                {
                    //If Successfully authenticated
                    Session["AuthenSuccess"] = true;
                    Session["UserId"] = txtUsername.Text.Trim();
                    Session["RI"] = ddlDomain.SelectedItem.Text;
                    //Session("LoginDomain") = lblDomain.Text.Trim 
                    RIInfoDB db = new RIInfoDB();
                    StaffInfo staff = new StaffInfo();
                    Session["LoginDomain"] = db.GetRILDAPDomain(Session["RI"].ToString());  //'lblDomain.Text.Trim.Replace("\", "")

                    DataRow loggedInUserDetails = staff.GetStaffFullNameByRI(Session["UserId"].ToString(), Session["LoginDomain"].ToString());
                    Session["FullName"] = loggedInUserDetails["cn"].ToString();
                    Session["email"] = loggedInUserDetails["mail"].ToString();

                    //''If Successfully authenticated
                    //'Session("AuthenSuccess") = True
                    //'Session("UserId") = "nedan" 'LCase(txtUserid.Text.Trim)
                    //'Session("RI") = "ASTAR" 'ddlRI.SelectedItem.Text
                    //''Session("LoginDomain") = lblDomain.Text.Trim 
                    //'Session("LoginDomain") = "A-STAR_HQ" ' lblDomain.Text.Trim.Replace("\", "")
                    //'Session("FullName") = objLoginDetails.getStaffFullNameByRI(Session("UserId"), Session("LoginDomain"))


                    //GetRole();

                    //if (Convert.ToBoolean(Session["HRP"]))
                    //    Response.Redirect("Home.aspx");
                    //else if (Session["USER"] != null && Session["USER"].ToString() == "True")
                    //{
                    //    Response.Redirect("UploadImage.aspx");
                    //}
                    //else
                    //{
                    //    pnlError.Visible = true;
                    //    lblErrMsg.Visible = true;
                    //    lblErrMsg.Text = "You do have the Admin permission for this portal.";
                    //}

                    //'When an unauthenticated user try to visit any page of your 
                    //'application that is only allowed to view by authenticated users then,
                    //'ASP.NET automatically redirect the user to login form and add 
                    //'ReturnUrl query string parameter that contain the URL of a page that 
                    //'user want to visit, So that we can redirect the user to that pa2ge after 
                    //'authenticated. FormsAuthentication.RedirectFromLoginPage() method 
                    //'not only redirect the user to that page but also generate an 
                    //'authentication token for that user.

                    //'If String.IsNullOrEmpty(Request.QueryString("ReturnUrl")) Then
                    //'    FormsAuthentication.RedirectFromLoginPage(txtUserid.Text, False)
                    //'Else
                    //'    'If ReturnUrl query string parameter is not present, 
                    //'    'then we need to generate authentication token and redirect 
                    //'    'the user to any page ( according to your application need). 
                    //'    'FormsAuthentication.SetAuthCookie() 
                    //'    'method will generate Authentication token 
                    //'    FormsAuthentication.SetAuthCookie(txtUserid.Text, False)
                    //'    Response.Redirect("home.aspx")
                    //'End If

                    //pnlError.Visible = true;
                    //lblErrMsg.Visible = true;
                    //lblErrMsg.Text = "Log in successful.";

                    Response.Redirect("/UploadImage/UploadImage.aspx");

                }
                else
                {
                    //'If not authenticated then display an error message
                    pnlError.Visible = true;
                    lblErrMsg.Visible = true;
                    if (lblDomain.Text == @"domain\")
                        lblErrMsg.Text = "Log in unsuccessful. Please select domain and try again.";
                    else
                        lblErrMsg.Text = "Log in unsuccessful. Please enter again.";

                }

            }

        }


    }
}