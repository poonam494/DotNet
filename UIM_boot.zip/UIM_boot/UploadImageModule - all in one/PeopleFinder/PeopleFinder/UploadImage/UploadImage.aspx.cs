﻿using PeopleFinder.BusinessLogicLayer;
using PeopleFinder.DataAccess;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PeopleFinder.UploadImage
{
    public partial class UploadImage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {

                if (Context.Session != null)
                {
                    if (Session.IsNewSession)
                    {
                        string cookieHeader = Request.Headers["Cookie"];
                        //checking if session timedout then redirect to ogin
                        if ((null != cookieHeader) && (cookieHeader.IndexOf("ASP.NET_SessionId") >= 0))
                        {
                            string queryString = Server.UrlEncode("session=Timeout");
                            Response.Redirect("Login.aspx?" + queryString);
                            //show msg for session ended. login again.
                        }
                        else
                        {
                            Response.Redirect("Login.aspx");
                        }
                    }
                    else if (Convert.ToBoolean(Session["AuthenSuccess"].ToString()))
                    {
                        string cn = Session["FullName"].ToString();
                        string email = Session["email"].ToString();
                        PeopleFinderService.PeopleFinderWebServiceSoapClient ws = new PeopleFinderService.PeopleFinderWebServiceSoapClient();
                        DataSet ds = ws.GetUsersDetailsByName(cn);

                        StaffInfo staffInfo = new StaffInfo();
                        DataSet dsUser = staffInfo.GetUserDetails(email);

                        #region file from DB check

                        if (File.Exists(HttpContext.Current.Server.MapPath(Path.Combine(dsUser.Tables[0].Rows[0]["basepath"].ToString() + dsUser.Tables[0].Rows[0]["filename"]))))
                        {
                            //user.imageLocation = HttpContext.Current.Server.MapPath(Path.Combine(row["basepath"].ToString() + row["filename"]));      //Path.Combine("/ProfilePic/" + user.cn + ".png");
                            
                            //dsUser.Tables[0].Rows[0]["imageLocation"] = Server.MapPath(Path.Combine(".." + dsUser.Tables[0].Rows[0]["basepath"].ToString() + dsUser.Tables[0].Rows[0]["filename"].ToString()));      //Path.Combine("/ProfilePic/" + user.cn + ".png");
                            dsUser.Tables[0].Rows[0]["imageLocation"] = Path.Combine(dsUser.Tables[0].Rows[0]["basepath"].ToString() + dsUser.Tables[0].Rows[0]["filename"].ToString());

                        }
                        else
                        {
                            ds.Tables[0].Rows[0]["imageLocation"] = "images/not_available.jpg";
                        }

                        #endregion

                        Repeater1.DataSource = dsUser;
                        Repeater1.DataBind();
                        //Response.Redirect(Request.RawUrl);
                    }
                    else
                    {
                        Response.Redirect("Login.aspx");
                    }
                } 



                //string cn = Session["FullName"].ToString();
                //string email = Session["email"].ToString();
                //PeopleFinderService.PeopleFinderWebServiceSoapClient ws = new PeopleFinderService.PeopleFinderWebServiceSoapClient();
                //DataSet ds = ws.GetUsersDetailsByName(cn);

                //StaffInfo staffInfo = new StaffInfo();
                //DataSet dsUser = staffInfo.GetUserDetails(email);
                //Repeater1.DataSource = dsUser;
                //Repeater1.DataBind();
            }

        }


        protected void btnUploadImage_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            //unique cn value
            var documentId = btn.CommandArgument;

            //Get the Repeater Item reference
            RepeaterItem item = btn.NamingContainer as RepeaterItem;

            var fileSelection = (FileUpload)item.FindControl("fileSelection");
            var filename = fileSelection.PostedFile.FileName;

            if (fileSelection.PostedFile != null && fileSelection.PostedFile.ContentLength > 0)
            {
                //fileSelection.PostedFile.SaveAs(Server.MapPath(Path.Combine("~/ProfilePic/", Path.GetFileName(filename))));

                //renaming uploaded file to cn unique name
                string extension = Path.GetExtension(fileSelection.PostedFile.FileName);
                string imageDirectoryPath = ConfigurationManager.AppSettings["ImageDirectoryPath"].ToString();


                if (extension.ToLower().Equals(".jpg", StringComparison.InvariantCultureIgnoreCase) || extension.ToLower().Equals(".png", StringComparison.InvariantCultureIgnoreCase))
                {

                    fileSelection.PostedFile.SaveAs(Server.MapPath(Path.Combine("~" + imageDirectoryPath, documentId + extension))); // + documentId + extension);  

                    //saving  file location directory and filename differently
                    BusinessLogic businessLogic = new BusinessLogic();
                    businessLogic.SaveFileDetails(documentId, imageDirectoryPath, documentId + extension);

                   // HttpContext.Current.Cache.Insert(documentId + extension, documentId + extension, new System.Web.Caching.CacheDependency(Server.MapPath(Path.Combine("~" + imageDirectoryPath, documentId + extension)), new DateTime()));
                    string msg = "File uploaded successfully";

                    // Javascript
                    //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "MessageDialog", "alert('" + msg + "');", true);
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "MessageDialog", "UploadMessage('" + msg + "')", true);
                    //Response.Redirect(Request.RawUrl);
                    
                    //jquery dialog
                    //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "MessageDialog", "ShowMessageDialog('" + msg + "')", true);

                    

                    //string imageBasePath = ConfigurationManager.AppSettings["ImageBasePath"].ToString();
                    //string imageDirectoryPath = ConfigurationManager.AppSettings["ImageDirectoryPath"].ToString();

                    //string imageDirectoryPathToCombine = imageDirectoryPath.Replace("/", @"\");

                    //if (imageDirectoryPathToCombine.StartsWith("/") || imageDirectoryPathToCombine.StartsWith(@"\"))
                    //{
                    //    imageDirectoryPathToCombine = imageDirectoryPathToCombine.Substring(1);
                    //}

                    //string imageFullBasePath = Path.Combine(imageBasePath, imageDirectoryPathToCombine);

                    //string destinationPath = Path.Combine(imageFullBasePath, documentId.ToString() + "_pending" + extension);

                    ////File.Copy(fileSelection.PostedFile.FileName, destinationPath, true);
                    //File.Copy(Server.MapPath(Path.Combine("~/UserImages/Pending/", documentId + extension)), destinationPath, true);


                    //UploadImageDB uplDB = new UploadImageDB();
                    //int requestId = uplDB.InsertUploadImageRequest(Session["RI"].ToString(), documentId, Session["UserId"].ToString(), Session["email"].ToString(), Session["FullName"].ToString(), "PENDING");

                }
                else 
                {
                  //  pnlError.Visible = true;
                    lblErrMsg.Visible = true;
                    lblErrMsg.Text = "Please select a file having jpg or png file format";
                }

            }
        }



    }
}