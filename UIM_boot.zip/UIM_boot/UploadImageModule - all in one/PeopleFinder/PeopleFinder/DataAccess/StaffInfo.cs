﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace PeopleFinder.DataAccess
{
    public class StaffInfo
    {
        private SERCLDAP.cLDAPDirectory LDAPDirectory = new SERCLDAP.cLDAPDirectory();

        public DataRow GetStaffFullNameByRI(string strUserID, string strRI)  //string
        {

             try 
	        {	        
		        DataSet ds = new DataSet();
                DataView dv = new DataView();
                string getStaffFullNameByRI = "";

                  if(strRI == "NMC")
                    strRI = "SIMTech";
            

                if(strRI == "ASTAR")
                    strRI = "A-STAR_HQ";


                ds = GetStaffDetailsByRI(strRI);
                dv = ds.Tables[0].DefaultView;
                dv.RowFilter = "uid = '" + strUserID + "'";

                if (dv != null)
                {
                    //if (dv.ToTable().Rows[0]["cn"] != null)
                    //{
                    //    getStaffFullNameByRI = dv.ToTable().Rows[0]["cn"].ToString();
                    //}
                    //else
                    //{
                    //    getStaffFullNameByRI = "Not found";
                    //}
                    return dv.ToTable().Rows[0];
                }
                else 
                {
                    //getStaffFullNameByRI = "Not found";
                    return null;
                }
               // return getStaffFullNameByRI;
	        }
	        catch (Exception)
	        {
                throw;
               // getStaffFullNameByRI = strUserID;
	        }

            }


          public DataSet GetStaffDetailsByRI(string strRI) 
          {
            DataSet dsStaffDetailsByRI = new DataSet();


            //'Select Case strRI
            //'    Case "SCEI"
            //'        dsStaffDetails = LDAPDirectory.getSCEIStaffs
            //'    Case "IHPC"
            //'        dsStaffDetails = LDAPDirectory.getIHPCStaffs
            //'    Case "DSI"
            //'        dsStaffDetails = LDAPDirectory.getDSIStaffs
            //'    Case "IMRE"
            //'        dsStaffDetails = LDAPDirectory.getIMREStaffs
            //'    Case Else
            //'        dsStaffDetails = LDAPDirectory.getAllStaffsByRI(strRI)
            //'End Select

            //'cn - Fullname
            //'ou - Department
            //'title - title
            //'mail - Email Address
            //'uid - username
            //'telephoneNumber - telephoneNumber
            //'sn - Surname
            //'o - company
            //'givenName - Given name (without surname)

            if(strRI == "NMC")
                strRI = "SIMTECH";
            
            if(strRI == "ASTAR")
                strRI = "A-STAR_HQ";
            

            dsStaffDetailsByRI = LDAPDirectory.getStaffsByRI(strRI);

            return dsStaffDetailsByRI;


          }

          //private static SqlConnection GetConnection()
          //{
          //    try
          //    {
          //        string connectionString = GetConnectionString();  //ConfigurationManager.ConnectionStrings["DevDatabaseConnectionString"].ConnectionString;
          //        SqlConnection connection = new SqlConnection(connectionString);
          //        return connection;
          //    }
          //    catch (Exception e)
          //    {
          //        throw e;
          //    }
          //}


          private static string GetConnectionString()
          {
              try
              {
                  string prodEnvirorment = ConfigurationManager.AppSettings["IS_PROD"].ToString();
                  string uatEnvirorment = ConfigurationManager.AppSettings["IS_UAT"].ToString();
                  string devEnvirorment = ConfigurationManager.AppSettings["IS_DEV"].ToString();

                  string dbConnectionString = null;

                  if (Convert.ToBoolean(Convert.ToInt16(prodEnvirorment)))
                  {
                      dbConnectionString = ConfigurationManager.ConnectionStrings["ProdDatabaseConnectionString"].ConnectionString;
                  }
                  else if (Convert.ToBoolean(Convert.ToInt16(uatEnvirorment)))
                  {
                      dbConnectionString = ConfigurationManager.ConnectionStrings["UatDatabaseConnectionString"].ConnectionString;
                  }
                  else if (Convert.ToBoolean(Convert.ToInt16(devEnvirorment)))
                  {
                      dbConnectionString = ConfigurationManager.ConnectionStrings["DevDatabaseConnectionString"].ConnectionString;
                  }

                  return dbConnectionString;
              }
              catch (Exception)
              {
                  throw;
              }
          }

          public DataSet GetUserDetails(string email)
          {
              SqlConnection con = null;

              try
              {
                  con = DBConnection.GetConnection();  //GetConnection();
                  con.Open();
                  using (SqlCommand cmd = new SqlCommand("select users.*,userimage.basepath,userimage.filename from ActiveDirectoryUserDataReplica as users left outer join UserImageFileDetails as userimage on users.cn = userimage.cn where users.mail like @mail", con))   //"select * from ActiveDirectoryUserDataReplica where mail like @mail"
                  {
                      cmd.CommandType = CommandType.Text;

                      cmd.Parameters.AddWithValue("@mail", email);

                      SqlDataAdapter da = new SqlDataAdapter(cmd);
                      DataSet ds = new DataSet();
                      da.Fill(ds);

                      if (ds.Tables[0].Rows.Count > 0)
                      {
                          return ds;
                      }
                      else
                      {
                          return null;
                      }
                  }
              }
              catch (Exception)
              {
                  throw;
                  //return null;
              }
              finally
              {
                  con.Close();
                  con.Dispose();
                  con = null;
              }

          }





    }
}