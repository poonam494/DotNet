﻿using PeopleFinderUploadImage.dataAccess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace PeopleFinderUploadImage.businessLogic
{
    public class BusinessLogic
    {


        public DataSet populateRI()
        {
            try
            {
                 Dictionary<string, string> RIDictionary = new Dictionary<string, string>();

                 RIInfoDB db = new RIInfoDB();
                 DataSet ds = db.GetRIs();

                //    foreach (DataRow row in ds.Tables[0].Rows)
                //    {
                //        string RI_Abbrev = row["RI_Abbrev"].ToString();
                //        string RI_LoginDomain = row["RI_LoginDomain"].ToString();

                //        RIDictionary.Add(RI_LoginDomain, RI_Abbrev);
                //    }
                
                //return RIDictionary;


                 return ds;


            }
            catch (Exception)
            {
                
                throw;
            }
            return null;
        }


        public string GetRIEntireNameByAbbr(string riAbbr) 
        {
            RIInfoDB db = new RIInfoDB();

            DataSet ds = db.GetRIs();
            DataView dataView =  ds.Tables[0].DefaultView;

            dataView.RowFilter = "RI_Abbrev = '" + riAbbr + "'";

            if(dataView.Count > 0)
            {
                DataTable dt = dataView.Table;
                return dt.Rows[0]["RI_Name"].ToString();
            }
            

            return null;
        }

    }
}