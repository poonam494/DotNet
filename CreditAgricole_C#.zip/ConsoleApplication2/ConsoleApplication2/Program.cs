﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {

            string s = "@oonam";

             char c = s[0];

             //string result = solution(s);

            int result = solution2(123456);


        //if (Upper(c))
        //{  // please fix condition
        //    return "upper";
        //} else if (Lower(c))
        //{  // please fix condition
        //    return "lower";
        //} else if (Digit(c))
        //{  // please fix condition
        //    return "digit";
        //} else {
        //    return "other";
        //}


            Console.WriteLine(result);
            
            Console.ReadLine();


        }


        static Boolean Upper(char c) 
        {
            Regex regex = new Regex("[A-Z]");
            Match match = regex.Match(c.ToString());

            if (match.Success)
                return true; 

            return false;
        }


        static Boolean Lower(char c) 
        {
            Regex regex = new Regex("[a-z]");
            Match match = regex.Match(c.ToString());

            if (match.Success)
                return true; 

            return false;
        }


        static Boolean Digit(char c) 
        {
            Regex regex = new Regex("[0-9]");
            Match match = regex.Match(c.ToString());

            if (match.Success)
                return true; 

            return false;
        }


        //1 Q
         public static String solution(String s) {
        char c = s[0];
        if (Upper(c))
        {  // please fix condition
            return "upper";
        }
        else if (Lower(c))
        {  // please fix condition
            return "lower";
        }
        else if (Digit(c))
        {  // please fix condition
            return "digit";
        }
        else
        {
            return "other";
        }
    }




         public static int solution2(int A)
         {
             // write your code in C# 6.0 with .NET 4.5 (Mono)

             string s = A.ToString();
             int length = s.Length;

             int halfLength = length / 2;

             string newString = null;
             for (int i = 0, j = s.Length -1 ; (i < s.Length) && (j > i); i++, j--)
             {
                 //for (int j = s.Length -1 ; j < length; j--)
                 //{
                 //    newString = newString + ;
                 //}

                 newString = newString + s[i] + s[j];

             }

             if (length % 2 != 0) 
             {
                int mid =  (length / 2) ;
                newString = newString + s[mid];

             }

             return Convert.ToInt32(newString);


         }





    }
}
