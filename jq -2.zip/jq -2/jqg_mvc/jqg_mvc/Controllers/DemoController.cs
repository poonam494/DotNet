﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace jqg_mvc.Controllers
{
    public class DemoController : Controller
    {
        // GET: Demo
        public ActionResult Index()
        {
            return View();
        }

        public JsonResult GetPersons(string sord, int page, int rows, string searchString)
        {
            //#1 Create Instance of DatabaseContext class for Accessing Database.  
            using (PersonEntities dbP = new PersonEntities())
            {
                //#2 Setting Paging  
                int pageIndex = Convert.ToInt32(page) - 1;
                int pageSize = rows;

                //#3 Linq Query to Get persons   
                var Results = dbP.tests.Select(
                    a => new
                    {
                        a.Id,
                        a.name,
                        a.location,
                        a.phone,
                        a.salary

                    }).ToList();

                //List<object> Results = new List<object>()
                //{
                //    new {Id = 1, name = "Poonam", location = "singapore", phone = "1234567",salary= "40000"},
                //    new {Id = 2, name = "Priti", location = "singapore", phone = "1234567",salary= "40000"}
                //};

                //#4 Get Total Row Count  
                int totalRecords = Results.Count();
                var totalPages = (int)Math.Ceiling((float)totalRecords / (float)rows);

                //#5 Setting Sorting  
                //if(!String.IsNullOrEmpty(sort))
                //{ 
                //if (sort.ToUpper() == "DESC")
                //{
                //    Results = Results.OrderByDescending(s => s.Id);
                //    Results = Results.Skip(pageIndex * pageSize).Take(pageSize);
                //}
                //else
                //{
                //    Results = Results.OrderBy(s => s.Id);
                //    Results = Results.Skip(pageIndex * pageSize).Take(pageSize);
                //}
                //}
                ////#6 Setting Search  
                //if (!string.IsNullOrEmpty(searchString))
                //{
                //    Results = Results.Where(m => m.location == searchString);
                //}
                //#7 Sending Json Object to View.  
                var jsonData = new
                {
                    total = totalPages,
                    page,
                    records = totalRecords,
                    rows = Results
                };
                return Json(jsonData, JsonRequestBehavior.AllowGet);
            }
        }
    }
}