/* RI SP Creation */
/* 1. All RI selection */
USE [PeopleFinder]
GO

/****** Object:  StoredProcedure [dbo].[p_mResearchInstitute_S]   ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




CREATE PROCEDURE [dbo].[p_mResearchInstitute_S] AS

SELECT * FROM t_mResearchInstitute where RI_Deleted = 0
ORDER BY RI_Name



GO




/* 2. select RI by abbr */
USE [PeopleFinder]
GO

/****** Object:  StoredProcedure [dbo].[p_mResearchInstitute_S_By_Abbr]    ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




create PROCEDURE [dbo].[p_mResearchInstitute_S_By_Abbr]
(
	@strAbbr varchar(50) 
)
AS

SELECT * FROM t_mResearchInstitute
where RI_Abbrev = @strAbbr







GO



/* 3. select all RI name with Abbr in bracket*/
USE [PeopleFinder]
GO

/****** Object:  StoredProcedure [dbo].[p_mResearchInstitute_S_Full]   ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[p_mResearchInstitute_S_Full] AS

SELECT *, RI_Name + ' (' + RI_Abbrev + ')' AS RIFullTerm FROM t_mResearchInstitute 
where [Entity_Deleted] = 0
ORDER BY [RI_Index] ASC,[RI_Name]ASC

GO

