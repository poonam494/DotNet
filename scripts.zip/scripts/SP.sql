USE PeopleFinder
GO

CREATE PROCEDURE spADUsersReplica
AS
BEGIN
	
	INSERT INTO ActiveDirectoryUserDataReplica (displayName,title,company,mail,telephoneNumber,mobile,department,physicalDeliveryOfficeName,distinguishedName,cn,organizationUnit,imageLocation,createdDate,createdBy)
	select displayName,title,company,mail,telephoneNumber,mobile,department,physicalDeliveryOfficeName,distinguishedName,cn,organizationUnit,imageLocation,createdDate,createdBy  
	from ActiveDirectoryUserData
END