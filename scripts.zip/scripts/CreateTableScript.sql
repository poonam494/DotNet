CREATE DATABASE PeopleFinder;
GO

USE PeopleFinder
GO

IF NOT EXISTS(SELECT * FROM sys.Objects WHERE  Object_id = OBJECT_ID(N'ActiveDirectoryUserData') AND Type = N'U')
BEGIN
   PRINT 'ActiveDirectoryUserData Table does not Exists'
   PRINT 'Create Table ActiveDirectoryUserData'

   CREATE TABLE ActiveDirectoryUserData (
   RECORD_NO INT IDENTITY(1,1),
   displayName NVARCHAR(250),
   title NVARCHAR(250),
   company NVARCHAR(250),
   mail NVARCHAR(500),
   telephoneNumber NVARCHAR(50),
   mobile NVARCHAR(50),
   department NVARCHAR(250),
   physicalDeliveryOfficeName NVARCHAR(500),
   distinguishedName NVARCHAR(500),
   cn NVARCHAR(300),
   organizationUnit NVARCHAR(100),
   imageLocation NVARCHAR(500),
   createdDate datetime DEFAULT GETDATE(),
   createdBy NVARCHAR(50) CONSTRAINT CREATEDBY_CONSTRAINT  DEFAULT 'SYSTEM'
   ) 


   PRINT 'TABLE ActiveDirectoryUserData CREATED'



END



/*--------------------------------------- REPLICA Table ----------------------------------------------------------------------------------- */

IF NOT EXISTS(SELECT * FROM sys.Objects WHERE  Object_id = OBJECT_ID(N'ActiveDirectoryUserDataReplica') AND Type = N'U')
BEGIN
   PRINT 'ActiveDirectoryUserDataReplica Table does not Exists'
   PRINT 'Create Table ActiveDirectoryUserDataReplica'

   CREATE TABLE ActiveDirectoryUserDataReplica (
   RECORD_NO INT IDENTITY(1,1),
   displayName NVARCHAR(250),
   title NVARCHAR(250),
   company NVARCHAR(250),
   mail NVARCHAR(500),
   telephoneNumber NVARCHAR(50),
   mobile NVARCHAR(50),
   department NVARCHAR(250),
   physicalDeliveryOfficeName NVARCHAR(500),
   distinguishedName NVARCHAR(500),
   cn NVARCHAR(300),
   organizationUnit NVARCHAR(100),
   imageLocation NVARCHAR(500),
   createdDate datetime DEFAULT GETDATE(),
   createdBy NVARCHAR(50) CONSTRAINT REPLICA_CREATEDBY_CONSTRAINT  DEFAULT 'SYSTEM'
   ) 


   PRINT 'ActiveDirectoryUserDataReplica TABLE CREATED'



END



/* ---------------------------------------- organization table --------------------------------------------------------------------------------------- */

IF NOT EXISTS(SELECT * FROM sys.Objects WHERE  Object_id = OBJECT_ID(N'ActiveDirectoryOrganizations') AND Type = N'U')
BEGIN
   PRINT 'ActiveDirectoryOrganizations Table does not Exists'
   PRINT 'Create Table ActiveDirectoryOrganizations'

   CREATE TABLE ActiveDirectoryOrganizations (
   RECORD_NO INT IDENTITY(1,1),
   organizationName NVARCHAR(250),
   path NVARCHAR(500),
   createdDate datetime DEFAULT GETDATE(),
   createdBy NVARCHAR(50) CONSTRAINT ORG_CREATEDBY_CONSTRAINT  DEFAULT 'SYSTEM'
   ) 


   PRINT 'ActiveDirectoryOrganizations TABLE CREATED'



END




















