/****** Object:  Table [dbo].[t_mResearchInstitute]    ******/

USE [PeopleFinder]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[t_mResearchInstitute](
	[RI_ID] [int] IDENTITY(1,1) NOT FOR REPLICATION NOT NULL,
	[RI_Name] [varchar](150) NOT NULL,
	[RI_Abbrev] [varchar](50) NOT NULL,
	[RI_Index] [varchar](2) NULL,
	[RI_LoginDomain] [varchar](50) NULL,
	[RI_LDAPDomain] [varchar](50) NULL,
	[RI_Deleted] [bit] NOT NULL,
	[Entity_Deleted] [bit] NULL,
	[RI_Council] [varchar](50) NULL,
	[RecipientTo] [nvarchar](4000) NULL,
	[RecipientCC] [nvarchar](4000) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO
GO

