USE [PeopleFinder]

GO

IF NOT EXISTS(SELECT * FROM sys.Objects WHERE  Object_id = OBJECT_ID(N'UserImageFileDetails') AND Type = N'U')
BEGIN
   PRINT 'Table does not Exists'
   PRINT 'Create Table'

   CREATE TABLE UserImageFileDetails (
   RECORD_NO INT IDENTITY(1,1),
   cn NVARCHAR(300),
   basepath NVARCHAR(500),
   filename NVARCHAR(500),
   createdDate datetime DEFAULT GETDATE(),
   updatedDate datetime DEFAULT GETDATE()
   ) 


   PRINT 'TABLE CREATED'



END




/*-----------------SP for upload image--------------------------------------------------------*/

USE [PeopleFinder]

GO

IF (OBJECT_ID('spSaveUserImageFileDetails') IS NOT NULL)
  DROP PROCEDURE spSaveUserImageFileDetails

GO
  
CREATE PROCEDURE spSaveUserImageFileDetails
@cn NVARCHAR(300),
@basepath NVARCHAR(500),
@filename NVARCHAR(500)
AS
BEGIN
	IF EXISTS(SELECT * FROM UserImageFileDetails WHERE cn = @cn)
		BEGIN
			UPDATE UserImageFileDetails
			SET basepath = @basepath,
				filename = @filename,
				updatedDate = GETDATE()
			WHERE cn = @cn

		END	
	ELSE
		BEGIN
			INSERT INTO UserImageFileDetails(cn,basepath,filename) 
			VALUES(@cn,@basepath,@filename)
		END
	
END

GO