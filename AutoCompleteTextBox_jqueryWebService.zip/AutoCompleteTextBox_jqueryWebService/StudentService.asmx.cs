﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace AutoCompleteTextBox_jqueryWebService
{
    /// <summary>
    /// Summary description for StudentService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]
    public class StudentService : System.Web.Services.WebService
    {

        [WebMethod]
        public List<String> GetStudentNames(string StudentName)
        {
            String connectionString = ConfigurationManager.ConnectionStrings["DbConnectionString"].ConnectionString;
            //return "Hello World";
            List<String> StudentNames = new List<string>();


            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("spGetMachingStudentNames", con);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlParameter param = new SqlParameter("@StudentName", StudentName);
                cmd.Parameters.Add(param);

                con.Open();

                SqlDataReader dr = cmd.ExecuteReader();

                while(dr.Read())
                {
                    StudentNames.Add(dr["Name"].ToString());
                }


            }
            return StudentNames;

        }
    }
}
