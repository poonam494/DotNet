﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PeopleFinderR.DataAccess
{
    interface IDataAccess
    {
        DataSet GetOrganizations();

        DataSet GetOrganizationUnitUsers(string organization);

        DataSet GetDepartmentByOrganizationUnit(string organization);

        DataSet GetUsersByDepartmentAndOrganizationUnit(string organization, string department);

        DataSet GetUsersByName(string name);

        DataSet GetUsersDetailsByName(string Name);

        void SaveUserImageFilePath(string cn, string filePath);

        void SaveFileDetails(string cn, string basepath, string filename);
    }
}
