﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace PeopleFinderR.DataAccess
{
    public class ActiveDirectoryDataAccess : IDataAccess
    {
        //ILog logger;

        private static SqlConnection GetConnection()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["DatabaseConnectionString"].ConnectionString;
            SqlConnection connection = new SqlConnection(connectionString);
            return connection;
        }

        public DataSet GetOrganizations()
        {
            SqlConnection con;
            try
            {
                con = GetConnection();
                con.Open();
                using (SqlCommand cmd = new SqlCommand("select distinct(organizationName) from ActiveDirectoryorganizations", con))
                {
                    cmd.CommandType = CommandType.Text;
                    //cmd.ExecuteReader();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    return ds;
                }

            }
            catch (Exception e)
            {
                throw;
            }
            finally
            {
                con = null;
            }
            return null;
        }

        #region one table
        //public DataSet GetOrganizationUnitUsers(string organization)
        //{
        //    SqlConnection con;
        //    try
        //    {
        //        con = GetConnection();
        //        con.Open();
        //        //using (SqlCommand cmd = new SqlCommand("select * from ActiveDirectoryUserDataReplica where organizationUnit like '%'+@organization+'%'", con))
        //        using (SqlCommand cmd = new SqlCommand("select * from ActiveDirectoryUserDataReplica where organizationUnit like @organization", con))
        //        {
        //            cmd.CommandType = CommandType.Text;
        //            cmd.Parameters.AddWithValue("@organization", "%" + organization + "%"); //string.Format("%{0}%",organization)
        //            SqlDataAdapter da = new SqlDataAdapter(cmd);
        //            DataSet ds = new DataSet();
        //            da.Fill(ds);


        //            return ds;
        //        }

        //    }
        //    catch (Exception e)
        //    {
        //        throw;
        //    }
        //    finally
        //    {
        //        con = null;
        //    }
        //    return null;
        //}


        //public DataSet GetUsersByDepartmentAndOrganizationUnit(string organization, string department)
        //{
        //    SqlConnection con;
        //    try
        //    {
        //        con = GetConnection();
        //        con.Open();

        //        string query = null;
        //        bool isAllDepartment = false;

        //        if (department.Equals("All", StringComparison.InvariantCultureIgnoreCase))
        //        {
        //            query = "select * from ActiveDirectoryUserDataReplica where organizationUnit like @organization ";
        //            isAllDepartment = true;
        //        }
        //        else
        //        {
        //            query = "select * from ActiveDirectoryUserDataReplica where organizationUnit like @organization and department = @department";
        //        }

        //        using (SqlCommand cmd = new SqlCommand(query, con))
        //        {
        //            cmd.CommandType = CommandType.Text;
        //            cmd.Parameters.AddWithValue("@organization", "%" + organization + "%"); //string.Format("%{0}%",organization)
        //            if (!isAllDepartment)
        //            {
        //                cmd.Parameters.AddWithValue("@department", department);
        //            }
        //            SqlDataAdapter da = new SqlDataAdapter(cmd);
        //            DataSet ds = new DataSet();
        //            da.Fill(ds);

        //            return ds;
        //        }

        //    }
        //    catch (Exception e)
        //    {
        //        throw;
        //    }
        //    finally
        //    {
        //        con = null;
        //    }
        //    return null;
        //}


        //public DataSet GetUsersDetailsByName(string Name)
        //{
        //    SqlConnection con;
        //    try
        //    {
        //        con = GetConnection();
        //        con.Open();

        //        using (SqlCommand cmd = new SqlCommand("select * from ActiveDirectoryUserDataReplica where cn = @cn", con))
        //        {
        //            cmd.CommandType = CommandType.Text;
        //            cmd.Parameters.AddWithValue("@cn", Name); //string.Format("%{0}%",organization)
        //            SqlDataAdapter da = new SqlDataAdapter(cmd);
        //            DataSet ds = new DataSet();
        //            da.Fill(ds);

        //            return ds;
        //        }

        //    }
        //    catch (Exception e)
        //    {
        //        throw;
        //    }
        //    finally
        //    {
        //        con = null;
        //    }
        //    return null;
        //}

        #endregion

        public DataSet GetDepartmentByOrganizationUnit(string organization)
        {
            SqlConnection con;
            try
            {
                con = GetConnection();
                con.Open();

                using (SqlCommand cmd = new SqlCommand("select distinct(department) from ActiveDirectoryUserDataReplica where organizationUnit like @organization", con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@organization", "%" + organization + "%"); //string.Format("%{0}%",organization)
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    return ds;
                }

            }
            catch (Exception e)
            {
                throw;
            }
            finally
            {
                con = null;
            }
            return null;
        }


        public DataSet GetUsersByName(string searchInput)
        {
            SqlConnection con;
            try
            {
                con = GetConnection();
                con.Open();

                string query = null;
                bool isNumberSearch = true;

                foreach (char c in searchInput)
                {
                    if (c < '0' || c > '9')
                    {
                        isNumberSearch = false;
                    }
                }

                if (!isNumberSearch)
                {
                    query = "select displayName,cn from ActiveDirectoryUserDataReplica where displayName like @seachInput";
                }
                else
                {
                    query = "select displayName,cn from ActiveDirectoryUserDataReplica where telephoneNumber like @seachInput";
                }

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@seachInput", "%" + searchInput + "%"); //string.Format("%{0}%",organization)
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    return ds;
                }

            }
            catch (Exception e)
            {
                throw;
            }
            finally
            {
                con = null;
            }
            return null;
        }


        public void SaveUserImageFilePath(string cn,string filePath) 
        {
            SqlConnection con;
            try
            {
                con = GetConnection();
                con.Open();

                using (SqlCommand cmd = new SqlCommand("Update ActiveDirectoryUserDataReplica Set imageLocation = @filepath where cn = @cn", con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@cn", cn);
                    cmd.Parameters.AddWithValue("@filepath", filePath);

                    cmd.ExecuteNonQuery();
                }

            }
            catch (Exception)
            {
                throw;
            }
            finally 
            {
                con = null;
            }
        }

        public void SaveFileDetails(string cn, string basepath, string filename) 
        {
            SqlConnection con;
            try
            {
                con = GetConnection();
                con.Open();

                using (SqlCommand cmd = new SqlCommand("spSaveUserImageFileDetails", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@cn", cn);
                    cmd.Parameters.AddWithValue("@basepath", basepath);
                    cmd.Parameters.AddWithValue("@filename", filename);

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception)
            {

                throw;
            }
            finally 
            {
                con = null;
            }
        }

        #region File details from DB
        public DataSet GetOrganizationUnitUsers(string organization)
        {
            SqlConnection con;
            try
            {
                con = GetConnection();
                con.Open();
                //using (SqlCommand cmd = new SqlCommand("select * from ActiveDirectoryUserDataReplica where organizationUnit like '%'+@organization+'%'", con))
                string query = "select users.*,userimage.basepath,userimage.filename from ActiveDirectoryUserDataReplica as users left outer join UserImageFileDetails as userimage on users.cn = userimage.cn where users.organizationUnit like @organization";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@organization", "%" + organization + "%"); //string.Format("%{0}%",organization)
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);


                    return ds;
                }

            }
            catch (Exception e)
            {
                throw;
            }
            finally
            {
                con = null;
            }
            return null;
        }



        public DataSet GetUsersByDepartmentAndOrganizationUnit(string organization, string department)
        {
            SqlConnection con;
            try
            {
                con = GetConnection();
                con.Open();

                string query = null;
                bool isAllDepartment = false;

                if (department.Equals("All", StringComparison.InvariantCultureIgnoreCase))
                {
                    query = "select users.*,userimage.basepath,userimage.filename from ActiveDirectoryUserDataReplica as users left outer join UserImageFileDetails as userimage on users.cn = userimage.cn where users.organizationUnit like @organization ";
                    isAllDepartment = true;
                }
                else
                {
                    query = "select users.*,userimage.basepath,userimage.filename from ActiveDirectoryUserDataReplica as users left outer join UserImageFileDetails as userimage on users.cn = userimage.cn where users.organizationUnit like @organization and users.department = @department";
                }

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@organization", "%" + organization + "%"); //string.Format("%{0}%",organization)
                    if (!isAllDepartment)
                    {
                        cmd.Parameters.AddWithValue("@department", department);
                    }
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    return ds;
                }

            }
            catch (Exception e)
            {
                throw;
            }
            finally
            {
                con = null;
            }
            return null;
        }


        public DataSet GetUsersDetailsByName(string Name)
        {
            SqlConnection con;
            try
            {
                con = GetConnection();
                con.Open();

                using (SqlCommand cmd = new SqlCommand("select users.*,userimage.basepath,userimage.filename from ActiveDirectoryUserDataReplica as users left outer join UserImageFileDetails as userimage on users.cn = userimage.cn where users.cn = @cn", con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@cn", Name); //string.Format("%{0}%",organization)
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    return ds;
                }

            }
            catch (Exception e)
            {
                throw;
            }
            finally
            {
                con = null;
            }
            return null;
        }

        #endregion
    }
}