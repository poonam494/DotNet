﻿using PeopleFinderR.Repository;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace PeopleFinderR
{
    /// <summary>
    /// Summary description for PeopleFinderWebService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]
    public class PeopleFinderWebService : System.Web.Services.WebService
    {

        [WebMethod]
        public DataSet GetOrganizationUnits()
        {
            //ActiveDirectoryDataAccess da = new ActiveDirectoryDataAccess();
            DataOperations operations = new DataOperations();
            DataSet orgs = operations.GetOrganizationUnits();

            return orgs;
        }


        [WebMethod]
        public DataSet GetOrganizationUnitUsers(string organization)
        {
            DataOperations operations = new DataOperations();
            DataSet users = operations.GetOrganizationUnitUsers(organization);
            return users;
        }

        [WebMethod]
        public DataSet GetDepartmentByOrganizationUnit(string organization)
        {
            DataOperations operations = new DataOperations();
            DataSet departments = operations.GetDepartmentByOrganizationUnit(organization);
            return departments;
        }


        [WebMethod]
        public DataSet GetUsersByDepartmentAndOrganizationUnit(string organization, string department)
        {
            DataOperations operations = new DataOperations();
            DataSet departments = operations.GetUsersByDepartmentAndOrganizationUnit(organization, department);
            return departments;
        }


        [WebMethod]
        //public Dictionary<string,string> GetUsersByName(string Name)
        public List<string> GetUsersByName(string Name)
        {
            DataOperations operations = new DataOperations();
            DataSet users = operations.GetUsersByName(Name);

            List<string> autoCompleteusers = new List<string>();

            //Dictionary<string, string> autoCompleteusers = new Dictionary<string, string>();
            foreach (DataRow item in users.Tables[0].Rows)
            {
                //autoCompleteusers.Add(item["cn"].ToString(), item["displayName"].ToString());
                autoCompleteusers.Add(item["displayName"].ToString() + ":" + item["cn"].ToString());
            }


            return autoCompleteusers;
        }


        [WebMethod]
        //public Dictionary<string,string> GetUsersByName(string Name)
        public DataSet GetUsersDetailsByName(string Name)
        {
            DataOperations operations = new DataOperations();
            DataSet user = operations.GetUsersDetailsByName(Name);

            //foreach (DataRow item in users.Tables[0].Rows)
            //{
            //    //autoCompleteusers.Add(item["cn"].ToString(), item["displayName"].ToString());
            //    autoCompleteusers.Add(item["displayName"].ToString() + "-" + item["cn"].ToString());
            //}


            return user;
        }

        [WebMethod]
        public void SaveUserImageFilePath(string cn, string filePath) 
        {
            DataOperations operations = new DataOperations();
            operations.SaveUserImageFilePath(cn, filePath);
        }

        [WebMethod]
        public void SaveFileDetails(string cn, string basepath, string filename) 
        {
            DataOperations operations = new DataOperations();
            operations.SaveFileDetails(cn, basepath, filename);

        }

    }
}
