﻿using PeopleFinder.BusinessLogicLayer;
using PeopleFinder.DataAccess;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PeopleFinder.UploadImage
{
    public partial class UploadImage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {

                if (Context.Session != null)
                {
                    if (Session.IsNewSession)
                    {
                        string cookieHeader = Request.Headers["Cookie"];
                        //checking if session timedout then redirect to ogin
                        if ((null != cookieHeader) && (cookieHeader.IndexOf("ASP.NET_SessionId") >= 0))
                        {
                            string queryString = Server.UrlEncode("session=Timeout");
                            //string qString = queryString + "session=ExpiredTime
                            Response.Redirect("Login.aspx?" + queryString);
                            
                        }
                        else
                        {
                            Response.Redirect("Login.aspx");
                        }
                    }
                    else if ((Session["AuthenSuccess"]!=null) && Convert.ToBoolean(Session["AuthenSuccess"].ToString()))
                    {
                        string cn = Session["FullName"].ToString();
                        string email = Session["email"].ToString();

                        StaffInfo staffInfo = new StaffInfo();
                        DataSet dsUser = staffInfo.GetUserDetails(email);

                        #region file from DB check

                        if (File.Exists(HttpContext.Current.Server.MapPath(Path.Combine(dsUser.Tables[0].Rows[0]["basepath"].ToString() + dsUser.Tables[0].Rows[0]["filename"]))))
                        {
                            //user.imageLocation = HttpContext.Current.Server.MapPath(Path.Combine(row["basepath"].ToString() + row["filename"]));      //Path.Combine("/ProfilePic/" + user.cn + ".png");

                            //dsUser.Tables[0].Rows[0]["imageLocation"] = Server.MapPath(Path.Combine(".." + dsUser.Tables[0].Rows[0]["basepath"].ToString() + dsUser.Tables[0].Rows[0]["filename"].ToString()));      //Path.Combine("/ProfilePic/" + user.cn + ".png");
                            dsUser.Tables[0].Rows[0]["imageLocation"] = Path.Combine(dsUser.Tables[0].Rows[0]["basepath"].ToString() + dsUser.Tables[0].Rows[0]["filename"].ToString());

                        }
                        else
                        {
                            dsUser.Tables[0].Rows[0]["imageLocation"] = "images/not_available.jpg";
                        }

                        #endregion

                        Repeater1.DataSource = dsUser;
                        Repeater1.DataBind();
                    }
                    else
                    {
                        Response.Redirect("Login.aspx");
                    }
                } 
            }

        }


        protected void btnUploadImage_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            //unique cn value
            var documentId = btn.CommandArgument;

            //Get the Repeater Item reference
            RepeaterItem item = btn.NamingContainer as RepeaterItem;

            var fileSelection = (FileUpload)item.FindControl("fileSelection");
            var filename = fileSelection.PostedFile.FileName;

            if (fileSelection.PostedFile != null && fileSelection.PostedFile.ContentLength > 0 && fileSelection.PostedFile.ContentLength <= 4096*1024)
            {
                //fileSelection.PostedFile.SaveAs(Server.MapPath(Path.Combine("~/ProfilePic/", Path.GetFileName(filename))));

                //renaming uploaded file to cn unique name
                string extension = Path.GetExtension(fileSelection.PostedFile.FileName);
                string imageDirectoryPath = ConfigurationManager.AppSettings["ImageDirectoryPath"].ToString();


                if (extension.ToLower().Equals(".jpg", StringComparison.InvariantCultureIgnoreCase) || extension.ToLower().Equals(".png", StringComparison.InvariantCultureIgnoreCase))
                {

                    fileSelection.PostedFile.SaveAs(Server.MapPath(Path.Combine("~" + imageDirectoryPath, documentId + extension))); // + documentId + extension);  

                    //saving  file location directory 
                    BusinessLogic businessLogic = new BusinessLogic();
                    //businessLogic.ToString(object.equals(objectA
                        
                    //businessLogic.SaveFileDetails(documentId,imageDirectoryPath, documentId + );
                    businessLogic.SaveFileDetails(documentId, imageDirectoryPath, documentId + extension);

                    string msg = "File uploaded successfully";

                    
                    //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "MessageDialog", "alert('" + msg + "');", true);
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "MessageDialog", "UploadMessage('" + msg + "')", true);
                    
                }
                else
                {
                    //  pnlError.Visible = true;
                    lblErrMsg.Visible = true;
                    lblErrMsg.Text = "Please select a file having jpg or png file format";
                }

            }
            else
            {
                pnlError.Visible = true;
                lblErrMsg.Visible = true;
                lblErrMsg.Text = "Please select a file having size upto 4MB ";
            }

        }

        protected void lnkBtnLogout_Click(object sender, EventArgs e)
        {
            //Session.Clear();
            //Session.Abandon();
            //Response.Redirect("/UploadImage/Login.aspx");
        }


    }
}