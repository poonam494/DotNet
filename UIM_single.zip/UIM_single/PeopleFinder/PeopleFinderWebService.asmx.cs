﻿using PeopleFinder.Repository;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace PeopleFinder
{
    /// <summary>
    /// Summary description for PeopleFinderWebService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]
    public class PeopleFinderWebService : System.Web.Services.WebService
    {

        [WebMethod]
        public DataSet GetOrganizationUnits()
        {
            DataOperations operations = new DataOperations();
            DataSet orgs = operations.GetOrganizationUnits();

            return orgs;
        }

        [WebMethod]
        public DataSet GetOrganizationUnitUsers(string organization)
        {
            DataOperations operations = new DataOperations();
            DataSet users =  operations.GetOrganizationUnitUsers(organization);
            return users;

        }

        [WebMethod]
        //public Dictionary<string,string> GetUsersByName(string Name)
        public List<string> GetUsersByName(string Name)
        {
            DataOperations operations = new DataOperations();
            DataSet users = operations.GetUsersByName(Name);

            List<string> autoCompleteusers = new List<string>();

            //Dictionary<string, string> autoCompleteusers = new Dictionary<string, string>();
            foreach (DataRow item in users.Tables[0].Rows)
            {
                string organizationUnitValue = item["organizationUnit"].ToString();

                //string organizationValue = item["organizationUnit"].ToString();
                //string o = item["organizationUnit"].ToString();
                //string org = item["organizationUnit"].ToString();
                //string ou = item["organizationUnit"].ToString();
                //string[] ouArr = ou.Split(',');
                //string firstOU = ouArr[0];

                //string ouName = null;

                //if (firstOU.Contains("="))
                //{
                //    ouName = firstOU.Split('=')[1];
                //}
                //else
                //{
                //    ouName = firstOU;
                //}

                //string[] orgName = ouName.Split(new char[] { '=' }, StringSplitOptions.RemoveEmptyEntries);
                //string orgNamefirstPart = orgName[0].Split(new char[] { '=' }, StringSplitOptions.RemoveEmptyEntries)[0];


                string orgValue = (organizationUnitValue.Split(',')[0]).Split('=')[1] ;
                autoCompleteusers.Add(item["displayName"].ToString() + "|" + orgValue + ":" + item["cn"].ToString());

                //autoCompleteusers.Add(item["displayName"].ToString() + ":" + item["cn"].ToString());
            }
            return autoCompleteusers;
        }

        
        [WebMethod]
        //public Dictionary<string,string> GetUsersByName(string Name)
        public DataSet GetUsersDetailsByName(string Name)
        {
            try
            {
                DataOperations operations = new DataOperations();
                DataSet user = operations.GetUsersDetailsByName(Name);

                return user;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        [WebMethod]
        public DataSet GetDepartmentByOrganizationUnit(string organization)
        {
            DataOperations operations = new DataOperations();
            DataSet departments = operations.GetDepartmentByOrganizationUnit(organization);
            return departments;
        }


        [WebMethod]
        public DataSet GetUsersByDepartmentAndOrganizationUnit(string organization, string department)
        {
            DataOperations operations = new DataOperations();
            DataSet users = operations.GetUsersByDepartmentAndOrganizationUnit(organization, department);


            return users;
        }

    }
}
