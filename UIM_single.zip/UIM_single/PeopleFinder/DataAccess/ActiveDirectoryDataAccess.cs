﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;

namespace PeopleFinder.DataAccess
{
    public class ActiveDirectoryDataAccess : IDataAccess
    {
        /// <summary>
        /// Method to get sql connection 
        /// </summary>
        /// <returns></returns>
        private static SqlConnection GetConnection()
        {
            try
            {
                string connectionString = GetConnectionString(); //ConfigurationManager.ConnectionStrings["DatabaseConnectionString"].ConnectionString;
                SqlConnection connection = new SqlConnection(connectionString);
                return connection;
            }
            catch (Exception e)
            {
                throw e;
            }
        }


        private static string GetConnectionString()
        {
            try
            {
                string prodEnvirorment = ConfigurationManager.AppSettings["IS_PROD"].ToString();
                string uatEnvirorment = ConfigurationManager.AppSettings["IS_UAT"].ToString();
                string devEnvirorment = ConfigurationManager.AppSettings["IS_DEV"].ToString();

                string dbConnectionString = null;

                if (Convert.ToBoolean(Convert.ToInt16(prodEnvirorment)))
                {
                    dbConnectionString = ConfigurationManager.ConnectionStrings["ProdDatabaseConnectionString"].ConnectionString;
                }
                else if (Convert.ToBoolean(Convert.ToInt16(uatEnvirorment)))
                {
                    dbConnectionString = ConfigurationManager.ConnectionStrings["UatDatabaseConnectionString"].ConnectionString;
                }
                else if (Convert.ToBoolean(Convert.ToInt16(devEnvirorment)))
                {
                    dbConnectionString = ConfigurationManager.ConnectionStrings["DevDatabaseConnectionString"].ConnectionString;
                }

                return dbConnectionString;
            }
            catch (Exception)
            {
                throw;
            }
        }




        /// <summary>
        /// Method to get organization names(i.e. RIs) from database
        /// </summary>
        /// <returns></returns>
        public DataSet GetOrganizations()
        {
           SqlConnection con;
           try
           {
               con = GetConnection();
               con.Open();

               DataSet ds = new DataSet();
               DataSet orgnames = new DataSet();
               orgnames.Tables.Add();
               orgnames.Tables[0].Columns.Add("organizationName");

               using (SqlCommand cmd = new SqlCommand("select distinct(organizationName) from ActiveDirectoryOrganizations", con))
               {
                   cmd.CommandType = CommandType.Text;
                   SqlDataAdapter da = new SqlDataAdapter(cmd);
                   // DataSet ds = new DataSet();

                   da.Fill(ds);

                  // foreach (DataRow row in ds.Tables[0].Rows)
                  // {
                  //     using (SqlCommand cmd1 = new SqlCommand("select count(*) from ActiveDirectoryUserDataReplica where organizationUnit like @orgName", con))
                  //     {
                  //         string orgName = row["organizationName"].ToString();
                  //         cmd1.CommandType = CommandType.Text;
                  //         cmd1.Parameters.AddWithValue("@orgName", "%" + orgName + "%");

                  //         SqlDataAdapter da1 = new SqlDataAdapter(cmd);
                  //         DataSet userCount = new DataSet();
                  //         da1.Fill(userCount);

                  //         if (userCount.Tables[0].Rows[0] != null)
                  //         {
                  //             int count = Convert.ToInt32(userCount.Tables[0].Rows[0][0].ToString());
                  //             //string userCounting = userCount.Tables[0].Rows[0]["counter"].ToString();

                  //             if (count > 0)  //Convert.ToBoolean(count)
                  //             {
                  //                 DataRow drCount = orgnames.Tables[0].NewRow();
                  //                 drCount["organizationName"] = orgName;
                                    
                  //                 //drCount["organization"] = orgName;
                                   
                  //                 orgnames.Tables[0].Rows.Add(new object[] { orgName });

                  //             } 

                  //         }
                  //     }
                  // }

                  //// return ds;
                  //return orgnames;
               }

               foreach (DataRow row in ds.Tables[0].Rows)
               {
                   using (SqlCommand cmd1 = new SqlCommand("select count(*) from ActiveDirectoryUserDataReplica where organizationUnit like @orgName", con))
                   {

                       string orgName = row["organizationName"].ToString();
                       cmd1.CommandType = CommandType.Text;
                       //cmd1.Parameters.AddWithValue("@orgName", "%" + orgName + "%"); 
                       cmd1.Parameters.AddWithValue("@orgName", orgName + "%"); 


                       SqlDataAdapter da = new SqlDataAdapter(cmd1);
                       DataSet userCount = new DataSet();
                       da.Fill(userCount);
                       int uCount = Convert.ToInt32(userCount.Tables[0].Rows[0][0].ToString());  //Convert.ToInt32(cmd1.ExecuteScalar().ToString());
                       if (uCount > 0)
                       {
                           orgnames.Tables[0].Rows.Add(new object[] { orgName });
                       }
                   }
               }

               return orgnames;

           }
           catch (Exception)
           {
               throw;
           }
           finally 
           {
               con = null;
           }
        }

        /// <summary>
        /// Method to get users belonging to organization unit from database
        /// </summary>
        /// <param name="organization">organization name(i.e. RI name)</param>
        /// <returns></returns>
        public DataSet GetOrganizationUnitUsers(string organization) 
        {
            SqlConnection con;
            try
            {
                con = GetConnection();
                con.Open();

                //string query = "select * from ActiveDirectoryUserDataReplica where organizationUnit like @organization";

                string query = "select users.*,userimage.basepath,userimage.filename from ActiveDirectoryUserDataReplica as users left outer join UserImageFileDetails as userimage on users.cn = userimage.cn where users.organizationUnit like @organization";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@organization","%"+ organization + "%"); //String.Format("%{0}%",organization

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    return ds;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return null;
        }

        /// <summary>
        /// Method to get users suggestions from database for search input
        /// </summary>
        /// <param name="searchInput"></param>
        /// <returns></returns>
        public DataSet GetUsersByName(string searchInput)
        {
            SqlConnection con;
            try
            {
                con = GetConnection();
                con.Open();

                string query = null;
                bool isNumberSearch = true;

                foreach (char c in searchInput)
                {
                    if (c < '0' || c > '9')
                    {
                        isNumberSearch = false;
                    }
                }

                //initial
                //query = "Select displayName,organizationUnit,cn from ActiveDirectoryUserDataReplica where displayName like @searchInput";


                //(RTRIM(LTRIM(mail)) = ''  or mail is null) and
                //RTRIM(LTRIM(telephoneNumber)) = '' and 
                //RTRIM(LTRIM(mobile)) = ''
                
                
                //filteration working query
                query = "Select displayName,organizationUnit,cn from ActiveDirectoryUserDataReplica where displayName like @searchInput and (RTRIM(LTRIM(mail)) != ''  and RTRIM(LTRIM(mail)) like '%.sg') UNION (Select displayName,organizationUnit,cn from ActiveDirectoryUserDataReplica where displayName like @searchInput and RTRIM(LTRIM(mail)) = '' and ( RTRIM(LTRIM(telephoneNumber)) != '' or  RTRIM(LTRIM(mobile)) != '' ))";

                //query = "Select displayName,organizationUnit,cn from ActiveDirectoryUserDataReplica where displayName like @searchInput and (mail != '' or telephoneNumber != '' or  mobile != '' )";
                

                if (!isNumberSearch)
                {
                    //initial
                    //query = "select displayName,organizationUnit,cn from ActiveDirectoryUserDataReplica where displayName like @searchInput";

                    //filteration working query
                    query = "Select displayName,organizationUnit,cn from ActiveDirectoryUserDataReplica where displayName like @searchInput and (RTRIM(LTRIM(mail)) != ''  and RTRIM(LTRIM(mail)) like '%.sg') UNION (Select displayName,organizationUnit,cn from ActiveDirectoryUserDataReplica where displayName like @searchInput and RTRIM(LTRIM(mail)) = '' and ( RTRIM(LTRIM(telephoneNumber)) != '' or  RTRIM(LTRIM(mobile)) != '' ))";

                    //query = "Select displayName,organizationUnit,cn from ActiveDirectoryUserDataReplica where displayName like @searchInput and (mail != '' or telephoneNumber != '' or  mobile != '' )";

                }
                else
                {
                    //initial
                    //query = "select displayName,organizationUnit,cn from ActiveDirectoryUserDataReplica where telephoneNumber like @searchInput";

                    //filteration working query
                    query = "Select displayName,organizationUnit,cn from ActiveDirectoryUserDataReplica where telephoneNumber like @searchInput and (RTRIM(LTRIM(mail)) != ''  and RTRIM(LTRIM(mail)) like '%.sg') UNION (Select displayName,organizationUnit,cn from ActiveDirectoryUserDataReplica where telephoneNumber like @searchInput and RTRIM(LTRIM(mail)) = '' and ( RTRIM(LTRIM(telephoneNumber)) != '' or  RTRIM(LTRIM(mobile)) != '' ))";

                    //query = "Select displayName,organizationUnit,cn from ActiveDirectoryUserDataReplica where telephoneNumber like @searchInput and (mail != '' or telephoneNumber != '' or  mobile != '' )";

                }


                using (SqlCommand cmd = new SqlCommand(query,con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@searchInput", "%" + searchInput + "%"); //string.Format("%{0}%",organization)
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    ds.DataSetName = "userSuggestionsForNamePhone";
                    da.Fill(ds);

                    ds.AcceptChanges();
                    return ds;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                con = null;
            }
            //return null;  
        }


        /// <summary>
        /// Method to get user details by cn name
        /// </summary>
        /// <param name="Name"></param>
        /// <returns></returns>
        public DataSet GetUsersDetailsByName(string Name)
        {
            SqlConnection con;
            try
            {
                con = GetConnection();
                con.Open();

                //string query = "select * from ActiveDirectoryUserDataReplica as users where users.cn = @cn";
                
                string query = "select users.*,userimage.basepath,userimage.filename from ActiveDirectoryUserDataReplica as users left outer join UserImageFileDetails as userimage on users.cn = userimage.cn where users.cn = @cn";

                //query = "select users.*,userimage.basepath,userimage.filename from activedirectoryuserdatareplica as users 
                //    left outer join userimagefiledetails as userimage on users.cn = userimage.cn where users.organizationunit like @organizationunit and users  @department";
                //    "select users.*,userimage.basepath,userimage.filename from activedirectoryuserdatareplica as users left outer join userimagefiledetails as userimage on users.cn = userimage.cn where users.organizationunit like @organization";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@cn", Name); //string.Format("%{0}%",organization)
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    return ds;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con = null;
            }
        }


        /// <summary>
        /// Method to get departments belonging to organization unit
        /// </summary>
        /// <param name="organization"></param>
        /// <returns></returns>
        public DataSet GetDepartmentByOrganizationUnit(string organization)
        {
            SqlConnection con;
            try
            {
                con = GetConnection();
                con.Open();

                using (SqlCommand cmd = new SqlCommand("select distinct(department) from ActiveDirectoryUserDataReplica where organizationUnit like @organization", con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@organization", "%" + organization + "%"); //string.Format("%{0}%",organization)
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    return ds;              
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                con = null;
            }
            return null;
        }



        public DataSet GetUsersByDepartmentAndOrganizationUnit(string organization, string department)
        {
            SqlConnection con;
            try
            {
                con = GetConnection();
                con.Open();

                string query = null;
                bool isAllDepartment = false;

                if (department.Equals("All", StringComparison.InvariantCultureIgnoreCase))
                {
                    //query = "select * from ActiveDirectoryUserDataReplica where organizationUnit like @organization ";
                    query = "select users.*,userimage.basepath,userimage.filename from ActiveDirectoryUserDataReplica as users left outer join UserImageFileDetails as userimage on users.cn = userimage.cn where users.organizationUnit like @organization ";

                    isAllDepartment = true;
                }
                else
                {
                    //query = "select * from ActiveDirectoryUserDataReplica where organizationUnit like @organization and department = @department";
                    query = "select users.*,userimage.basepath,userimage.filename from ActiveDirectoryUserDataReplica as users left outer join UserImageFileDetails as userimage on users.cn = userimage.cn where users.organizationUnit like @organization and users.department = @department";
                }

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Parameters.AddWithValue("@organization", "%" + organization + "%"); //string.Format("%{0}%",organization)
                    if (!isAllDepartment)
                    {
                        cmd.Parameters.AddWithValue("@department", department);
                    }
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    return ds; 
                }
            }
            catch (Exception e)
            {
            }
            finally
            {
                con = null;
            }
            return null;
        }


    }
}