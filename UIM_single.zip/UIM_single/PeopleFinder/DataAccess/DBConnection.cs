﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace PeopleFinder.DataAccess
{
    public class DBConnection
    {

        public static SqlConnection GetConnection()
        {
            try
            {
                string connectionString = GetConnectionString(); //ConfigurationManager.ConnectionStrings["DatabaseConnectionString"].ConnectionString;
                SqlConnection connection = new SqlConnection(connectionString);
                return connection;
            }
            catch (Exception e)
            {
                throw e;
            }
        }


        private static string GetConnectionString()
        {
            try
            {
                string prodEnvirorment = ConfigurationManager.AppSettings["IS_PROD"].ToString();
                string uatEnvirorment = ConfigurationManager.AppSettings["IS_UAT"].ToString();
                string devEnvirorment = ConfigurationManager.AppSettings["IS_DEV"].ToString();

                string dbConnectionString = null;

                if (Convert.ToBoolean(Convert.ToInt16(prodEnvirorment)))
                {
                    dbConnectionString = ConfigurationManager.ConnectionStrings["ProdDatabaseConnectionString"].ConnectionString;
                }
                else if (Convert.ToBoolean(Convert.ToInt16(uatEnvirorment)))
                {
                    dbConnectionString = ConfigurationManager.ConnectionStrings["UatDatabaseConnectionString"].ConnectionString;
                }
                else if (Convert.ToBoolean(Convert.ToInt16(devEnvirorment)))
                {
                    dbConnectionString = ConfigurationManager.ConnectionStrings["DevDatabaseConnectionString"].ConnectionString;
                }

                return dbConnectionString;
            }
            catch (Exception)
            {
                throw;
            }
        }


    }
}